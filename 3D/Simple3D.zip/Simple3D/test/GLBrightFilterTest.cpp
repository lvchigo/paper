#include "test/GLTest.h"
#include "core/GLBitmapFactory.h"
#include "filter/GLBrightFilter.h"

class GLBrightFilterTest:public GLTest
{
    public:
        virtual void run();
        GLBrightFilterTest(){}
        virtual ~GLBrightFilterTest(){}
};

void GLBrightFilterTest::run()
{
    GPPtr<IGLFilter> filter = new GLBrightFilter;
    GPPtr<GLBmp> origin = GLBitmapFactory::create("input.png");
    GPPtr<GLBmp> dst = new GLBmp(origin->width(), origin->height());
    filter->vFilter(dst.get(), origin.get());
    GLBitmapFactory::dump(dst.get(), "output/GLBrightFilterTest.png");
}
static GLTestRegister<GLBrightFilterTest> a("GLBrightFilterTest");
