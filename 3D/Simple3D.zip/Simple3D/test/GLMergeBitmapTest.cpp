#include "test/GLTest.h"
#include "algorithm/GLSkinDetect.h"
#include "core/GLBitmapFactory.h"
#include "core/GLGrayBitmap.h"
#include "ImageProc.h"

class GLMergeBitmapTest:public GLTest
{
    public:
        virtual void run();
        GLMergeBitmapTest(){}
        virtual ~GLMergeBitmapTest(){}
};

void GLMergeBitmapTest::run()
{
    GPPtr<GLBmp> origin = GLBitmapFactory::create("meifutest.png");
    GPPtr<GLBmp> black = new GLBmp(origin->width(), origin->height());
    black->clear();
    GPPtr<GLGrayBitmap> mask = new GLGrayBitmap(origin->width(), origin->height());
    GLSkinDetect::run(origin.get(), mask.get());
    ImageProc::bitmapMergeMask(origin.get(), black.get(), mask.get(),0,0);
    GLBitmapFactory::dump(origin.get(), "output/GLMergeBitmapTest.png");
}
static GLTestRegister<GLMergeBitmapTest> a("GLMergeBitmapTest");
