#include "test/GLTest.h"
#include "core/GLGrayBitmap.h"
#include "core/GLBitmapFactory.h"

class GLGrayBitmapTest:public GLTest
{
    public:
        virtual void run();
        GLGrayBitmapTest(){}
        virtual ~GLGrayBitmapTest(){}
};

void GLGrayBitmapTest::run()
{
    GPPtr<GLBmp> rgb = GLBitmapFactory::create("input.png");
    GPPtr<GLGrayBitmap> gray = new GLGrayBitmap(rgb->width(), rgb->height());
    GLGrayBitmap::turnGray(gray.get(), rgb.get());
    GLGrayBitmap::turnRGB(gray.get(), rgb.get());
    GLBitmapFactory::dump(rgb.get(), "output/GLGrayBitmapTest.png");
}
static GLTestRegister<GLGrayBitmapTest> a("GLGrayBitmapTest");
