#include "test/GLTest.h"
#include "core/GLBitmapFactory.h"
#include "operator/GLGrayOperatorFactory.h"
#include "operator/GLFastBlurFilter.h"

class GLGrayOperatorFactoryTest:public GLTest
{
    public:
        virtual void run();
        GLGrayOperatorFactoryTest(){}
        virtual ~GLGrayOperatorFactoryTest(){}
};

void GLGrayOperatorFactoryTest::run()
{
    GPPtr<IGrayOperator> originfilter = new GLFastBlurFilter;
    GPPtr<IGLFilter> filter = GLGrayOperatorFactory::turnToRGB(originfilter.get());
    GPPtr<GLBmp> origin = GLBitmapFactory::create("input.png");
    GPPtr<GLBmp> dst = new GLBmp(origin->width(), origin->height());
    filter->vFilter(dst.get(), origin.get());
    GLBitmapFactory::dump(dst.get(), "output/GLGrayOperatorFactoryTest.png");
}
static GLTestRegister<GLGrayOperatorFactoryTest> a("GLGrayOperatorFactoryTest");
