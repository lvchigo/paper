#include "test/GLTest.h"
#include "algorithm/GLSkinDetect.h"
#include "core/GLBitmapFactory.h"
#include "core/GLGrayBitmap.h"

class GLSkinDetectTest:public GLTest
{
    public:
        virtual void run();
        GLSkinDetectTest(){}
        virtual ~GLSkinDetectTest(){}
};

void GLSkinDetectTest::run()
{
    GPPtr<GLBmp> origin = GLBitmapFactory::create("meifutest.png");
    GPPtr<GLGrayBitmap> dst = new GLGrayBitmap(origin->width(), origin->height());
    GLSkinDetect::run(origin.get(), dst.get());
    GLGrayBitmap::turnRGB(dst.get(), origin.get());
    GLBitmapFactory::dump(origin.get(), "output/GLSkinDetectTest.png");
}
static GLTestRegister<GLSkinDetectTest> a("GLSkinDetectTest");
