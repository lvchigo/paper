#include "test/GLTest.h"
#include "core/GLBitmapFactory.h"
#include "core/GLGrayBitmap.h"
#include "algorithm/GLRegions.h"
#include "utils/GLDebug.h"

class GLRegionTest:public GLTest
{
    public:
        virtual void run();
        GLRegionTest(){}
        virtual ~GLRegionTest(){}
};

void GLRegionTest::run()
{
    GPPtr<GLBmp> origin = GLBitmapFactory::create("./shape.png");
    GPPtr<GLGrayBitmap> gray = new GLGrayBitmap(origin->width(), origin->height());
    GLGrayBitmap::turnGray(gray.get(), origin.get());
    std::vector<std::pair<int, int>> points;
    GLRegion::reduceToOneRegion(gray.get(), NULL);
    GLGrayBitmap::turnRGB(gray.get(), origin.get());
    GLBitmapFactory::dump(origin.get(), "output/GLRegionTestReduceRegion.png");
    GLRegion::findContour(gray.get(), points);
    gray->clear();
    for (auto p : points)
    {
        *(gray->getAddr(p.first, p.second)) = 0xFF;
    }
    GLGrayBitmap::turnRGB(gray.get(), origin.get());
    GLBitmapFactory::dump(origin.get(), "output/GLRegionTest.png");
    
    std::vector<std::pair<int, int>> offsetpoints;
    GLRegion::offsetContour(points, offsetpoints, 0);
    gray->clear();
    offsetpoints.push_back(offsetpoints[0]);
    for (int i=0; i<offsetpoints.size()-1; ++i)
    {
        auto x1 = offsetpoints[i].first;
        auto x2 = offsetpoints[i+1].first;
        auto y1 = offsetpoints[i].second;
        auto y2 = offsetpoints[i+1].second;
        for (int p = 0; p<10; ++p)
        {
            float rate = p*0.1;
            int x = x1*rate + x2*(1-rate);
            int y = y1*rate + y2*(1-rate);
            *(gray->getAddr(x, y)) = 0xFF;
        }
    }
    GLGrayBitmap::turnRGB(gray.get(), origin.get());
    GLBitmapFactory::dump(origin.get(), "output/GLRegionTestOffset.png");

    
    GPPtr<GLGrayBitmap> rectRegion = new GLGrayBitmap(origin->width(), origin->height());
    rectRegion->clear();
    int l = origin->width()/3;
    int r = l + origin->width()/3;
    int t = origin->height()/3;
    int b = t + origin->height()/3;
    int sw = r-l+1;
    int sh = b-t+1;
    for (int y=t; y<=b; ++y)
    {
        auto addr = rectRegion->getAddr(l, y);
        ::memset(addr, 0xFF, sizeof(unsigned char)*sw);
    }
    points.clear();
    GLRegion::findContour(rectRegion.get(), points);
    gray->clear();
    for (int i=0; i<points.size()-1; ++i)
    {
        auto x1 = points[i].first;
        auto x2 = points[i+1].first;
        auto y1 = points[i].second;
        auto y2 = points[i+1].second;
        for (int p = 0; p<10; ++p)
        {
            float rate = p*0.1;
            int x = x1*rate + x2*(1-rate);
            int y = y1*rate + y2*(1-rate);
            *(gray->getAddr(x, y)) = 0xFF;
        }
    }
    GLGrayBitmap::turnRGB(gray.get(), origin.get());
    GLBitmapFactory::dump(origin.get(), "output/GLRegionTest2.png");
    
    {
        GPPtr<GLBmp> origin = GLBitmapFactory::create("hole.png");
        GPPtr<GLGrayBitmap> gray = new GLGrayBitmap(origin->width(), origin->height());
        GLGrayBitmap::turnGray(gray.get(), origin.get());
        FUNC_PRINT(GLRegion::getMeanWidth(gray.get(), 0.6f));
        GLRegion::fillHole(gray.get());
        GLGrayBitmap::turnRGB(gray.get(), origin.get());
        GLBitmapFactory::dump(origin.get(), "fillholetest.png");
    }

    
}
static GLTestRegister<GLRegionTest> a("GLRegionTest");
