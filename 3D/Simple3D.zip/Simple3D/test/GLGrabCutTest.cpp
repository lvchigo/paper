#include "test/GLTest.h"
#include "algorithm/GLGraphicCut.h"
#include "core/GLBitmapFactory.h"

class GLGrabCutTest:public GLTest
{
    public:
        virtual void run();
        GLGrabCutTest(){}
        virtual ~GLGrabCutTest(){}
};

void GLGrabCutTest::run()
{
    GPPtr<GLBmp> origin = GLBitmapFactory::create("input.png");
    auto w = origin->width();
    auto h = origin->height();
    GPPtr<GLGrayBitmap> mask = new GLGrayBitmap(w, h);
    //::memset(mask->getAddr(0,0), 1, w*h*sizeof(unsigned char));
    mask->clear();
    int l = 2*w/5;
    int t = h/2;
    int sw = 2*w/5;
    int sh = h/2;
    for (int y=t; y<sh+t; ++y)
    {
        auto m = mask->getAddr(l, y);
        ::memset(m, 129, sw*sizeof(unsigned char));
        //::memset(m+sw/3, 0xFF, sw/3*sizeof(unsigned char));
    }
    GLGraphicCut cut(450, 20);
    cut.grabCut(origin.get(), mask.get(), 128, 255);
    for (int y=0; y<h; ++y)
    {
        for (int x=0; x<w; ++x)
        {
            auto rgb = origin->getAddr(x, y);
            auto m = mask->getAddr(x, y);
            rgb[0] = rgb[0]*m[0]/255;
            rgb[1] = rgb[1]*m[0]/255;
            rgb[2] = rgb[2]*m[0]/255;
        }
    }
    GLBitmapFactory::dump(origin.get(), "output/GLGrabCutTest.png");
}
static GLTestRegister<GLGrabCutTest> a("GLGrabCutTest");
