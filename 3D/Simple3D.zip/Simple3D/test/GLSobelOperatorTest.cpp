#include "test/GLTest.h"
#include "operator/GLSobelOperator.h"
#include "core/GLBitmapFactory.h"

class GLSobelOperatorTest:public GLTest
{
    public:
        virtual void run();
        GLSobelOperatorTest(){}
        virtual ~GLSobelOperatorTest(){}
};

void GLSobelOperatorTest::run()
{
    GPPtr<GLBmp> rgb = GLBitmapFactory::create("input.png");
    GPPtr<GLGrayBitmap> gray = new GLGrayBitmap(rgb->width(), rgb->height());
    GPPtr<GLGrayBitmap> gray_treat = new GLGrayBitmap(rgb->width(), rgb->height());
    GLGrayBitmap::turnGray(gray.get(), rgb.get());
    GLSobelOperator filter(1, 0);
    filter.vFilter(gray_treat.get(), gray.get());
    GLGrayBitmap::turnRGB(gray_treat.get(), rgb.get());
    GLBitmapFactory::dump(rgb.get(), "output/GLSobelOperatorTest.png");
}
static GLTestRegister<GLSobelOperatorTest> a("GLSobelOperatorTest");
