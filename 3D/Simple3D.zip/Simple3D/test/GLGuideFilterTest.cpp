#include "test/GLTest.h"
#include "core/GLBitmapFactory.h"
#include "filter/GLGuideFilter.h"

class GLGuideFilterTest:public GLTest
{
    public:
        virtual void run();
        GLGuideFilterTest(){}
        virtual ~GLGuideFilterTest(){}
};

void GLGuideFilterTest::run()
{
    GPPtr<IGLFilter> filter = new GLGuideFilter;
    GPPtr<GLBmp> origin = GLBitmapFactory::create("meifutest.png");
    GPPtr<GLBmp> dst = new GLBmp(origin->width(), origin->height());
    filter->vFilter(dst.get(), origin.get());
    GLBitmapFactory::dump(dst.get(), "output/GLGuideFilterTest.png");
}
static GLTestRegister<GLGuideFilterTest> a("GLGuideFilterTest");
