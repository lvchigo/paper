#include "test/GLTest.h"
#include "core/GLBitmapFactory.h"
#include "filter/GLGuideFilter.h"
#include "filter/GLChainFilter.h"
#include "filter/GLBrightFilter.h"
#include <algorithm>

class GLMeiFuTest:public GLTest
{
    public:
        virtual void run();
        GLMeiFuTest(){}
        virtual ~GLMeiFuTest(){}
};

void GLMeiFuTest::run()
{
    GPPtr<GLBmp> origin = GLBitmapFactory::create("meifutest.png");
    GPPtr<GLBmp> dst = new GLBmp(origin->width(), origin->height());
    auto w = dst->width();
    GPPtr<GLChainFilter> filter = new GLChainFilter(new GLGuideFilter(std::min(128.0, w*0.03), 0.005));
    filter->addFilter(new GLBrightFilter);
    filter->vFilter(dst.get(), origin.get());
    GLBitmapFactory::dump(dst.get(), "output/GLMeiFuTest.png");
}
static GLTestRegister<GLMeiFuTest> a("GLMeiFuTest");
