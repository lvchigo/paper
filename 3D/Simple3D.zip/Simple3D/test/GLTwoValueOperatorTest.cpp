#include "test/GLTest.h"
#include "operator/GLTwoValueOperator.h"
#include "core/GLBitmapFactory.h"

class GLTwoValueOperatorTest:public GLTest
{
    public:
        virtual void run();
        GLTwoValueOperatorTest(){}
        virtual ~GLTwoValueOperatorTest(){}
};

void GLTwoValueOperatorTest::run()
{
    GPPtr<GLBmp> rgb = GLBitmapFactory::create("input.png");
    GPPtr<GLGrayBitmap> gray = new GLGrayBitmap(rgb->width(), rgb->height());
    GPPtr<GLGrayBitmap> gray_treat = new GLGrayBitmap(rgb->width(), rgb->height());
    GLGrayBitmap::turnGray(gray.get(), rgb.get());
    GLTwoValueOperator filter(0.5f);
    filter.vFilter(gray_treat.get(), gray.get());
    GLGrayBitmap::turnRGB(gray_treat.get(), rgb.get());
    GLBitmapFactory::dump(rgb.get(), "output/GLTwoValueOperatorTest.png");
}
static GLTestRegister<GLTwoValueOperatorTest> a("GLTwoValueOperatorTest");
