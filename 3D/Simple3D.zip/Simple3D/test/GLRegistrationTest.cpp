#include "test/GLTest.h"
#include "algorithm/GLDistanceMatcher.h"
#include "algorithm/GLLinearRegressor.h"
#include "algorithm/GLSiftOperator.h"
#include "core/GLBitmapFactory.h"
#include <iostream>
using namespace std;

class GLRegistrationTest:public GLTest
{
    public:
        virtual void run();
        GLRegistrationTest(){}
        virtual ~GLRegistrationTest(){}
};

void GLRegistrationTest::run()
{
    GPPtr<GLBmp> b1 = GLBitmapFactory::create("p1.png");
    GPPtr<GLBmp> b2 = GLBitmapFactory::create("p2.png");
    GPPtr<GLGrayBitmap> g1 = new GLGrayBitmap(b1->width(), b1->height());
    GPPtr<GLGrayBitmap> g2 = new GLGrayBitmap(b2->width(), b2->height());
    GLGrayBitmap::turnGray(g1.get(), b1.get());
    GLGrayBitmap::turnGray(g2.get(), b2.get());
    GPPtr<GLRegistration> registrationer = new GLRegistration(new GLSiftOperator, new GLDistanceMatcher, new GLLinearRegressor);

    GPPtr<GLMatrix<float>> parameter = registrationer->registration(g1.get(), g2.get());
    int h = parameter->height();
    int w = parameter->width();
    for (int i=0; i<h; ++i)
    {
        auto p = parameter->getAddr(i);
        for (int j=0; j<w; ++j)
        {
            cout << p[j] << " ";
        }
        cout << "\n";
    }
}
static GLTestRegister<GLRegistrationTest> a("GLRegistrationTest");
