#include "test/GLTest.h"
#include "core/GLBitmapFactory.h"
#include "filter/GLHistogramEqualFilter.h"

class GLHistogramTest:public GLTest
{
    public:
        virtual void run();
        GLHistogramTest(){}
        virtual ~GLHistogramTest(){}
};

void GLHistogramTest::run()
{
    GPPtr<IGLFilter> filter = new GLHistogramEqualFilter;
    GPPtr<GLBmp> origin = GLBitmapFactory::create("input.png");
    GPPtr<GLBmp> dst = new GLBmp(origin->width(), origin->height());
    filter->vFilter(dst.get(), origin.get());
    GLBitmapFactory::dump(dst.get(), "output/GLHistogramTest.png");
}
static GLTestRegister<GLHistogramTest> a("GLHistogramTest");
