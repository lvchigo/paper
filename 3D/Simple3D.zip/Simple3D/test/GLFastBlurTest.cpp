#include "test/GLTest.h"
#include "core/GLGrayBitmap.h"
#include "core/GLBitmapFactory.h"
#include "operator/GLFastBlurFilter.h"

class GLFastBlurTest:public GLTest
{
    public:
        virtual void run();
        GLFastBlurTest(){}
        virtual ~GLFastBlurTest(){}
};

void GLFastBlurTest::run()
{
    GPPtr<GLBmp> rgb = GLBitmapFactory::create("input.png");
    GPPtr<GLGrayBitmap> gray = new GLGrayBitmap(rgb->width(), rgb->height());
    GPPtr<GLGrayBitmap> gray_treat = new GLGrayBitmap(rgb->width(), rgb->height());
    GLGrayBitmap::turnGray(gray.get(), rgb.get());
    GLFastBlurFilter filter(10);
    filter.vFilter(gray_treat.get(), gray.get());
    GLGrayBitmap::turnRGB(gray_treat.get(), rgb.get());
    GLBitmapFactory::dump(rgb.get(), "output/GLFastBlurFilterTest.png");
}
static GLTestRegister<GLFastBlurTest> a("GLFastBlurTest");
