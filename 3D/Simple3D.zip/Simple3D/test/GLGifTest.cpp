#include "test/GLTest.h"
#include "utils/GLDebug.h"
#include "movie/GLGifManager.h"
#include "core/GLBitmapFactory.h"
#include <sstream>

class GLGifTest:public GLTest
{
    public:
        virtual void run();
        GLGifTest(){}
        virtual ~GLGifTest(){}
};

void GLGifTest::run()
{
    auto movie = GLGifManager::decode("53c389904c881.gif");
    GPPtr<GLGifEncoder> encoder = GLGifManager::encode("output/GLGifTest/dst.gif");
    FUNC_PRINT(movie->frames());
    FUNC_PRINT(movie->width());
    FUNC_PRINT(movie->height());
    int w = movie->width();
    int h = movie->height();
    int n = movie->frames();
    GPPtr<GLBmp> dst = new GLBmp(w, h);
    for (int i=0; i<n; ++i)
    {
        std::ostringstream os;
        os << "output/GLGifTest/"<<i<<".png";
        movie->draw(dst.get(), i, false);
        if (0 == i)
        {
            encoder->start(dst.get());
        }
        else
        {
            encoder->add(dst.get(), 0, 0);
        }
        GLBitmapFactory::dump(dst.get(), os.str().c_str());
    }
    movie->draw(dst.get(), 0, false);
    encoder->start(dst.get());
    {
        GPPtr<GLBmp> jpegbitmap = GLBitmapFactory::create("testcomplex.png");
        GPPtr<GLGifEncoder> gifencoder = GLGifManager::encode("output/GLGifTest/testcomplex.gif");
        gifencoder->start(jpegbitmap.get());
    }
}
static GLTestRegister<GLGifTest> a("GLGifTest");
