#include "test/GLTest.h"
#include "filter/IGLFilterFactory.h"
#include "core/GLBitmapFactory.h"
#include <iostream>
class GLFilterFactoryTest:public GLTest
{
    public:
        virtual void run();
        GLFilterFactoryTest(){}
        virtual ~GLFilterFactoryTest(){}
};

void GLFilterFactoryTest::run()
{
    GPPtr<GLBmp> origin = GLBitmapFactory::create("basic.png");
    GPPtr<GLBmp> dst = new GLBmp(origin->width(), origin->height());
    auto methods = IGLFilterFactory::listMethods();
    for (auto m : methods)
    {
        std::cout << m << std::endl;
        auto outputname = "output/factory/" + m + "_factorytest.png";
        GPPtr<IGLFilter> filter = IGLFilterFactory::create(m.c_str(), origin->width(), origin->height());
        filter->vFilter(dst.get(), origin.get());
        GLBitmapFactory::dump(dst.get(), outputname.c_str());
    }
}
static GLTestRegister<GLFilterFactoryTest> a("GLFilterFactoryTest");
