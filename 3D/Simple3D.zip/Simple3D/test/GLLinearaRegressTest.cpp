#include "test/GLTest.h"
#include "algorithm/GLLinearRegressor.h"
#include <iostream>
#include <stdlib.h>
using namespace std;

class GLLinearaRegressTest:public GLTest
{
    public:
        virtual void run();
        GLLinearaRegressTest(){}
        virtual ~GLLinearaRegressTest(){}
};

void GLLinearaRegressTest::run()
{
    GPPtr<GLMatrix<int>> P1 = new GLMatrix<int>(5, 2);
    GPPtr<GLMatrix<int>> P2 = new GLMatrix<int>(5, 2);
    auto p1x = P1->getAddr(0);
    auto p1y = P1->getAddr(1);
    auto p2x = P2->getAddr(0);
    auto p2y = P2->getAddr(1);
    for (int i=0; i<5; ++i)
    {
        p1x[i] = (rand()%50);
        p1y[i] = (rand()%100);
        p2x[i] = 0.6*p1x[i] + 0.8*p1y[i] + 0.5 + 0.1*(rand()%100);
        p2y[i] = 0.9*p1x[i] + 0.2*p1y[i] + 0.3 + 0.1*(rand()%100);
    }
    GLLinearRegressor reg;
    GPPtr<GLMatrix<float>> res = reg.vRegress(P1, P2);
    for (int i=0; i<res->height(); ++i)
    {
        auto _r = res->getAddr(i);
        for (int j=0; j<res->width(); ++j)
        {
            cout << _r[j] << " ";
        }
        cout << "\n";
    }
}
static GLTestRegister<GLLinearaRegressTest> a("GLLinearaRegressTest");
