#include "test/GLTest.h"
#include "Decryptor.h"
#include "core/GLBitmapFactory.h"

class GLDecryptorTest:public GLTest
{
    public:
        virtual void run();
        GLDecryptorTest(){}
        virtual ~GLDecryptorTest(){}
};

void GLDecryptorTest::run()
{
    GPPtr<GLBmp> origin = GLBitmapFactory::create("input.png");
    Decryptor::encode(origin.get());
    GPPtr<GLBmp> dst = origin;
    GLBitmapFactory::dump(dst.get(), "output/GLDecryptorTest_encode.png");
    Decryptor::decode(dst.get());
    GLBitmapFactory::dump(dst.get(), "output/GLDecryptorTest_decode.png");
}
static GLTestRegister<GLDecryptorTest> a("GLDecryptorTest");
