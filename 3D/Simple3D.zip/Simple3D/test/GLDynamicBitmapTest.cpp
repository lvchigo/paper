#include "test/GLTest.h"
#include "movie/GLDynamicBitmapFactory.h"
#include "core/GLBitmapFactory.h"
#include "utils/GLDebug.h"
#include <sstream>
using namespace std;

class GLDynamicBitmapTest:public GLTest
{
    public:
        virtual void run();
        GLDynamicBitmapTest(){}
        virtual ~GLDynamicBitmapTest(){}
};

void GLDynamicBitmapTest::run()
{
    if (true)
    {
        GPPtr<GLBmp> bitmap = GLBitmapFactory::create("input2.png");
        GPPtr<GLBmp> bitmap2 = new GLBmp(bitmap->width()/3, bitmap->height()/3);
        /*Crop LT*/
        for (int i=0; i<bitmap2->height(); ++i)
        {
            int size = bitmap2->width()*4*sizeof(unsigned char);
            ::memcpy(bitmap2->getAddr(0, i), bitmap->getAddr(0, i), size);
        }
        int frames = 10;
        GPPtr<GLWStream> output = GLStreamFactory::writeForFile("output/GLDynamicBitmapTest.png");
        GPPtr<GLDynamicBitmapFactory::Encoder> encoder = GLDynamicBitmapFactory::startEncode(bitmap, output, frames);
        int wunit = (bitmap->width()-bitmap2->width())/frames;
        int hunit = (bitmap->height()-bitmap2->height())/frames;
        for (int i=1; i<frames; ++i)
        {
            encoder->addFrame(wunit*i, hunit*i, bitmap2.get());
        }
    }
    {
        GPPtr<GLStream> inputs = GLStreamFactory::readFromFile("output/GLDynamicBitmapTest.png");
        GPPtr<GLMovie> byb = GLDynamicBitmapFactory::decode(inputs);
        auto frames = byb->frames();
        GPPtr<GLBmp> dst = new GLBmp(byb->width(), byb->height());
        for (int i=0; i<frames; ++i)
        {
            ostringstream filename;
            FUNC_PRINT(i);
            filename <<"output/GLDynamicBitmapTest/frame_"<<i<<"_apng.png";
            byb->draw(dst.get(), i, false);
            GLBitmapFactory::dump(dst.get(), filename.str().c_str());
        }
    }
}
static GLTestRegister<GLDynamicBitmapTest> a("GLDynamicBitmapTest");
