#!/usr/bin/python
gDefaultPath = "glsl"
gOutputHeadFile = "AllShader.h"
gOutputSourceFile = "glsl/AllShader.cpp"
gOutputFactoryFile = "opengl/src/GL/GLShaderFactory.cpp"
import os
def findAllShader(path):
    cmd = "find " + path + " -name \"*.vex\""
    vexs = os.popen(cmd).read().split('\n')
    cmd = "find " + path + " -name \"*.fra\""
    fras = os.popen(cmd).read().split('\n')
    output = []
    for f in vexs:
        if len(f)>1:
            output.append(f)
    for f in fras:
        if len(f)>1:
            output.append(f)
    return output

def getName(fileName):
    s1 = fileName.replace("/", "_")
    s1 = s1.replace(".", "_")
    return s1
def getShortName(name):
    s = name.split('/')
    return s[len(s)-1]

def generateFile(headfile, sourcefile, factoryfile, shaders):
    h = "#ifndef GLSL_SHADER_AUTO_GENERATE_H\n#define GLSL_SHADER_AUTO_GENERATE_H\n#include <string>\n"
    cpp = "#include \"" + headfile +"\"\n"
    factorycpp = "#include \"GL/GLShaderFactory.h\"\n#include \"AllShader.h\"\n"
    factorycpp += "const char* GLShaderFactory::get(std::string name)\n{\n"
    for s in shaders:
        name = getName(s)
        sname = getShortName(s)
        factorycpp += 'if(name ==\"' + sname + '\") return ' + name+'.c_str();\n'
        h += "extern const std::string " + name + ";\n";
        f = open(s)
        allcontents = f.read()
        f.close();
        if name.find('fra')!=-1 and allcontents.find('sampler2D inputImageTexture')!=-1:
        #if False:
            cpp += "const std::string " + name + " = \"#extension GL_OES_EGL_image_external : require\\n\"\n";
        else:
            cpp += "const std::string " + name + " = \"\"\n";
        lines = allcontents.split("\n")
        for l in lines:
            l = l.replace('\015','')
            if (len(l) < 1):
                continue
            #Delete 
            cpp += "\""+l+"\\n\"\n"
        cpp += ";\n"
    h+= "#endif"
    factorycpp += 'return NULL;\n}\n'
    headfile = "include/" + headfile;
    with open(headfile, "w") as f:
        f.write(h);
    cpp = cpp.replace('sampler2D inputImageTexture;', 'samplerExternalOES inputImageTexture;')
    with open(sourcefile, "w") as f:
        f.write(cpp);
    with open(factoryfile, 'w') as f:
        f.write(factorycpp)

if __name__ == '__main__':
    shaders = findAllShader(gDefaultPath)
    generateFile(gOutputHeadFile, gOutputSourceFile, gOutputFactoryFile, shaders);
