#ifndef GL_GLPASTELINWORK_H
#define GL_GLPASTELINWORK_H
#include "GLInWork.h"
CONTEXT_CLASS class GLPastelInWork:public GLInWork
{
    public:
        GLPastelInWork(const char* vertex, const char* frag, std::vector<GLBmp*> resources, float defaultratio);
        virtual ~GLPastelInWork();
    private:
        virtual void onSetupVertex(int w, int h);
        int mWidthPos;
        int mHeightPos;
};
#endif
