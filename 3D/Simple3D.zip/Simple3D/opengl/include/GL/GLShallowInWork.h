#ifndef GL_GLSHALLOWINWORK_H
#define GL_GLSHALLOWINWORK_H
#include "GLInWork.h"
#include "GLvboBuffer.h"
CONTEXT_CLASS class GLShallowInWork:public GLInWork
{
    public:
        GLShallowInWork(const char* vertex, const char* frag, std::vector<GLBmp*> resources, float defaultratio);
        virtual ~GLShallowInWork();
        virtual void onDraw(GLTexture** src, int n, GLvboBuffer* vex, GLvboBuffer* tex);
    private:
        int mWidthPos;
        int mHeightPos;
        GPPtr<GLProgram> mSecondProgram;
        GPPtr<GLvboBuffer> mFirstVex;
        GPPtr<GLTexture> mMidTexture;
        int mSecondRatioPos;
};
#endif
