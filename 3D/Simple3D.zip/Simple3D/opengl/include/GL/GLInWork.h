#ifndef GL_GLINWORK_H
#define GL_GLINWORK_H
#include "head.h"
#include "core/GLBmp.h"
#include "GL/GLTexture.h"
#include "GL/GLProgram.h"
#include "GL/GLvboBuffer.h"
#include "IGLDrawWork.h"
#include <vector>
struct GLInWorkResource
{
    std::string name;
    const char* vertex;
    const char* frag;
    float ratio;
    std::vector<GLBmp*> resources;
    GLInWorkResource(){}
    ~GLInWorkResource()
    {
        for (int i=0; i<resources.size(); ++i)
        {
            resources[i]->decRef();
        }
    }
};


CONTEXT_CLASS class GLInWork:public IGLDrawWork
{
public:
    /*If vertex/frag is NULL, use default shader*/
    GLInWork(const char* vertex, const char* frag, std::vector<GLBmp*> resouces, float defaultratio);
    virtual ~GLInWork();
    static void setDefaultVertexShader(const char* vertex);
    static void setDefaultFragmentShader(const char* frag);
    
    virtual size_t vMap(double* parameters, size_t n);
    
    
    virtual void onDraw(GLTexture** src, int n, GLvboBuffer* vs, GLvboBuffer* ts);
    void release();
    void setRatio(float ratio){mRatio = ratio;}
    float getRatio() const {return mRatio;}
    inline int getProgramId() const {return mProgram->id();}
    inline int getFirstTexturePos() const {return mFirstTexPos;}

    static GLInWork* createDefault();
    
protected:
    virtual void onSetupVertex(int w, int h);
    virtual void onSetupFragment(int w, int h);
    inline GLProgram* getProgram() {return mProgram.get();}
    float mRatio;
    int mRatioPos;
    int mFirstTexPos;
    GPPtr<GLProgram> mProgram;
private:
    
    std::vector<GPPtr<GLTexture> > mResources;
    std::vector<int> mResoucePos;
    
    static std::string gDefaultVertex;
};
#endif
