#ifndef GL_GLINWORKFACTORY_H
#define GL_GLINWORKFACTORY_H
#include "GLInWork.h"
#include <istream>
#include <map>
class GLInWorkCreator
{
    public:
        //Create BitmapWork
        virtual IGLDrawWork* vCreate(GLInWorkResource* r) const = 0;
        //Give Detail for how to set input
        virtual void vDetail(std::ostream& os) const{}
        GLInWorkCreator(){}
        virtual ~GLInWorkCreator(){}
};
class GLInWorkFactory
{
    public:
        //For User
        static IGLDrawWork* create(const char* name, GLInWorkResource* r, bool preferSpeed = true);
        //For GLInWorkCreatorRegister
        void insert(GLInWorkCreator* c, const std::string& s, bool preferSpeed);
        static GLInWorkFactory& get();
        void printMethods(std::ostream& os);
    private:
        IGLDrawWork* _create(const char* name, GLInWorkResource* r, bool preferSpeed);
        GLInWorkFactory();
        ~GLInWorkFactory();
        static GLInWorkFactory* gFactory;
        typedef std::map<std::string, GLInWorkCreator*> CREATERS;
        CREATERS mCreator;
        CREATERS mSlowCreator;
};
template <class T>
class GLInWorkCreatorRegister
{
    public:
        GLInWorkCreatorRegister(const char* claim, bool preferSpeed=true)
        {
            T* test = new T;
            GLInWorkFactory& ts = GLInWorkFactory::get();
            std::string s(claim);
            ts.insert(test, s, preferSpeed);
        }
        ~GLInWorkCreatorRegister(){}
};
#endif
