#ifndef FILTER_GLGPUFILTER_H
#define FILTER_GLGPUFILTER_H
#include "IGLFilter.h"
#include "IGLDrawWork.h"
#include "GLvboBuffer.h"
class GLGPUFilter:public IGLFilter
{
public:
    /*The vs and ts is 8-elements*/
    GLGPUFilter(GPPtr<IGLDrawWork> w, const float* vs, const float* ts);
    GLGPUFilter(GPPtr<IGLDrawWork> w, GPPtr<GLvboBuffer> vs, GPPtr<GLvboBuffer> ts); 
    virtual ~GLGPUFilter();
    virtual void vFilter(GLBmp* dst, const GLBmp* src) const;
    virtual size_t vMap(double* parameters, size_t n);
private:
    GPPtr<IGLDrawWork> mWork;
    GPPtr<GLTexture> mSrc;
    GPPtr<GLTexture> mDst;
    GPPtr<GLvboBuffer> mVs;
    GPPtr<GLvboBuffer> mTs;
};

#endif
