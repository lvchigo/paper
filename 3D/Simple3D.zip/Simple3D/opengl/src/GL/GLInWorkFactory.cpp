#include "GLInWorkFactory.h"
GLInWorkFactory* GLInWorkFactory::gFactory = NULL;

GLInWorkFactory& GLInWorkFactory::get()
{
    if (NULL == gFactory)
    {
        gFactory = new GLInWorkFactory;
    }
    return *gFactory;
}

void GLInWorkFactory::printMethods(std::ostream& os)
{
    CREATERS& c = gFactory->mCreator;
    CREATERS::iterator it = c.begin();
    for (;it!=c.end(); it++)
    {
        os << it->first<<std::endl;
        it->second->vDetail(os);
        os << std::endl;
    }
}

IGLDrawWork* GLInWorkFactory::create(const char* name, GLInWorkResource* input, bool preferSpeed)
{
    GLInWorkFactory& f = GLInWorkFactory::get();
    return f._create(name, input, preferSpeed);
}

IGLDrawWork* GLInWorkFactory::_create(const char* name, GLInWorkResource* input, bool preferSpeed)
{
    if (NULL==name) return NULL;
    if (!preferSpeed)
    {
        auto i = mSlowCreator.find(std::string(name));
        if (i!=mSlowCreator.end())
        {
            return (i->second)->vCreate(input);
        }
    }
    CREATERS::iterator i = mCreator.find(std::string(name));
    if (i!=mCreator.end())
    {
        return (i->second)->vCreate(input);
    }
    /*Default*/
    return new GLInWork(input->vertex, input->frag, input->resources, input->ratio);
}

void GLInWorkFactory::insert(GLInWorkCreator* c, const std::string& s, bool preferSpeed)
{
    if (preferSpeed)
    {
        mCreator.insert(make_pair(s, c));
    }
    else
    {
        mSlowCreator.insert(make_pair(s, c));
    }
}

GLInWorkFactory::GLInWorkFactory()
{
}

GLInWorkFactory::~GLInWorkFactory()
{
    for (auto i : mCreator)
    {
        delete i.second;
        i.second = NULL;
    }
    for (auto i : mSlowCreator)
    {
        delete i.second;
        i.second = NULL;
    }
}
