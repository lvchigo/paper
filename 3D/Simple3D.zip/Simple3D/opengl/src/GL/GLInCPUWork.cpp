#include "GLInCPUWork.h"
#include "GLAutoFbo.h"
#include "GLvboBufferManager.h"
static const char* gMixShader = "#extension GL_OES_EGL_image_external : require\n"
"precision mediump float;\n"
"varying vec2 textureCoordinate;\n"
"uniform samplerExternalOES inputImageTexture;\n"
"uniform sampler2D inputImageTexture2;\n"
"uniform float filterRatio;\n"
"void main()\n"
"{\n"
"vec3 origin = texture2D(inputImageTexture, textureCoordinate).rgb;\n"
"vec3 filter = texture2D(inputImageTexture2, textureCoordinate).rgb;\n"
"gl_FragColor = vec4(mix(origin, filter, filterRatio), 1.0);\n"
"}";


GLInCPUWork::GLInCPUWork(GPPtr<IGLFilter> f, std::vector<GLBmp*> resouces, float defaultratio) : GLInWork(NULL, gMixShader, resouces, defaultratio)
{
    GLASSERT(NULL!=f.get());
    mFilter = f;
    mCache = new GLTexture;
    mSecondTexPos = mProgram->uniform("inputImageTexture2");
}
GLInCPUWork::~GLInCPUWork()
{
    
}
void GLInCPUWork::onDraw(GLTexture** src, int n, GLvboBuffer* vs, GLvboBuffer* ts)
{
    GLASSERT(NULL!=src);
    GLASSERT(NULL!=vs);
    GLASSERT(NULL!=ts);
    GLASSERT(1==n);
    auto w = src[0]->width();
    auto h = src[0]->height();
    if (w != mCache->width() || h!=mCache->height())
    {
        mCache->upload(NULL, w, h);
    }
    GPPtr<GLBmp> srcB = new GLBmp(w, h);
    GPPtr<GLBmp> dstB = new GLBmp(w, h);
    {
        GLAutoFbo __s(*mCache);
        mProgram->use();
        GLProgram::setUniform(0.0f, mProgram->uniform("filterRatio"));
        src[0]->use(mFirstTexPos, 0);
        auto _vs = GLvboBufferManager::createBasicPos();
        auto _ts = GLvboBufferManager::createBasicTex();
        _vs->use(mProgram->attr("position"));
        _ts->use(mProgram->attr("inputTextureCoordinate"));
        _vs->draw();
        mCache->download(srcB->pixels());
    }
    mFilter->vFilter(dstB.get(), srcB.get());
    //memset(dstB->pixels(), 255 , 4*w*h);
    mCache->upload(dstB->pixels(), w, h);
    mProgram->use();
    src[0]->use(mFirstTexPos, 0);
    mCache->use(mSecondTexPos, 1);
    GLProgram::setUniform(mRatio, mProgram->uniform("filterRatio"));
    vs->use(mProgram->attr("position"));
    ts->use(mProgram->attr("inputTextureCoordinate"));
    ts->draw();
}
