#ifndef GL_GLINCPUWORK_H
#define GL_GLINCPUWORK_H
#include "GLInWork.h"
#include "IGLFilter.h"
class GLInCPUWork:public GLInWork
{
public:
    GLInCPUWork(GPPtr<IGLFilter> filter, std::vector<GLBmp*> resouces, float defaultratio);
    virtual ~GLInCPUWork();
    virtual void onDraw(GLTexture** src, int n, GLvboBuffer* vs, GLvboBuffer* ts);
private:
    GPPtr<GLTexture> mCache;
    GPPtr<IGLFilter> mFilter;
    int mSecondTexPos;
};
#endif
