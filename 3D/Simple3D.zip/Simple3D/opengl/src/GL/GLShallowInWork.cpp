#include "GLShallowInWork.h"
#include "GLInWorkFactory.h"
#include "GLShaderFactory.h"
#include "GLAutoFbo.h"
GLShallowInWork::GLShallowInWork(const char* vertex, const char* frag, std::vector<GLBmp*> resources, float defaultratio):GLInWork(vertex, frag, resources, defaultratio)
{
    mWidthPos = glGetUniformLocation(getProgramId(), "texelWidth");
    OPENGL_CHECK_ERROR;
    GLASSERT(-1!=mWidthPos);
    mHeightPos = glGetUniformLocation(getProgramId(), "texelHeight");
    OPENGL_CHECK_ERROR;
    GLASSERT(-1!=mHeightPos);
    const float points[] = {
        -1.0, -1.0,
        -1.0, 1.0,
        1.0, -1.0,
        1.0, 1.0
    };
    mFirstVex = new GLvboBuffer(points, 2, 4, GL_TRIANGLE_STRIP);
    mSecondProgram = new GLProgram(GLShaderFactory::get("ShallowTwoPass.vex"), GLShaderFactory::get("ShallowTwoPass.fra"));
    mSecondProgram->init();
    mSecondRatioPos = mSecondProgram->uniform("filterRatio");
    mMidTexture = new GLTexture;
}


GLShallowInWork::~GLShallowInWork()
{
}
void GLShallowInWork::onDraw(GLTexture** src, int n, GLvboBuffer* vex, GLvboBuffer* tex)
{
    GLASSERT(NULL!=vex);
    GLASSERT(NULL!=tex);
    GLASSERT(NULL!=src);
    GLASSERT(1==n);
    auto w = src[0]->width();
    auto h = src[0]->height();
    float scaleX = 2.0;
    float scaleY = 2.0;
    /*First Pass*/
    if (mMidTexture->width()!=w || mMidTexture->height()!=h)
    {
        mMidTexture->upload(NULL, w, h);
    }
    {
        GLAutoFbo _fbo(*(mMidTexture.get()));
        mProgram->use();
        GLProgram::setUniform(mRatio, mRatioPos);
        OPENGL_CHECK_ERROR;
        src[0]->use();
        GLProgram::setUniform((float)((1.0/w)*scaleX), mWidthPos);
        GLProgram::setUniform((float)0, mHeightPos);
        mFirstVex->use(mProgram->attr("position"));
        mFirstVex->draw();
    }
    /*Second*/
    mSecondProgram->use();
    mMidTexture->use();
    GLProgram::setUniform(mRatio, mSecondRatioPos);
    GLProgram::setUniform((float)0, mSecondProgram->uniform("texelWidth"));
    GLProgram::setUniform((float)((1.0/h)*scaleY), mSecondProgram->uniform("texelHeight"));
    vex->use(mSecondProgram->attr("position"));
    tex->use(mSecondProgram->attr("inputTextureCoordinate"));
    vex->draw();
}

class GLShallowInWorkCreator:public GLInWorkCreator
{
    public:
        //Create BitmapWork
        virtual IGLDrawWork* vCreate(GLInWorkResource* r) const
        {
            return new GLShallowInWork(r->vertex, r->frag, r->resources, r->ratio);
        }
};


#include "GLGuideFilter.h"
#include "GLInCPUWork.h"
class GLShallowInWorkCPUCreator:public GLInWorkCreator
{
    public:
        //Create BitmapWork
        virtual IGLDrawWork* vCreate(GLInWorkResource* r) const
        {
            return new GLInCPUWork(new GLGuideFilter, r->resources, r->ratio);
        }
};
static GLInWorkCreatorRegister<GLShallowInWorkCreator> __T2("Shallow");
//static GLInWorkCreatorRegister<GLShallowInWorkCPUCreator> __T2("Shallow");

