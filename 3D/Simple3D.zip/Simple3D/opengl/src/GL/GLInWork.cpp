#include "GLInWork.h"
#include <sstream>
#include "utils/GLDebug.h"

std::string GLInWork::gDefaultVertex =
"attribute vec2 position;\n"
"attribute vec2 inputTextureCoordinate;\n"
" \n"
"varying vec2 textureCoordinate;\n"
" \n"
"void main()\n"
"{\n"
"    gl_Position = vec4(position,1.0,1.0);\n"
"    textureCoordinate = inputTextureCoordinate;\n"
"}";
static const std::string gDefaultFrag = "#extension GL_OES_EGL_image_external : require\n"
"precision mediump float;\n"
"varying  vec2 textureCoordinate;\n"
"uniform sampler2D inputImageTexture;\n"
"void main()\n"
"{\n"
"     gl_FragColor = texture2D(inputImageTexture, textureCoordinate);\n"
"}\n"
;

GLInWork::GLInWork(const char* vertex, const char* frag, std::vector<GLBmp*> resouces, float defaultratio)
{
    mRatio = defaultratio;
    if (NULL == vertex)
    {
        vertex = gDefaultVertex.c_str();
    }
    GLASSERT(NULL!=frag);
    mProgram = new GLProgram(vertex, frag);
    mProgram->init();
    mResoucePos.clear();
    mResources.clear();
    for (int i=0; i<resouces.size(); ++i)
    {
        GLBmp* bmp = resouces[i];
        GPPtr<GLTexture> texture = new GLTexture();
        std::ostringstream os;
        os << "inputImageTexture";
        os << i + 2;
        texture->upload(bmp->pixels(), bmp->width(), bmp->height());
        mResources.push_back(texture);
        mResoucePos.push_back(glGetUniformLocation(mProgram->id(), os.str().c_str()));
        OPENGL_CHECK_ERROR;//Call opengl directly, must check error
    }
    mRatioPos = glGetUniformLocation(mProgram->id(), "filterRatio");
    /*If ratio not exist, don't set*/
    {
        GLenum error = glGetError();
        if (GL_NO_ERROR != error)
        {
            mRatioPos = -1;
        }
    }
    mFirstTexPos = glGetUniformLocation(mProgram->id(), "inputImageTexture");
    OPENGL_CHECK_ERROR;
}

GLInWork::~GLInWork()
{
}

void GLInWork::onSetupVertex(int w, int h)
{
}
void GLInWork::onSetupFragment(int w, int h)
{
    GLASSERT(mResoucePos.size() == mResources.size());
    for (int i=0; i<mResoucePos.size(); ++i)
    {
        GLTexture* t= mResources[i].get();
        int pos = mResoucePos[i];
        t->use(pos, i+1);
    }
    if (0 <= mRatioPos)
    {
        glUniform1f(mRatioPos, mRatio);
        OPENGL_CHECK_ERROR;
    }
}
void GLInWork::onDraw(GLTexture** src, int n, GLvboBuffer* vs, GLvboBuffer* ts)
{
    GLASSERT(NULL!=vs);
    GLASSERT(NULL!=ts);
    GLASSERT(NULL!=src);
    GLASSERT(1 == n);
    mProgram->use();
    auto w = src[0]->width();
    auto h = src[0]->height();
    this->onSetupVertex(w, h);
    this->onSetupFragment(w, h);
    src[0]->use(mFirstTexPos, 0);
    vs->use(mProgram->attr("position"));
    ts->use(mProgram->attr("inputTextureCoordinate"));
    ts->draw();
}
void GLInWork::release()
{
    mResources.clear();
    mResoucePos.clear();
}
void GLInWork::setDefaultVertexShader(const char* vertex)
{
    gDefaultVertex = vertex;
}

size_t GLInWork::vMap(double* parameters, size_t n)
{
    if (NULL == parameters)
    {
        return 1;
    }
    mRatio = parameters[0];
    return 1;
}
GLInWork* GLInWork::createDefault()
{
    std::vector<GLBmp*> resources;
    return new GLInWork(gDefaultVertex.c_str(), gDefaultFrag.c_str(), resources, 1.0f);
}
