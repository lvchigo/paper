#include "GL/GLShaderFactory.h"
#include "AllShader.h"
const char* GLShaderFactory::get(std::string name)
{
if(name =="ShallowTwoPass.vex") return glsl_ShallowTwoPass_vex.c_str();
if(name =="Shallow.vex") return glsl_Shallow_vex.c_str();
if(name =="Pastel.vex") return glsl_Pastel_vex.c_str();
if(name =="Timing.fra") return glsl_Timing_fra.c_str();
if(name =="Lemon.fra") return glsl_Lemon_fra.c_str();
if(name =="1937.fra") return glsl_1937_fra.c_str();
if(name =="Monroe.fra") return glsl_Monroe_fra.c_str();
if(name =="Meishi.fra") return glsl_Meishi_fra.c_str();
if(name =="xianliang.fra") return glsl_xianliang_fra.c_str();
if(name =="France.fra") return glsl_France_fra.c_str();
if(name =="Wine.fra") return glsl_Wine_fra.c_str();
if(name =="Nature.fra") return glsl_Nature_fra.c_str();
if(name =="Africa.fra") return glsl_Africa_fra.c_str();
if(name =="Trace.fra") return glsl_Trace_fra.c_str();
if(name =="Hills.fra") return glsl_Hills_fra.c_str();
if(name =="Fuji.fra") return glsl_Fuji_fra.c_str();
if(name =="Walking.fra") return glsl_Walking_fra.c_str();
if(name =="White.fra") return glsl_White_fra.c_str();
if(name =="guild_filter_slow_second.fra") return glsl_guild_filter_slow_second_fra.c_str();
if(name =="ShallowTwoPass.fra") return glsl_ShallowTwoPass_fra.c_str();
if(name =="Skin.fra") return glsl_Skin_fra.c_str();
if(name =="Film.fra") return glsl_Film_fra.c_str();
if(name =="Sweet.fra") return glsl_Sweet_fra.c_str();
if(name =="Acient.fra") return glsl_Acient_fra.c_str();
if(name =="Origin.fra") return glsl_Origin_fra.c_str();
if(name =="Danya.fra") return glsl_Danya_fra.c_str();
if(name =="Beauty.fra") return glsl_Beauty_fra.c_str();
if(name =="Lavender.fra") return glsl_Lavender_fra.c_str();
if(name =="Pastel.fra") return glsl_Pastel_fra.c_str();
if(name =="Morning.fra") return glsl_Morning_fra.c_str();
if(name =="Frozen.fra") return glsl_Frozen_fra.c_str();
if(name =="ImageWarping.fra") return glsl_ImageWarping_fra.c_str();
if(name =="Cool.fra") return glsl_Cool_fra.c_str();
if(name =="InstaLike.fra") return glsl_InstaLike_fra.c_str();
if(name =="Burma.fra") return glsl_Burma_fra.c_str();
if(name =="YouYa.fra") return glsl_YouYa_fra.c_str();
if(name =="Meifu.fra") return glsl_Meifu_fra.c_str();
if(name =="Pooling.fra") return glsl_Pooling_fra.c_str();
if(name =="Shallow.fra") return glsl_Shallow_fra.c_str();
if(name =="guild_filter_slow_b.fra") return glsl_guild_filter_slow_b_fra.c_str();
if(name =="Forest.fra") return glsl_Forest_fra.c_str();
if(name =="guild_filter_slow_a.fra") return glsl_guild_filter_slow_a_fra.c_str();
if(name =="LookUp.fra") return glsl_LookUp_fra.c_str();
if(name =="Xinchao.fra") return glsl_Xinchao_fra.c_str();
if(name =="Child.fra") return glsl_Child_fra.c_str();
return NULL;
}
