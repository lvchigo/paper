#include "IGLDrawWork.h"
#include "GLInWorkFactory.h"
#include "GLDrawWork.h"
#include "GLTreeDrawWork.h"
#include "GLShaderFactory.h"
#include "GLAutoStorage.h"
#include <map>
#include <string>
using namespace std;
static float gDefaultThetha = 0.005;
class GLGuildFilterGLWork:public IGLDrawWork
{
public:
    GLGuildFilterGLWork(float ratio)
    {
        map<string, float> p_uniform;
        map<string, float> c_uniform;
        p_uniform["texelWidth"] = 0.01;
        p_uniform["texelHeight"] = 0.01;
        p_uniform["filterRatio"] = 0.80;
        
        c_uniform["texelWidth"] = 0.01;
        c_uniform["texelHeight"] = 0.01;
        c_uniform["thetha"] = gDefaultThetha;
        GPPtr<IGLDrawWork> p = new GLDrawWork(GLShaderFactory::get("ShallowTwoPass.vex"), GLShaderFactory::get("guild_filter_slow_second.fra"), &p_uniform, NULL, 3);
        mP = (GLDrawWork*)(p.get());
        GPPtr<IGLDrawWork> l = new GLDrawWork(GLShaderFactory::get("ShallowTwoPass.vex"), GLShaderFactory::get("guild_filter_slow_a.fra"), &c_uniform);
        mL = (GLDrawWork*)(l.get());
        GPPtr<IGLDrawWork> r = new GLDrawWork(GLShaderFactory::get("ShallowTwoPass.vex"), GLShaderFactory::get("guild_filter_slow_b.fra"), &c_uniform);
        mR = (GLDrawWork*)(r.get());
        GLTreeDrawWork* tp = new GLTreeDrawWork(p);
        GPPtr<GLTreeDrawWork> lp = new GLTreeDrawWork(l);
        GPPtr<GLTreeDrawWork> rp = new GLTreeDrawWork(r);
        tp->addNode(NULL);
        tp->addNode(lp);
        tp->addNode(rp);
        mBasic = tp;
        mRatio = ratio;
    }
    virtual ~GLGuildFilterGLWork()
    {
        
    }
    virtual void onDraw(GLTexture** src, int n, GLvboBuffer* vs, GLvboBuffer* ts)
    {
        GLASSERT(1 == n);
        GLASSERT(NULL!=src);
        GLASSERT(NULL!=src[0]);
        GLASSERT(NULL!=vs);
        GLASSERT(NULL!=ts);
        auto w = src[0]->width();
        auto h = src[0]->height();
        mL->setUniform("texelWidth", 1.0/w);
        mL->setUniform("texelHeight", 1.0/h);
        mR->setUniform("texelWidth", 1.0/w);
        mR->setUniform("texelHeight", 1.0/h);
        mP->setUniform("texelWidth", 1.0/w);
        mP->setUniform("texelHeight", 1.0/h);
        mP->setUniform("filterRatio", mRatio);
        mBasic->onDraw(src, n, vs, ts);
    }
    
    /*All parameters is in [0,1), set self parameters by these, if parameters is NULL, don't do anything just return the number of parameters needed*/
    virtual size_t vMap(double* parameters, size_t n)
    {
        if (NULL == parameters)
        {
            return 1;
        }
        mRatio = parameters[0];
        return 1;
    }
    
private:
    GPPtr<GLTreeDrawWork> mBasic;
    GLDrawWork* mP;
    GLDrawWork* mL;
    GLDrawWork* mR;
    float mRatio;
};


class GuildFilterCreator:public GLInWorkCreator
{
public:
    virtual IGLDrawWork* vCreate(GLInWorkResource* r) const
    {
        return new GLGuildFilterGLWork(r->ratio);
    }
};
static GLInWorkCreatorRegister<GuildFilterCreator> __T2("Shallow",false);
