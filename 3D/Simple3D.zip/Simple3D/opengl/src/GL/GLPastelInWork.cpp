#include "GL/GLPastelInWork.h"
#include "GL/GLInWorkFactory.h"
GLPastelInWork::GLPastelInWork(const char* vertex, const char* frag, std::vector<GLBmp*> resources, float defaultratio):GLInWork(vertex, frag, resources, defaultratio)
{
    mWidthPos = glGetUniformLocation(getProgramId(), "texelWidth");
    OPENGL_CHECK_ERROR;
    GLASSERT(-1!=mWidthPos);
    mHeightPos = glGetUniformLocation(getProgramId(), "texelHeight");
    OPENGL_CHECK_ERROR;
    GLASSERT(-1!=mHeightPos);
}


GLPastelInWork::~GLPastelInWork()
{
}
void GLPastelInWork::onSetupVertex(int w, int h)
{
    glUniform1f(mWidthPos, 1.0/(float)w);
    OPENGL_CHECK_ERROR;
    glUniform1f(mHeightPos, 1.0/(float)h);
    OPENGL_CHECK_ERROR;
}

class GLPastelInWorkCreator:public GLInWorkCreator
{
    public:
        //Create BitmapWork
        virtual IGLDrawWork* vCreate(GLInWorkResource* r) const
        {
            return new GLPastelInWork(r->vertex, r->frag, r->resources, r->ratio);
        }
};

static GLInWorkCreatorRegister<GLPastelInWorkCreator> __T("Pastel");
