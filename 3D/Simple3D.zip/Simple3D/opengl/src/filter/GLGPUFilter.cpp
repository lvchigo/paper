#include "filter/GLGPUFilter.h"
#include "GLAutoFbo.h"

GLGPUFilter::GLGPUFilter(GPPtr<IGLDrawWork> w, const float* vs, const float* ts)
{
    mWork = w;
    mSrc = new GLTexture;
    mDst = new GLTexture;
    mVs = new GLvboBuffer(vs, 2, 4, GL_TRIANGLE_STRIP);
    mTs = new GLvboBuffer(ts, 2, 4, GL_TRIANGLE_STRIP);
}
GLGPUFilter::GLGPUFilter(GPPtr<IGLDrawWork> w, GPPtr<GLvboBuffer> vs, GPPtr<GLvboBuffer> ts)
{
    mWork = w;
    mSrc = new GLTexture;
    mDst = new GLTexture;
    mVs = vs;
    mTs = ts;
}
GLGPUFilter::~GLGPUFilter()
{
}
void GLGPUFilter::vFilter(GLBmp* dst, const GLBmp* src) const
{
    GLASSERT(NULL!=dst);
    GLASSERT(NULL!=src);
    mSrc->setFilter(true);
    mSrc->upload(src->pixels(), src->width(), src->height());
    mDst->upload(NULL, dst->width(), dst->height());
    GLAutoFbo __fbo(*(mDst.get()));
    GLTexture* pSrc = mSrc.get();
    mWork->onDraw(&pSrc, 1, mVs.get(), mTs.get());
    mDst->download(dst->pixels());
}

size_t GLGPUFilter::vMap(double* parameters, size_t n)
{
    return mWork->vMap(parameters, n);
}
