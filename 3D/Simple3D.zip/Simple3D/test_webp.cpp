#include "Decryptor.h"
#include "core/GLBitmapFactory.h"
#include "utils/GLDebug.h"
#include "core/GLGrayBitmap.h"
#include <vector>
#include "algorithm/GLRegions.h"
#include "algorithm/GLScale.h"
#include "sift.h"
#include "GLAutoStorage.h"
#include "algorithm/GLLinearRegressor.h"
#include <iostream>
#include <random>
#include "algorithm/GLGraphicCut.h"
#include "filter/GLSharpFilter.h"
#include "core/GLBitmapFactory.h"
#include "encode.h"
#include "decode.h"
#include "GLStream.h"
using namespace std;

static int stream_writer(const uint8_t* data, size_t data_size,
                         const WebPPicture* const picture) {
    GLWStream* stream = (GLWStream*)picture->custom_ptr;
    size_t s = stream->vWrite(data, data_size);
    if (s > 0)
    {
        return 1;
    }
    return 0;
}

static const size_t WEBP_VP8_HEADER_SIZE = 64;
static const size_t WEBP_IDECODE_BUFFER_SZ = (1 << 16);

// Parse headers of RIFF container, and check for valid Webp (VP8) content.
static bool webp_parse_header(GLStream* stream, int* width, int* height, int* alpha) {
    unsigned char buffer[WEBP_VP8_HEADER_SIZE];
    size_t bytesToRead = WEBP_VP8_HEADER_SIZE;
    size_t totalBytesRead = 0;
    do {
        unsigned char* dst = buffer + totalBytesRead;
        const size_t bytesRead = stream->vRead(dst, bytesToRead);
        if (0 == bytesRead) {
            // Could not read any bytes. Check to see if we are at the end (exit
            // condition), and continue reading if not. Important for streams
            // that do not have all the data ready.
            continue;
        }
        bytesToRead -= bytesRead;
        totalBytesRead += bytesRead;
        GLASSERT(bytesToRead + totalBytesRead == WEBP_VP8_HEADER_SIZE);
    } while (!stream->vIsEnd() && bytesToRead > 0);
    
    WebPBitstreamFeatures features;
    VP8StatusCode status = WebPGetFeatures(buffer, totalBytesRead, &features);
    if (VP8_STATUS_OK != status) {
        return false; // Invalid WebP file.
    }
    *width = features.width;
    *height = features.height;
    *alpha = features.has_alpha;
    return true;
}

static bool webp_idecode(GLStream* stream, WebPDecoderConfig* config) {
    WebPIDecoder* idec = WebPIDecode(NULL, 0, config);
    if (NULL == idec) {
        WebPFreeDecBuffer(&config->output);
        return false;
    }
    if (!stream->vRewind())
    {
        GLASSERT(0);
    }
    const size_t readBufferSize = 4096;
    GLAUTOSTORAGE(input, unsigned char, readBufferSize);
    if (NULL == input) {
        WebPIDelete(idec);
        WebPFreeDecBuffer(&config->output);
        return false;
    }
    bool success = true;
    VP8StatusCode status = VP8_STATUS_SUSPENDED;
    do {
        const size_t bytesRead = stream->vRead(input, readBufferSize);
        if (0 == bytesRead) {
            success = false;
            break;
        }
        
        status = WebPIAppend(idec, input, bytesRead);
        if (VP8_STATUS_OK != status && VP8_STATUS_SUSPENDED != status) {
            success = false;
            break;
        }
    } while (VP8_STATUS_OK != status);
    WebPIDelete(idec);
    WebPFreeDecBuffer(&config->output);
    
    return success;
}


int encodeForWebp(const GLBmp* origin, GLWStream* writeStream, int quality)
{
    WebPConfig webp_config;
    if (!WebPConfigPreset(&webp_config, WEBP_PRESET_DEFAULT, (float) quality)) {
        return false;
    }
    
    WebPPicture pic;
    WebPPictureInit(&pic);
    pic.width = origin->width();
    pic.height = origin->height();
    pic.writer = stream_writer;
    pic.custom_ptr = (void*)(writeStream);
    
    const uint8_t* src = origin->getAddr(0, 0);
    WebPPictureImportRGBA(&pic, src, origin->stride());
    
    WebPEncode(&webp_config, &pic);
    WebPPictureFree(&pic);
    return 0;
}

GPPtr<GLBmp> decodeFromWebp(GLStream* stream)
{
    int origWidth, origHeight, hasAlpha;
    if (!webp_parse_header(stream, &origWidth, &origHeight, &hasAlpha)) {
        return NULL;
    }
    if (!hasAlpha)
    {
        GLASSERT(0);
    }
    GPPtr<GLBmp> decodedBitmap = new GLBmp(origWidth, origHeight);
    
    WebPDecoderConfig configs;
    WebPDecoderConfig* config = &configs;
    WEBP_CSP_MODE mode = MODE_RGBA;
    if (0 == WebPInitDecoderConfig(config)) {
        return NULL;
    }
    
    config->output.colorspace = mode;
    config->output.u.RGBA.rgba = decodedBitmap->getAddr(0, 0);
    config->output.u.RGBA.stride = decodedBitmap->stride();
    config->output.u.RGBA.size = decodedBitmap->stride()*decodedBitmap->height();
    config->output.is_external_memory = 1;
    // Decode the WebP image data stream using WebP incremental decoding.
    webp_idecode(stream, config);
    return decodedBitmap;
}


int main(int argc, char* argv[])
{
    GPPtr<GLBmp> origin = GLBitmapFactory::create("/Users/jiangxiaotang/InWork/incameraengineandroid/Simple3D/input.png");
    GPPtr<GLWStream> writeStream = GLStreamFactory::writeForFile("/Users/jiangxiaotang/InWork/incameraengineandroid/Simple3D/input.webp");
    encodeForWebp(origin.get(), writeStream.get(), 100);
    writeStream = NULL;
    GPPtr<GLStream> readStream = GLStreamFactory::readFromFile("/Users/jiangxiaotang/InWork/incameraengineandroid/Simple3D/input.webp");
    GPPtr<GLBmp> newBmp = decodeFromWebp(readStream.get());
    GLBitmapFactory::dump(newBmp.get(), "/Users/jiangxiaotang/InWork/incameraengineandroid/Simple3D/webptest.png");
    return 1;
}
