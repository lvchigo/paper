//
//  BigHeadJni.cpp
//  simple3d
//
//  Created by jiangxiaotang on 15/9/1.
//  Copyright (c) 2015年 jiangxiaotang. All rights reserved.
//

#include "BigHeadJni.h"

#include "utils/GLLock.h"
#include "utils/GLDefer.h"
#include "BigHeaderManager.h"
#include <map>
#include "jniutils/FormatConvert.h"
#include "jniutils/JniBitmap.h"

using namespace std;
static map<long, BigHeaderManager*> gManagers;
static GLLock gJniLock;
static long gInstanceNum = 0;

jlong Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHNewInstance(JNIEnv* env, jclass cls)
{
    GLAutoLock _l(gJniLock);
    long res = gInstanceNum++;
    gManagers.insert(make_pair(res, new BigHeaderManager));
    return res;
}
void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHReleaseInstance(JNIEnv* env, jclass cls, jlong instance)
{
    GLAutoLock _l(gJniLock);
    if (gManagers.end() == gManagers.find(instance))
    {
        return;
    }
    auto iter = gManagers.find(instance);
    delete iter->second;
    gManagers.erase(iter);
}
jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHSetUpOriginBitmap(JNIEnv* env, jclass cls, jlong instance, jobject origin)
{
    GPCLOCK;
    BigHeaderManager* manager = NULL;
    GLAutoLock _l(gJniLock);
    {
        auto iter = gManagers.find(instance);
        if (iter != gManagers.end())
        {
            manager = iter->second;
        }
    }
    if (NULL == manager)
    {
        return 0;
    }
    AndroidBitmapInfo info;
    info.format = ANDROID_BITMAP_FORMAT_NONE;
    AndroidBitmap_getInfo(env, origin, &info);
    GLASSERT(info.format!=ANDROID_BITMAP_FORMAT_NONE);
    GPPtr<GLBmp> origin_bitmap = new GLBmp(info.width, info.height);
    GLConvertToARGB((unsigned char*)(origin_bitmap->pixels()), 0, 0, info.width-1, info.height-1, info.width*4, env, origin);
    manager->setBitmap(origin_bitmap);
    return 0;
}
jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHAddNewMask(JNIEnv* env, jclass cls, jlong instance, jobject gray_seed, jobject gray_mask, jint left, jint top, jint right, jint bottom, jint max_computeArea)
{
    GPCLOCK;
    GLASSERT(left<=right);
    GLASSERT(top<=bottom);
    BigHeaderManager* manager = NULL;
    {
        GLAutoLock _l(gJniLock);
        auto iter = gManagers.find(instance);
        if (iter != gManagers.end())
        {
            manager = iter->second;
        }
    }
    if (NULL == manager)
    {
        return 0;
    }
    JniBitmap jgray_seed(env, gray_seed);
    JniBitmap jgray_mask(env, gray_mask);
    GLASSERT(jgray_mask.info().format == ANDROID_BITMAP_FORMAT_A_8);
    GLASSERT(jgray_seed.info().format == ANDROID_BITMAP_FORMAT_A_8);
    int w = jgray_seed.info().width;
    int h = jgray_seed.info().height;
    GLASSERT(w == jgray_mask.info().width);
    GLASSERT(h == jgray_mask.info().height);
    left = left>=0?left:0;
    right = right<w?right:w-1;
    top = top>=0?top:0;
    bottom = bottom<h?bottom:h-1;
    GPPtr<GLGrayBitmap> gray_seed_bitmap = jgray_seed.turnGray();
    GPPtr<GLGrayBitmap> gray_mask_bitmap = jgray_mask.turnGray();
    GLRect rect;
    rect.l = left;
    rect.r = right;
    rect.t = top;
    rect.b = bottom;
    //GraphicCut with mask
    bool success = manager->addNewMask(gray_seed_bitmap.get(), gray_mask_bitmap.get(), rect, max_computeArea);
    if (!success)
    {
        return 0;
    }
    return 1;
}



jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHReduceRegion(JNIEnv* env, jclass cls, jlong instance, jobject gray_mask)
{
    GPCLOCK;
    BigHeaderManager* manager = NULL;
    {
        GLAutoLock _l(gJniLock);
        auto iter = gManagers.find(instance);
        if (iter != gManagers.end())
        {
            manager = iter->second;
        }
    }
    if (NULL == manager)
    {
        return 0;
    }
    JniBitmap jgray_mask(env, gray_mask);
    GPPtr<GLGrayBitmap> gl_gray_mask = jgray_mask.turnGray();
    BigHeaderManager::reduceToOneRegion(gl_gray_mask.get());
    return 0;
}

jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHMeasure(JNIEnv* env, jclass cls, jlong instance, jobject gray_mask, jintArray bounds)
{
    GLASSERT(4 <= env->GetArrayLength(bounds));
    auto _bounds = env->GetIntArrayElements(bounds, NULL);
    GLDefer([&]{
        env->ReleaseIntArrayElements(bounds, _bounds, 0);
    });
    JniBitmap jgray_mask(env, gray_mask);
    GLASSERT(jgray_mask.info().format == ANDROID_BITMAP_FORMAT_A_8);
    GPPtr<GLGrayBitmap> gl_gray_mask = jgray_mask.turnGray();
//    auto r = BigHeaderManager::reduceToOneRegion(&gl_grey_mask);
//    auto r1 = BigHeaderManager::reduceToOneRegion(&gl_grey_mask);
//    BigHeaderManager::addRegionBounder(&gl_grey_mask, r1, 50);
    auto r = BigHeaderManager::getBound(gl_gray_mask.get());
    _bounds[0] = r.l;
    _bounds[1] = r.t;
    _bounds[2] = r.r;
    _bounds[3] = r.b;
    return 0;
}

jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHCropByMask(JNIEnv* env, jclass cls, jlong instance, jobject gray_mask, jobject dst, jint l, jint t)
{
    JniBitmap jgray_mask(env, gray_mask);
    GLASSERT(jgray_mask.info().format == ANDROID_BITMAP_FORMAT_A_8);
    JniBitmap jdst(env, dst);
    GLASSERT(jdst.info().format == ANDROID_BITMAP_FORMAT_RGBA_8888);
    GPPtr<GLGrayBitmap> gl_gray_mask = jgray_mask.turnGray();
    GPPtr<GLBmp> gl_dst = jdst.turnARGB();
    BigHeaderManager* manager = NULL;
    {
        GLAutoLock _l(gJniLock);
        auto iter = gManagers.find(instance);
        if (iter != gManagers.end())
        {
            manager = iter->second;
        }
    }
    if (NULL == manager)
    {
        return 0;
    }
    manager->crop(gl_dst.get(), gl_gray_mask.get(), l, t);
    return 0;
}


jintArray Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHGetMaskBounderOffsetPoints(JNIEnv* env, jclass cls, jlong instance, jobject gray_mask, jint l, jint t, jint r, jint b, jint length, jint interval, jint thredhold, jint pixelThredhold)
{
    GLRect rect;
    rect.l = l; rect.r = r; rect.t = t; rect.b = b;
    JniBitmap _gray(env, gray_mask);
    GPPtr<GLGrayBitmap> _jgray = _gray.turnGray();
    GPPtr<GLMatrix<int>> resultMatrix;
    resultMatrix = BigHeaderManager::getBoundAxis(_jgray.get(), rect, length,  interval, thredhold, pixelThredhold);
    if (NULL == resultMatrix.get())
    {
        jintArray result = env->NewIntArray(2);
        int* _result = env->GetIntArrayElements(result, NULL);
        _result[0] = 0;
        _result[1] = 0;
        env->ReleaseIntArrayElements(result, _result, 0);
        return result;
    }
    GLASSERT(NULL!=resultMatrix.get());
    GLASSERT(2 == resultMatrix->height());
    int w = resultMatrix->width();
    jintArray result = env->NewIntArray(w*2);
    auto x = resultMatrix->getAddr(0);
    auto y = resultMatrix->getAddr(1);
    int* _result = env->GetIntArrayElements(result, NULL);
    for (int i=0; i<w; ++i)
    {
        _result[i*2] = x[i];
        _result[i*2+1] = y[i];
    }
    env->ReleaseIntArrayElements(result, _result, 0);
    return result;
}

jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHEclosion(JNIEnv* env, jclass cls, jlong instance, jobject gray_mask)
{
    JniBitmap _gray(env, gray_mask);
    GPPtr<GLGrayBitmap> _jgray = _gray.turnGray();
    BigHeaderManager::eclosion(_jgray.get());
    return 0;
}


jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHSkinDetect(JNIEnv* env, jclass cls, jlong instance, jobject gray, jint skin, jint nonskin)
{
    BigHeaderManager* manager = NULL;
    {
        GLAutoLock _l(gJniLock);
        auto iter = gManagers.find(instance);
        if (iter != gManagers.end())
        {
            manager = iter->second;
        }
    }
    if (NULL == manager)
    {
        return 0;
    }
    JniBitmap _gray(env, gray);
    GPPtr<GLGrayBitmap> _jgray = _gray.turnGray();
    manager->skinDetect(_jgray.get(), skin, nonskin);
    return 1;
}


jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHAddNewMaskConnected(JNIEnv* env, jclass cls, jlong instance, jobject gray_seed, jobject gray_mask, jint left, jint top, jint right, jint bottom, jint max_computeArea)
{
    BigHeaderManager* manager = NULL;
    {
        GLAutoLock _l(gJniLock);
        auto iter = gManagers.find(instance);
        if (iter != gManagers.end())
        {
            manager = iter->second;
        }
    }
    if (NULL == manager)
    {
        return 0;
    }
    JniBitmap jgray_seed(env, gray_seed);
    JniBitmap jgray_mask(env, gray_mask);
    GLASSERT(jgray_mask.info().format == ANDROID_BITMAP_FORMAT_A_8);
    GLASSERT(jgray_seed.info().format == ANDROID_BITMAP_FORMAT_A_8);
    int w = jgray_seed.info().width;
    int h = jgray_seed.info().height;
    GLASSERT(w == jgray_mask.info().width);
    GLASSERT(h == jgray_mask.info().height);
    left = left>=0?left:0;
    right = right<w?right:w-1;
    top = top>=0?top:0;
    bottom = bottom<h?bottom:h-1;
    GPPtr<GLGrayBitmap> gray_seed_bitmap = jgray_seed.turnGray();
    GPPtr<GLGrayBitmap> gray_mask_bitmap = jgray_mask.turnGray();
    GLRect rect;
    rect.l = left;
    rect.r = right;
    rect.t = top;
    rect.b = bottom;
    //GraphicCut with mask
    manager->addNewMaskConnected(gray_seed_bitmap.get(), gray_mask_bitmap.get(), rect, max_computeArea);
    return 0;
}


jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHFillInterval(JNIEnv* env, jclass cls, jlong instance, jobject dstBitmap)
{
    JniBitmap jni_dst(env, dstBitmap);
    GLASSERT(jni_dst.info().format == ANDROID_BITMAP_FORMAT_A_8);
    GPPtr<GLGrayBitmap> dst = jni_dst.turnGray();
    BigHeaderManager::fillHole(dst.get());
    return 0;
}

