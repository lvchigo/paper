#ifndef IMAGEPROCJNI_H
#define IMAGEPROCJNI_H
#include <jni.h>
extern "C"{
    jfloatArray Java_com_jiuyan_infashion_imagefilter_util_FilterJni_ImageProcRegistration(JNIEnv* env, jclass cls, jobject dst, jobject src);
    void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_ImageProcMergeBitmap(JNIEnv* env, jclass cls, jobject dst, jobject src, jobject mask, jint xoffset, jint yoffset);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_ImageProcGetMeanWidth(JNIEnv* env, jclass cls, jobject mask, jfloat rate);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_ImageProcRunFilter(JNIEnv* env, jclass cls, jobject dst, jobject src, jstring name, jfloat rate);
    jstring Java_com_jiuyan_infashion_imagefilter_util_FilterJni_ImageProcGetFilterNames(JNIEnv* env, jclass cls);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_ImageProcMorphing(JNIEnv* env, jclass cls, jobject dst, jint l, jint t, jint w, jint h, jint mx, jint my);
}
#endif
