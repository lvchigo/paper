#ifndef GIFJNI_H
#define GIFJNI_H
#include <jni.h>
extern "C"{
    jlong Java_com_jiuyan_infashion_imagefilter_util_FilterJni_MovieStartEncode(JNIEnv* env, jclass cls, jobject bitmap, jobject output, jbyteArray array, jint frames);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_MovieAddBitmap(JNIEnv* env, jclass cls, jlong instance, jobject bitmap, jint l, jint t);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_MovieEndEncode(JNIEnv* env, jclass cls, jlong instance);

    jlong Java_com_jiuyan_infashion_imagefilter_util_FilterJni_MovieDecode(JNIEnv* env, jclass cls, jobject inputStream, jbyteArray cache);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_MovieRelease(JNIEnv* env, jclass cls, jlong instance);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_MovieGetInfo(JNIEnv* env, jclass cls, jlong instance, jintArray infos);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_MovieRender(JNIEnv* env, jclass cls, jlong instance, jobject dstBitmap, jint n, jboolean renderdirty);
}
#endif
