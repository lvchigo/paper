#include "JniString.h"
JniString::JniString(JNIEnv* env, jstring origin)
{
    const char* ver = env->GetStringUTFChars(origin, NULL);
    mOutput = ver;
    mOrigin = origin;
    mEnv = env;
}
JniString::~JniString()
{
    mEnv->ReleaseStringUTFChars(mOrigin, mOutput);
}
