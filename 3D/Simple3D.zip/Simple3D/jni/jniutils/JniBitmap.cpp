//
//  JniBitmap.cpp
//  simple3d
//
//  Created by jiangxiaotang on 15/9/25.
//  Copyright (c) 2015年 jiangxiaotang. All rights reserved.
//

#include "JniBitmap.h"
#include "utils/GLDebug.h"
JniBitmap::JniBitmap(JNIEnv* env, jobject bitmap)
{
    mInfo.format = ANDROID_BITMAP_FORMAT_NONE;
    AndroidBitmap_getInfo(env, bitmap, &mInfo);
    mPixels = NULL;
    AndroidBitmap_lockPixels(env, bitmap, &mPixels);
    GLASSERT(NULL!=mPixels);
    mBitmap = bitmap;
    mEnv = env;
}
JniBitmap::~JniBitmap()
{
    AndroidBitmap_unlockPixels(mEnv, mBitmap);
}
GPPtr<GLGrayBitmap> JniBitmap::turnGray() const
{
    GLASSERT(mInfo.format == ANDROID_BITMAP_FORMAT_A_8);
    return new GLGrayBitmap(mInfo.width, mInfo.height, mInfo.stride, (unsigned char*)mPixels);
}
GPPtr<GLBmp> JniBitmap::turnARGB() const
{
    GLASSERT(mInfo.format == ANDROID_BITMAP_FORMAT_RGBA_8888);
    return new GLBmp(mInfo.width, mInfo.height, mPixels, mInfo.stride);
}

