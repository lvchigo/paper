#ifndef JNIUTILS_JNISTRING_H
#define JNIUTILS_JNISTRING_H
#include <jni.h>
#include <string.h>
class JniString
{
    public:
        JniString(JNIEnv* env, jstring origin);
        ~JniString();
        const char* get() const {return mOutput;}
    private:
        JNIEnv* mEnv;
        jstring mOrigin;
        const char* mOutput;
};
#define JNISTRING(x, f, e) JniString __##x(e, f); const char* x = __##x.get();
#endif
