#ifndef JNIUTILS_JNIENV_H
#define JNIUTILS_JNIENV_H
#include <jni.h>
jint JNI_OnLoad(JavaVM* vm, void *reserved);
#endif
