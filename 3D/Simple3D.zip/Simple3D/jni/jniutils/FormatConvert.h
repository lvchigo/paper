#ifndef JNI_FORMATCONVERT_H
#define JNI_FORMATCONVERT_H
#include <android/bitmap.h>
#include <jni.h>
#include "core/GLBmp.h"

void convertToRGBA(unsigned char* yuv, int w, int h, int format, int* rgba);
void rotateYUV(unsigned char* output, unsigned char* input, int w, int h, bool swapxy, bool flipH, bool flipV);

void GLConvertToARGB(unsigned char* dst, int l, int t, int r, int b, int dststride, JNIEnv* env, jobject src_bitmap);

GLBmp* GLConvert(JNIEnv* env, jobject bitmap);
void RGBAToYUV(const GLBmp* src, unsigned char* yuv, int outputformat);
void YUVToRGB(const GLBmp* dstBitmap, unsigned char* yuv, int yuvformat);
#endif
