#include "FormatConvert.h"
#include "utils/GLDebug.h"
#include "utils/GLDefer.h"
#include "utils/GLAutoStorage.h"
#include "utils/GP_Clock.h"
#include "JniBitmap.h"
#ifdef HAS_NEON
#include <arm_neon.h>
#endif
static const int g_argb_bpp = 4;
//convert uint16_t rgb565 pixel to int value
#define RGB565_R(p) ((((p) & 0xF800) >> 11) << 3)
#define RGB565_G(p) ((((p) & 0x7E0 ) >> 5)  << 2)
#define RGB565_B(p) ( ((p) & 0x1F  )        << 3)
#define MAKE_RGB565(r,g,b) ((((r) >> 3) << 11) | (((g) >> 2) << 5) | ((b) >> 3))
//convert uint32_t rgba8888 pixel to int value
#define RGBA8888_A(p) (((p) & 0xFF000000) >> 24)
#define RGBA8888_R(p) (((p) & 0x00FF0000) >> 16)
#define RGBA8888_G(p) (((p) & 0x0000FF00) >>  8)
#define RGBA8888_B(p)  ((p) & 0x000000FF)
#define MAKE_RGBA8888(r,g,b,a) (((a) << 24) | ((r) << 16) | ((g) << 8) | (b))
//convert uint16_t rgba4444 pixel to int value
#define RGBA4444_R(p) ((((p) & 0xF000) >> 12) << 4)
#define RGBA4444_G(p) ((((p) & 0x0F00) >> 8) << 4)
#define RGBA4444_B(p) ((((p) & 0x00F0) >> 4) << 4)
#define RGBA4444_A(p) ( ((p) & 0x000F) << 4)

static void _rgba_2_rgba(unsigned char* dst, unsigned char* src, int count)
{
    ::memcpy(dst, src, count*g_argb_bpp*sizeof(unsigned char));
}
static void _rgb565_2_rgba(unsigned char* dst, unsigned char* src, int count)
{
    int sta = 0;
    unsigned short* src_s = (unsigned short*)src;
    for (int j=sta; j<count; ++j)
    {
        unsigned short rgb565 = src_s[j];
        dst[3] = 0xFF;
        dst[0] = RGB565_R(rgb565);
        dst[1] = RGB565_G(rgb565);
        dst[2] = RGB565_B(rgb565);
        dst+=g_argb_bpp;
    }
}
static void _rgba4444_2_rgba(unsigned char* dst, unsigned char* src, int count)
{
    int sta = 0;
    unsigned short* src_s = (unsigned short*)src;
    for (int j=sta; j<count; ++j)
    {
        unsigned short rgb = src_s[j];
        dst[3] = RGBA4444_A(rgb);
        dst[0] = RGBA4444_R(rgb);
        dst[1] = RGBA4444_G(rgb);
        dst[2] = RGBA4444_B(rgb);
        dst+=g_argb_bpp;
    }
}
static void _a8_2_rgba(unsigned char* dst, unsigned char* src, int count)
{
    int sta = 0;
    for (int i=sta; i<count; ++i)
    {
        ::memset(dst+i*g_argb_bpp, src[i], g_argb_bpp);
    }
}

void GLConvertToARGB(unsigned char* dst, int l, int t, int r, int b, int dststride, JNIEnv* env, jobject src_bitmap)
{
    GLASSERT(0<=l && 0<=t);
    GLASSERT(l<=r && t<=b);
    GLASSERT(dststride >= r);
    AndroidBitmapInfo info;
    info.format = ANDROID_BITMAP_FORMAT_NONE;
    AndroidBitmap_getInfo(env, src_bitmap, &info);
    GLASSERT(info.width > r);
    GLASSERT(info.height > b);
    void(*proc)(unsigned char* dst, unsigned char* src, int count) = NULL;
    switch (info.format)
    {
        case ANDROID_BITMAP_FORMAT_RGBA_8888:
            proc = _rgba_2_rgba;
            break;
        case ANDROID_BITMAP_FORMAT_RGB_565:
            proc = _rgb565_2_rgba;
            break;
        case ANDROID_BITMAP_FORMAT_RGBA_4444:
            proc = _rgba4444_2_rgba;
            break;
        case ANDROID_BITMAP_FORMAT_A_8:
            proc = _a8_2_rgba;
            break;
        default:
            break;
    }
    if (NULL == proc)
    {
        return;
    }
    void* pixels = NULL;
    AndroidBitmap_lockPixels(env, src_bitmap, &pixels);
    if (NULL == pixels)
    {
        return;
    }
    GLDefer([&](){
        AndroidBitmap_unlockPixels(env, src_bitmap);
    });
    unsigned char* src = (unsigned char*)pixels;
    int src_bpp = info.stride/info.width;
    int count = r-l+1;
    for (int i=t; i<=b; ++i)
    {
        proc(dst+i*dststride+l*g_argb_bpp, src+i*info.stride+l*src_bpp, count);
    }
}

void convertToRGBA(unsigned char* yuv, int w, int h, int format, int* rgba)
{
    GLASSERT(17 == format);
    FUNC_PRINT(w);
    FUNC_PRINT(h);
    for (int i=0; i<h; ++i)
    {
        unsigned char* dst = (unsigned char*)(rgba + w*i);
        unsigned char* y = yuv + w*i;
        unsigned char* uv = yuv + w*h + w*(i/2);
        int count = w;

#ifdef HAS_NEON
        int c = count/16;
        asm volatile(
                "mov r4, %[c]\t\n"
                "beq 2f\t\n"
                "vmov.u8 d7, #255\t\n"//Alpha
                "vmov.u8 d3, #255\t\n"//Alpha
                "vmov.s16 q11, #90\t\n"
                "vmov.s16 q12, #128\t\n"
                "vmov.s16 q13, #22\t\n"
                "vmov.s16 q14, #46\t\n"
                "vmov.s16 q15, #113\t\n"
                "1:\t\n"
                "vld2.8 {d8, d9}, [%[y]]!\t\n"//Y1, Y2
                "vld2.8 {d0, d1}, [%[uv]]!\t\n"//u, v
                "vmovl.u8  q5, d0\t\n"
                "vmovl.u8  q6, d1\t\n"
                "vsub.i16 q5,q5, q12\t\n"
                "vsub.i16 q6,q6, q12\t\n"
                //First RGBA
                "vshll.u8 q7, d8, #6\t\n"
                "vshll.u8 q8, d8, #6\t\n"
                "vshll.u8 q9, d8, #6\t\n"
                "vmla.i16 q7, q6, q11\t\n"
                "vmls.i16 q8, q5, q13\t\n"
                "vmls.i16 q8, q6, q14\t\n"
                "vmla.i16 q9, q5, q15\t\n"

                "vshr.s16 q7, q7, #6\t\n"
                "vshr.s16 q8, q8, #6\t\n"
                "vshr.s16 q9, q9, #6\t\n"
                "vmov.s16 q10, #0\t\n"
                "vmax.s16 q7, q7, q10\t\n"
                "vmax.s16 q8, q8, q10\t\n"
                "vmax.s16 q9, q9, q10\t\n"
                "vmov.u16 q10, #255\t\n"
                "vmin.u16 q7, q7, q10\t\n"
                "vmin.u16 q8, q8, q10\t\n"
                "vmin.u16 q9, q9, q10\t\n"
                "vmovn.s16 d2, q7\t\n"
                "vmovn.s16 d1, q8\t\n"
                "vmovn.s16 d0, q9\t\n"

                //Second RGBA
                "vshll.u8 q7, d9, #6\t\n"
                "vshll.u8 q8, d9, #6\t\n"
                "vshll.u8 q9, d9, #6\t\n"
                "vmla.i16 q7, q6, q11\t\n"
                "vmls.i16 q8, q5, q13\t\n"
                "vmls.i16 q8, q6, q14\t\n"
                "vmla.i16 q9, q5, q15\t\n"
                "vshr.s16 q7, q7, #6\t\n"
                "vshr.s16 q8, q8, #6\t\n"
                "vshr.s16 q9, q9, #6\t\n"
                "vmov.s16 q10, #0\t\n"
                "vmax.s16 q7, q7, q10\t\n"
                "vmax.s16 q8, q8, q10\t\n"
                "vmax.s16 q9, q9, q10\t\n"
                "vmov.u16 q10, #255\t\n"
                "vmin.u16 q7, q7, q10\t\n"
                "vmin.u16 q8, q8, q10\t\n"
                "vmin.u16 q9, q9, q10\t\n"
                "vmovn.s16 d6, q7\t\n"
                "vmovn.s16 d5, q8\t\n"
                "vmovn.s16 d4, q9\t\n"

                "vtrn.8 d2,d6\t\n"
                "vtrn.16 d2,d6\t\n"
                "vtrn.32 d2,d6\t\n"

                "vtrn.8 d1,d5\t\n"
                "vtrn.16 d1,d5\t\n"
                "vtrn.32 d1,d5\t\n"

                "vtrn.8 d0,d4\t\n"
                "vtrn.16 d0,d4\t\n"
                "vtrn.32 d0,d4\t\n"

                "vst4.8 {d0-d3}, [%[dst]]!\t\n"
                "vst4.8 {d4-d7}, [%[dst]]!\t\n"

                "subs r4, r4, #1\t\n"
                "bne 1b\t\n"
                "2:\t\n"
                : [dst] "+r" (dst), [y] "+r" (y), [uv] "+r" (uv), [c] "+r" (c)
                :
                : "r4", "cc","memory", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d7","d8","d9","d10","d11","d12","d13","d14","d15","d16","d17","d18","d19","d20","d21","d22","d23","d24","d25","d26","d27","d28","d29","d30","d31"
                );
        count%=16;
#endif
        int r, g, b;
        while (count > 1)
        {
            unsigned char _y = y[0];
            unsigned char _u = uv[0];
            unsigned char _v = uv[1];
            r = _y + ((179*(_v-128))>>7);
            g = _y - ((43*(_u-128) - 91*(_v-128))>>7);
            b = _y + ((227*(_u-128))>>7);
            r = r<0?0:r;r=r>255?255:r;
            g = g<0?0:g;g=g>255?255:g;
            b = b<0?0:b;b=b>255?255:b;
            dst[0] = b;
            dst[1] = g;
            dst[2] = r;
            dst[3] = 0xFF;

            y++;
            dst+=4;
            _y = y[0];

            r = _y + ((179*(_v-128))>>7);
            g = _y - ((43*(_u-128) - 91*(_v-128))>>7);
            b = _y + ((227*(_u-128))>>7);
            r = r<0?0:r;r=r>255?255:r;
            g = g<0?0:g;g=g>255?255:g;
            b = b<0?0:b;b=b>255?255:b;

            dst[0] = b;
            dst[1] = g;
            dst[2] = r;
            dst[3] = 0xFF;
            y++;
            uv+=2;
            dst+=4;

            count-=2;
        }
        if (count > 0)
        {
            unsigned char _y = y[0];
            unsigned char _u = uv[0];
            unsigned char _v = uv[1];
            r = _y + ((179*(_v-128))>>7);
            g = _y - ((43*(_u-128) - 91*(_v-128))>>7);
            b = _y + ((227*(_u-128))>>7);
            r = r<0?0:r;r=r>255?255:r;
            g = g<0?0:g;g=g>255?255:g;
            b = b<0?0:b;b=b>255?255:b;
            dst[0] = b;
            dst[1] = g;
            dst[2] = r;
            dst[3] = 0xFF;
        }
    }
}

void rotateYUV(unsigned char* output, unsigned char* input, int w, int h, bool swapxy, bool flipH, bool flipV)
{
    /*TODO support other transform*/
    if (!flipH)
    {
        for (int i=0; i<h; ++i)
        {
            for (int j=0; j<w; ++j)
            {
                output[j*h+h-i-1] = input[i*w+j];
            }
        }
    }
    else
    {
        for (int i=0; i<h; ++i)
        {
            for (int j=0; j<w; ++j)
            {
                output[j*h+i] = input[i*w+j];
            }
        }
    }
    if (flipV)
    {
        GLAUTOSTORAGE(tempbuffer, unsigned char, h);
        for (int i=0; i<w/2; ++i)
        {
            auto src = output + i*h;
            auto dst = output + (w-i-1)*h;
            ::memcpy(tempbuffer, src, h*sizeof(unsigned char));
            ::memcpy(src, dst, h*sizeof(unsigned char));
            ::memcpy(dst, tempbuffer, h*sizeof(unsigned char));
        }
    }
}

GLBmp* GLConvert(JNIEnv* env, jobject bitmap)
{
    //GPCLOCK;
    AndroidBitmapInfo info;
    info.format = ANDROID_BITMAP_FORMAT_NONE;
    AndroidBitmap_getInfo(env, bitmap, &info);
    if (info.width == 0 || info.height == 0 || info.format == ANDROID_BITMAP_FORMAT_NONE)
    {
        return NULL;
    }
    GLBmp* result = new GLBmp(info.width, info.height);
    GLConvertToARGB(result->getAddr(0, 0), 0, 0, info.width-1, info.height-1, info.width*4, env, bitmap);
    return result;
}
void RGBAToYUV(const GLBmp* srcBitmap, unsigned char* yuv, int outputformat)
{
    auto w = srcBitmap->width();
    auto h = srcBitmap->height();
    auto _output = yuv;
    for (int y=0; y<h; ++y)
    {
        unsigned char* _y = _output + y*w;
        auto src_ = srcBitmap->getAddr(0,y);
        int sta = 0;
        for (int x=sta; x<w; ++x)
        {
            int R = src_[x*4];
            int G = src_[x*4+1];
            int B = src_[x*4+2];
            int Y = ( (  66 * R + 129 * G +  25 * B + 128) >> 8) +  16;
            _y[x] = Y;
        }
    }
    /*TODO Compute UV*/
}

void YUVToRGB(const GLBmp* dstBitmap, unsigned char* yuv, int yuvformat)
{
    auto w = dstBitmap->width();
    auto h = dstBitmap->height();
    auto _input = yuv;
    for (int y=0; y<h; ++y)
    {
        unsigned char* _y = _input + y*w;
        auto dst_ = dstBitmap->getAddr(0,y);
        int sta = 0;
        for (int x=sta; x<w; ++x)
        {
            ::memset(dst_+x*4, _y[x], 4*sizeof(unsigned char));
        }
    }
}
