#ifndef JNIUTILS_JNIUTILSHEAD_H
#define JNIUTILS_JNIUTILSHEAD_H
#include "JniString.h"
#include "JniBitmap.h"
#include "JniStream.h"
#endif
