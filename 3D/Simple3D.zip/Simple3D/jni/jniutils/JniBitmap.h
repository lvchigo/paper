//
//  JniBitmap.h
//  simple3d
//
//  Created by jiangxiaotang on 15/9/25.
//  Copyright (c) 2015年 jiangxiaotang. All rights reserved.
//

#ifndef __simple3d__JniBitmap__
#define __simple3d__JniBitmap__

#include <stdio.h>
#include <android/bitmap.h>
#include "utils/RefCount.h"
#include "core/GLGrayBitmap.h"
class JniBitmap:public RefCount
{
public:
    JniBitmap(JNIEnv* env, jobject bitmap);
    virtual ~JniBitmap();
    const AndroidBitmapInfo& info() const {return mInfo;}
    void* pixels() const {return mPixels;}
    GPPtr<GLGrayBitmap> turnGray() const;
    GPPtr<GLBmp> turnARGB() const;
private:
    AndroidBitmapInfo mInfo;
    void* mPixels;
    jobject mBitmap;
    JNIEnv* mEnv;
};

#endif /* defined(__simple3d__JniBitmap__) */
