#include <stdlib.h>
#include "JniStream.h"
#include "utils/GLDebug.h"
#include "JniEnv.h"
#include "Verify.cpf"
jint JNI_OnLoad(JavaVM* vm, void *reserved)
{
    JNIEnv* env = NULL;
    
    if(vm->GetEnv((void**)&env, JNI_VERSION_1_4) != JNI_OK)
    {
        return -1;
    }
    if (!Verify(env))
    {
        abort();
        return -1;
    }
    register_android_graphics_CreateJavaOutputStreamAdaptor(env);
    return JNI_VERSION_1_4; //这里很重要，必须返回版本，否则加载会失败。
}
