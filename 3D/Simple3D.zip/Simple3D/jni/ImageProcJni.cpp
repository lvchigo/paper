#include "ImageProcJni.h"
#include "ImageProc.h"
#include "core/GLBmp.h"
#include "core/GLGrayBitmap.h"
#include "jniutils/jniUtilsHead.h"
#include <sstream>

jfloatArray Java_com_jiuyan_infashion_imagefilter_util_FilterJni_ImageProcRegistration(JNIEnv* env, jclass cls, jobject dst, jobject src)
{
    JniBitmap _dst(env, dst);
    JniBitmap _src(env, src);
    GLASSERT(_dst.info().format == ANDROID_BITMAP_FORMAT_RGBA_8888);
    GLASSERT(_src.info().format == ANDROID_BITMAP_FORMAT_RGBA_8888);
    GLASSERT(_dst.info().width == _src.info().width);
    GLASSERT(_dst.info().height == _src.info().height);
    
    GPPtr<GLMatrix<float>> transform = ImageProc::computeForARGB(_dst.pixels(), _src.pixels(), _dst.info().width, _dst.info().height);
    jfloatArray result = env->NewFloatArray(transform->width()*transform->height());
    float* _result = env->GetFloatArrayElements(result, NULL);
    
    for (int i=0; i<transform->height(); ++i)
    {
        auto _t = transform->getAddr(i);
        for (int j=0; j<transform->width(); ++j)
        {
            _result[i*transform->width()+j] = _t[j];
        }
    }
    env->ReleaseFloatArrayElements(result, _result, 0);
    return result;
}

void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_ImageProcMergeBitmap(JNIEnv* env, jclass cls, jobject dst, jobject src, jobject mask, jint xoffset, jint yoffset)
{
    JniBitmap jnidst(env, dst);
    JniBitmap jnisrc(env, src);
    JniBitmap jnigray(env, mask);
    GLASSERT(jnidst.info().format == ANDROID_BITMAP_FORMAT_RGBA_8888);
    GLASSERT(jnisrc.info().format == ANDROID_BITMAP_FORMAT_RGBA_8888);
    GLASSERT(jnigray.info().format == ANDROID_BITMAP_FORMAT_A_8);
    GLBmp _dst(jnidst.info().width, jnidst.info().height, jnidst.pixels());
    GLBmp _src(jnisrc.info().width, jnisrc.info().height, jnisrc.pixels());
    GPPtr<GLGrayBitmap> _mask = jnigray.turnGray();
    ImageProc::bitmapMergeMask(&_dst, &_src, _mask.get(), xoffset, yoffset);
}
jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_ImageProcGetMeanWidth(JNIEnv* env, jclass cls, jobject mask, jfloat rate)
{
    JniBitmap jnigray(env, mask);
    GLASSERT(jnigray.info().format == ANDROID_BITMAP_FORMAT_A_8);
    GPPtr<GLGrayBitmap> _mask = jnigray.turnGray();
    return ImageProc::meanImageWidth(_mask.get(), rate);
}

jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_ImageProcRunFilter(JNIEnv* env, jclass cls, jobject dst, jobject src, jstring name, jfloat rate)
{
    JNISTRING(filter, name, env);
    JniBitmap jdst(env, dst);
    JniBitmap jsrc(env, src);
    GPPtr<GLBmp> _dst = jdst.turnARGB();
    GPPtr<GLBmp> _src = jsrc.turnARGB();
    bool success = ImageProc::imageFilter(_dst.get(), _src.get(), filter, rate);
    if (success)
    {
        return 1;
    }
    return 0;
}

jstring Java_com_jiuyan_infashion_imagefilter_util_FilterJni_ImageProcGetFilterNames(JNIEnv* env, jclass cls)
{
    auto names = ImageProc::getAllFilterName();
    std::ostringstream output;
    for (auto n : names)
    {
        output << n << " ";
    }
    return env->NewStringUTF(output.str().c_str());
}

jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_ImageProcMorphing(JNIEnv* env, jclass cls, jobject dst, jint l, jint t, jint w, jint h, jint mx, jint my)
{
    JniBitmap jdst(env, dst);
    GPPtr<GLBmp> _dst = jdst.turnARGB();
    ImageProc::imageWarping(_dst.get(), _dst.get(), l, t, w, h, mx, my);
    return 0;
}
