#ifndef DISABLE_MOVIE

#include "MovieJni.h"
#include "jniutils/JniStream.h"
#include "jniutils/JniBitmap.h"
#include "jniutils/FormatConvert.h"
#include "utils/GLDebug.h"
#include <map>
#include "utils/GLLock.h"
#include "movie/GLDynamicBitmapFactory.h"
static GLLock gMutex;
static std::map<long, GPPtr<GLDynamicBitmapFactory::Encoder>> gInstance;
static std::map<long, GPPtr<GLMovie>> gMovieInstances;
static long gId = 0;

template <class T>
GPPtr<T> _findInstance(const std::map<long, GPPtr<T>>& instances, long id)
{
    GLAutoLock _l(gMutex);
    auto iter = instances.find(id);
    if (iter !=instances.end())
    {
        return iter->second;
    }
    return NULL;
}


jlong Java_com_jiuyan_infashion_imagefilter_util_FilterJni_MovieStartEncode(JNIEnv* env, jclass cls, jobject bitmap, jobject output, jbyteArray array, jint frames)
{
    GPPtr<GLBmp> gbitmap = GLConvert(env, bitmap);
    GPPtr<GLWStream> output_s = CreateJavaOutputStreamAdaptor(env, output, array);
    GPPtr<GLDynamicBitmapFactory::Encoder> encoder = GLDynamicBitmapFactory::startEncode(gbitmap, output_s, frames);
    long id = gId;
    {
        GLAutoLock _l(gMutex);
        gInstance.insert(std::make_pair(id, encoder));
        gId++;
    }
    FUNC_PRINT(1);
    return id;
}
jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_MovieAddBitmap(JNIEnv* env, jclass cls, jlong instance, jobject bitmap, jint l, jint t)
{
    GPPtr<GLBmp> gbitmap = GLConvert(env, bitmap);
    GLDynamicBitmapFactory::Encoder* encoder = NULL;
    {
        GLAutoLock _l(gMutex);
        auto iter = gInstance.find(instance);
        if (iter!=gInstance.end())
        {
            encoder = iter->second.get();
        }
    }
    if (NULL == encoder)
    {
        return 0;
    }
    FUNC_PRINT(1);
    encoder->addFrame(l, t, gbitmap.get());
    return 1;
}
jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_MovieEndEncode(JNIEnv* env, jclass cls, jlong instance)
{
    GLAutoLock _l(gMutex);
    auto iter = gInstance.find(instance);
    if (iter!=gInstance.end())
    {
        gInstance.erase(iter);
    }
    return 1;
}

jlong Java_com_jiuyan_infashion_imagefilter_util_FilterJni_MovieDecode(JNIEnv* env, jclass cls, jobject inputStream, jbyteArray cache)
{
    GPPtr<GLStream> jniStream = CreateJavaInputStreamAdaptor(env, inputStream, cache);
    GPPtr<GLMovie> movie = GLDynamicBitmapFactory::decode(jniStream);
    long id = -1;
    {
        GLAutoLock _l(gMutex);
        id = gId;
        gMovieInstances.insert(std::make_pair(id, movie));
        gId++;
    }
    return id;
}
jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_MovieGetInfo(JNIEnv* env, jclass cls, jlong instance, jintArray infos)
{
    GPPtr<GLMovie> movie = _findInstance(gMovieInstances, instance);
    if (NULL == movie.get())
    {
        return -1;
    }
    int w= movie->width();
    int h = movie->height();
    int frames = movie->frames();
    jint* infos_ = env->GetIntArrayElements(infos, NULL);
    infos_[0] = w;
    infos_[1] = h;
    infos_[2] = frames;
    env->ReleaseIntArrayElements(infos, infos_, 0);
    return 0;
}
jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_MovieRender(JNIEnv* env, jclass cls, jlong instance, jobject dstBitmap, jint n, jboolean renderdirty)
{
    GPPtr<GLMovie> movie = _findInstance(gMovieInstances, instance);
    if (NULL == movie.get())
    {
        return -1;
    }
    JniBitmap dst_(env, dstBitmap);
    GLASSERT(dst_.info().format == ANDROID_BITMAP_FORMAT_RGBA_8888);
    GLBmp dst(dst_.info().width, dst_.info().height, dst_.pixels());
    movie->draw(&dst, n, renderdirty);
    return 0;
}

jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_MovieRelease(JNIEnv* env, jclass cls, jlong instance)
{
    GLAutoLock _l(gMutex);
    auto iter = gMovieInstances.find(instance);
    if (iter!=gMovieInstances.end())
    {
        gMovieInstances.erase(iter);
        return 1;
    }
    return 0;
}
#endif
