#include <jni.h>
#include <string.h>
#include <android/bitmap.h>
#include <string>
#include <sstream>
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES/glext.h>
#include "InWorkManager.h"
#include "utils/GLLock.h"
#include "utils/GLDefer.h"
#include "jniutils/FormatConvert.h"
#include "GL/GLWorkThread.h"
#include "GL/GLContext.h"
#include "jniutils/JniBitmap.h"
#include <unistd.h>
#include <sys/types.h>

using namespace std;

static InWorkManager* gManager = NULL;

static GLLock gJniLock;

extern "C"{
    jlong Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeInit(JNIEnv* env, jclass cls);
    void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeAddWork(JNIEnv* env, jclass cls, jlong id, jstring name, jobjectArray resources, jfloat defaultratio);
    void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeReleaseGLWorks(JNIEnv* env, jclass cls, jlong id);
    void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeRelease(JNIEnv* env, jclass cls, jlong id);
    void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeModify(JNIEnv* env, jclass cls, jobject dst);
    void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeSetDefaultVertex(JNIEnv* env, jclass cls, jstring vertex);
    void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeSetFilterChain(JNIEnv* env, jclass cls, jlong manager, jintArray ids, jfloatArray ratios, jint n);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeGetCurrentIndex(JNIEnv* env, jclass cls, jlong id);
    void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeRun(JNIEnv* env, jclass cls, jlong id, jint srcid, jint w, jint h, jfloatArray vs, jfloatArray ts, jint useoes);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeRunForBitmapOpt(JNIEnv* env, jclass cls,jlong id, jobject dst, jobject src,  jint l, jint t, jint flipH, jint flipV, jint swapxy, jintArray ids, jfloatArray ratios, jint n);
    void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeRunForBitmap(JNIEnv* env, jclass cls,jlong id, jobject dst, jobject src,  jfloatArray vs, jfloatArray fs, jintArray ids, jfloatArray ratios, jint n);
    void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeTurnToRGBA(JNIEnv* env, jclass cls, jbyteArray yuv, jint width, jint height, jint srcformat, jintArray rgbout);
    void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeRotate(JNIEnv* env, jclass cls, jbyteArray output, jbyteArray input, jint w, jint h, jboolean swapxy, jboolean flipH, jboolean flipV);
    void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeBitmapToYUV(JNIEnv* env, jclass cls, jbyteArray output, jobject src, jint OutputFormat);
}

jlong Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeInit(JNIEnv* env, jclass cls)
{
    GLAutoLock _l(gJniLock);
    if (NULL!=gManager)
    {
        delete gManager;
    }
    gManager = new InWorkManager;
    return 0;
}
void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeRelease(JNIEnv* env, jclass cls, jlong id)
{
    GLAutoLock _l(gJniLock);
    if (NULL == gManager)
    {
        return;
    }
    delete gManager;
    gManager = NULL;
}
void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeRun(JNIEnv* env, jclass cls, jlong id, jint srcid, jint w, jint h, jfloatArray vs, jfloatArray ts, jint useoes)
{
    GLAutoLock _l(gJniLock);
    if (NULL == gManager)
    {
        return;
    }
    jfloat* _vs = env->GetFloatArrayElements(vs, NULL);
    jfloat* _ts = env->GetFloatArrayElements(ts, NULL);
    int target = GL_TEXTURE_2D;
    if (1 == useoes)
    {
        target = GL_TEXTURE_EXTERNAL_OES;
    }
    GLTexture tempsrc(srcid, w, h, target);
    gManager->drawFrame(&tempsrc, _vs, _ts, useoes, gettid());
    env->ReleaseFloatArrayElements(vs, _vs, 0);
    env->ReleaseFloatArrayElements(ts, _ts, 0);
}

void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeSetDefaultVertex(JNIEnv* env, jclass cls, jstring vertex)
{
    GLAutoLock _l(gJniLock);
    const char* ver = env->GetStringUTFChars(vertex, NULL);
    GLInWork::setDefaultVertexShader(ver);
    env->ReleaseStringUTFChars(vertex, ver);
}
void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeAddWork(JNIEnv* env, jclass cls, jlong id, jstring name, jobjectArray resources, jfloat defaultratio)
{
    if (NULL == gManager)
    {
        return;
    }
    GLAutoLock _l(gJniLock);
    const char* cname = env->GetStringUTFChars(name, NULL);
    int size = env->GetArrayLength(resources);
    vector<InWorkManager::BitmapInfo> infos;
    for (int i=0; i<size; ++i)
    {
        auto obj = env->GetObjectArrayElement(resources,i);
        AndroidBitmapInfo info;
        AndroidBitmap_getInfo(env, obj, &info);
        InWorkManager::BitmapInfo inf;
        inf.w = info.width;
        inf.h = info.height;
        AndroidBitmap_lockPixels(env, obj, &(inf.pixels));
        infos.push_back(inf);
    }
    gManager->addWork(cname, infos, defaultratio);
    for (int i=0; i<size; ++i)
    {
        auto obj = env->GetObjectArrayElement(resources,i);
        AndroidBitmap_unlockPixels(env, obj);
    }
    env->ReleaseStringUTFChars(name, cname);
}
void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeTurnToRGBA(JNIEnv* env, jclass cls, jbyteArray yuvdata, jint width, jint height, jint srcformat, jintArray rgbout)
{
    jint *rgb = env->GetIntArrayElements(rgbout, 0);
    jbyte* yuv = env->GetByteArrayElements(yuvdata, 0);
    convertToRGBA((unsigned char*)yuv, width, height, srcformat, (int*)rgb);
    env->ReleaseIntArrayElements(rgbout, rgb, 0);
    env->ReleaseByteArrayElements(yuvdata, yuv, 0);
}

void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeRunForBitmap(JNIEnv* env, jclass cls,jlong id, jobject dst, jobject src,  jfloatArray vs, jfloatArray ts, jintArray ids, jfloatArray ratios, jint composeNumber)
{
    if (NULL == gManager)
    {
        return;
    }
    jint *composeIds;
    jfloat* _composeRatios;
    GLStartEnd({composeIds = env->GetIntArrayElements(ids, 0); _composeRatios = env->GetFloatArrayElements(ratios, 0);}, [&](){env->ReleaseIntArrayElements(ids, composeIds,0); env->ReleaseFloatArrayElements(ratios, _composeRatios,0);});
    JniBitmap jni_src(env, src);
    GLASSERT(ANDROID_BITMAP_FORMAT_RGBA_8888 == jni_src.info().format);
    JniBitmap jni_dst(env, dst);
    GLASSERT(ANDROID_BITMAP_FORMAT_RGBA_8888 == jni_dst.info().format);
    jfloat* _vs = env->GetFloatArrayElements(vs, NULL);
    jfloat* _ts = env->GetFloatArrayElements(ts, NULL);
    GPPtr<GLBmp> srcb = jni_src.turnARGB();
    GPPtr<GLBmp> dstb = jni_dst.turnARGB();
    gManager->runForBitmap(srcb.get(), dstb.get(), _vs, _ts, composeIds, _composeRatios, composeNumber);
    env->ReleaseFloatArrayElements(vs, _vs, 0);
    env->ReleaseFloatArrayElements(ts, _ts, 0);
}
jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeGetCurrentIndex(JNIEnv* env, jclass cls, jlong id)
{
    if (NULL == gManager)
    {
        return -1;
    }
    return gManager->getCur();
}


void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeReleaseGLWorks(JNIEnv* env, jclass cls, jlong id)
{
    GLAutoLock _l(gJniLock);
    if (NULL == gManager)
    {
        return;
    }
    gManager->releaseCurrentWork(gettid());
}
jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeRunForBitmapOpt(JNIEnv* env, jclass cls,jlong id, jobject dst, jobject src,  jint l, jint t, jint flipH, jint flipV, jint swapxy, jintArray ids, jfloatArray ratios, jint composeNumber)
{
    if (NULL == gManager)
    {
        return 0;
    }
    jint *composeIds;
    jfloat* _composeRatios;
    GLStartEnd({composeIds = env->GetIntArrayElements(ids, 0); _composeRatios = env->GetFloatArrayElements(ratios, 0);}, [&](){env->ReleaseIntArrayElements(ids, composeIds,0); env->ReleaseFloatArrayElements(ratios, _composeRatios,0);});
    JniBitmap jni_src(env, src);
    GLASSERT(ANDROID_BITMAP_FORMAT_RGBA_8888 == jni_src.info().format);
    JniBitmap jni_dst(env, dst);
    GLASSERT(ANDROID_BITMAP_FORMAT_RGBA_8888 == jni_dst.info().format);
    GPPtr<GLBmp> srcb = jni_src.turnARGB();
    GPPtr<GLBmp> dstb = jni_dst.turnARGB();
    return gManager->runForBitmapOpt(srcb.get(), dstb.get(), composeIds, _composeRatios, l, t, flipH, flipV, swapxy, composeNumber);
}


void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeRotate(JNIEnv* env, jclass cls, jbyteArray output, jbyteArray input, jint w, jint h, jboolean swapxy, jboolean flipH, jboolean flipV)
{
    jbyte* _input = env->GetByteArrayElements(input, 0);
    jbyte* _output = env->GetByteArrayElements(output, 0);
    rotateYUV((unsigned char*)_output, (unsigned char*)_input, w, h, swapxy, flipH, flipV);
    env->ReleaseByteArrayElements(input, _input, 0);
    env->ReleaseByteArrayElements(output, _output, 0);
}


void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeSetFilterChain(JNIEnv* env, jclass cls, jlong manager, jintArray ids, jfloatArray ratios, jint n)
{
    GLAutoLock _l(gJniLock);
    if (NULL == gManager)
    {
        return;
    }
    GLASSERT(0<n);
    jint *_ids = env->GetIntArrayElements(ids, 0);
    jfloat* _ratios = env->GetFloatArrayElements(ratios, 0);
    GLASSERT(n <= env->GetArrayLength(ids));
    GLASSERT(n <= env->GetArrayLength(ratios));
    gManager->refresh(_ids, _ratios, n);
    env->ReleaseIntArrayElements(ids, _ids,0);
    env->ReleaseFloatArrayElements(ratios, _ratios,0);
}

void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_nativeBitmapToYUV(JNIEnv* env, jclass cls, jbyteArray output, jobject src, jint OutputFormat)
{
    JniBitmap jniBitmap(env, src);
    GPPtr<GLBmp> srcBitmap;
    if (jniBitmap.info().format == ANDROID_BITMAP_FORMAT_RGBA_8888)
    {
        srcBitmap = new GLBmp(jniBitmap.info().width, jniBitmap.info().height, jniBitmap.pixels());
    }
    else
    {
        srcBitmap = GLConvert(env, src);
    }
    GLASSERT(NULL!=srcBitmap.get());
    jbyte* __output = env->GetByteArrayElements(output, 0);
    unsigned char* _output = (unsigned char*)__output;
    GLASSERT(NULL!=_output);
    RGBAToYUV(srcBitmap.get(), _output, OutputFormat);
    env->ReleaseByteArrayElements(output, __output, 0);
}
