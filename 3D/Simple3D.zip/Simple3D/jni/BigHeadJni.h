//
//  BigHeadJni.h
//  simple3d
//
//  Created by jiangxiaotang on 15/9/1.
//  Copyright (c) 2015年 jiangxiaotang. All rights reserved.
//

#ifndef __simple3d__BigHeadJni__
#define __simple3d__BigHeadJni__

#include <stdio.h>
#include <jni.h>
#include "utils/GLDebug.h"
extern "C"
{
    jlong Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHNewInstance(JNIEnv* env, jclass cls);
    void Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHReleaseInstance(JNIEnv* env, jclass cls, jlong instance);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHSetUpOriginBitmap(JNIEnv* env, jclass cls, jlong instance, jobject origin);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHSkinDetect(JNIEnv* env, jclass cls, jlong instance, jobject gray, jint skin, jint nonskin);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHReduceRegion(JNIEnv* env, jclass cls, jlong instance, jobject gray_mask);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHFillInterval(JNIEnv* env, jclass cls, jlong instance, jobject dstBitmap);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHEclosion(JNIEnv* env, jclass cls, jlong instance, jobject gray_mask);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHAddNewMask(JNIEnv* env, jclass cls, jlong instance, jobject gray_seed, jobject gray_mask, jint left, jint top, jint right, jint bottom, jint max_computeArea);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHAddNewMaskConnected(JNIEnv* env, jclass cls, jlong instance, jobject gray_seed, jobject gray_mask, jint left, jint top, jint right, jint bottom, jint max_computeArea);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHMeasure(JNIEnv* env, jclass cls, jlong instance, jobject gray_mask, jintArray bounds);
    jint Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHCropByMask(JNIEnv* env, jclass cls, jlong instance, jobject gray_mask, jobject dst, jint l, jint t);
    jintArray Java_com_jiuyan_infashion_imagefilter_util_FilterJni_BHGetMaskBounderOffsetPoints(JNIEnv* env, jclass cls, jlong instance, jobject gray_mask, jint l, jint t, jint r, jint b, jint length, jint interval, jint thredhold, jint pixelThredhold);
}
#endif /* defined(__simple3d__BigHeadJni__) */
