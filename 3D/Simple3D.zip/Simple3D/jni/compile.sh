#!/bin/bash
find ../obj/local/ -name JniEnv.o | xargs rm
cp Verify.cpp_false Verify.cpf && stat Verify.cpf && ndk-build -j16

cp ../libs/armeabi/libsimple3D.so     ../../../android-aries-camera/CameraLibrary/libs/armeabi/libsimple3D.so
cp ../libs/armeabi-v7a/libsimple3D.so ../../../android-aries-camera/CameraLibrary/libs/armeabi-v7a/libsimple3D.so
cp ../libs/x86/libsimple3D.so         ../../../android-aries-camera/CameraLibrary/libs/x86/libsimple3D.so
echo Second

find ../obj/local/ -name JniEnv.o | xargs rm
rm Verify.cpf && cp Verify.cpp_true Verify.cpf && stat Verify.cpf && ndk-build
cp ../libs/armeabi/libsimple3D.so     ../../../android-aries-camera/CameraLibrary/libs_release/armeabi/libsimple3D.so
cp ../libs/armeabi-v7a/libsimple3D.so ../../../android-aries-camera/CameraLibrary/libs_release/armeabi-v7a/libsimple3D.so
cp ../libs/x86/libsimple3D.so         ../../../android-aries-camera/CameraLibrary/libs_release/x86/libsimple3D.so
cp ../obj/local/armeabi/libsimple3D.so     ../../../android-aries-camera/CameraLibrary/libs_release_obj/armeabi/libsimple3D.so
cp ../obj/local/armeabi-v7a/libsimple3D.so ../../../android-aries-camera/CameraLibrary/libs_release_obj/armeabi-v7a/libsimple3D.so
cp ../obj/local/x86/libsimple3D.so         ../../../android-aries-camera/CameraLibrary/libs_release_obj/x86/libsimple3D.so
