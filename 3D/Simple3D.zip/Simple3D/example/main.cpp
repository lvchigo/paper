#include "GL/GLShaderFactory.h"
#include "core/GLBitmapFactory.h"
#include "GL/GLContext.h"
#include "GL/GLBitmapWork.h"
#include "ImageProc.h"

int main()
{
    GPPtr<GLBmp> src = GLBitmapFactory::create("/Users/jiangxiaotang/InWork/incameraengineandroid/Simple3D/input.png");
    int l = src->width() / 5.0;
    int t = src->height() / 5.0;
    int w = src->width() / 3.0;
    int h = src->height() / 3.0;
    ImageProc::imageWarping(src.get(), src.get(), l, t, w, h, src->width(), 0);
    return 1;
}
