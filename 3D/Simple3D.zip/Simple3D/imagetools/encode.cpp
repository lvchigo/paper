#include "Decryptor.h"
#include "core/GLBitmapFactory.h"
#include "utils/GLDebug.h"

int main(int argc, char* argv[])
{
    FUNC_PRINT(argc);
    GLASSERT(argc>=2);
    for (int i=1; i<argc; ++i)
    {
        FUNC_PRINT_ALL(argv[i], s);
        GPPtr<GLBmp> origin = GLBitmapFactory::create(argv[i]);
        Decryptor::encode(origin.get());
        GLBitmapFactory::dump(origin.get(), argv[i]);
    }
    return 1;
}
