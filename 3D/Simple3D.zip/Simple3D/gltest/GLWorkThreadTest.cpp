#include "test/GLTest.h"
#include "core/GLBmp.h"
#include "core/GLBitmapFactory.h"
#include "GL/GLBitmapWorkFactory.h"
#include "GL/GLBitmapWork.h"
#include "GL/GLWorkThread.h"
#include "GL/GLContext.h"
void create()
{
    GLContext::init();
}
void destroy()
{
    GLContext::destroy();
}

class GLWorkThreadTest:public GLTest
{
    public:
        virtual void run();
        GLWorkThreadTest(){}
        virtual ~GLWorkThreadTest(){}
};

void GLWorkThreadTest::run()
{
    GLWorkThread worker(create, destroy);
    worker.start();
    GPPtr<GLBmp> src = GLBitmapFactory::create("input.png");
    GPPtr<GLBmp> dst = new GLBmp(src->width(),src->height());
    GLBitmapWork* work = GLBitmapWorkFactory::create("Bicubic");
    assert(NULL!=work);
    GPPtr<GLWork> w = work;

    work->set(src, dst);
    GPPtr<GLWorkSemore> s = worker.queueWork(w);
    s->wait();
    GLBitmapFactory::dump(dst.get(), "output/GLWorkThreadTest.png");
    worker.stop();
}
static GLTestRegister<GLWorkThreadTest> a("GLWorkThreadTest");
