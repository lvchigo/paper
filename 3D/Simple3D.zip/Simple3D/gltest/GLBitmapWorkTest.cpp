#include "test/GLTest.h"
#include "core/GLBmp.h"
#include "core/GLBitmapFactory.h"
#include "GL/GLBitmapWork.h"

class GLBitmapWorkTest:public GLTest
{
    public:
        virtual void run();
        GLBitmapWorkTest(){}
        virtual ~GLBitmapWorkTest(){}
};

void GLBitmapWorkTest::run()
{
    GPPtr<GLBmp> src = GLBitmapFactory::create("input.png");
    GPPtr<GLBmp> dst = new GLBmp(src->width()*4, src->height()*4);
    {
        GPPtr<GLTextureWork> _w= new GLTextureWork(NULL, NULL);
        GPPtr<GLBitmapWork> w = new GLBitmapWork(_w);
        w->set(src, dst);
        w->runOnePass();
    }
    GLBitmapFactory::dump(dst.get(), "output/GLBitmapWorkTest.png");
}
static GLTestRegister<GLBitmapWorkTest> a("GLBitmapWorkTest");
