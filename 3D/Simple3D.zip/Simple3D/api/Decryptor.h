#ifndef DECRYPTOR_H
#define DECRYPTOR_H
#include "core/GLBmp.h"

class Decryptor
{
public:
    static void decode(GLBmp* target);
    static void encode(GLBmp* target);
};

#endif
