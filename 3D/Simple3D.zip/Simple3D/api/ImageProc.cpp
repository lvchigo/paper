#include "ImageProc.h"
#include "utils/GLDebug.h"
#include "utils/GLAutoStorage.h"
#include "core/GLBmp.h"
#include "core/GLGrayBitmap.h"
#include "filter/IGLFilterFactory.h"
#include "algorithm/GLRegistration.h"
#include "algorithm/GLDistanceMatcher.h"
#include "algorithm/GLLinearRegressor.h"
#include "algorithm/GLSiftOperator.h"
#include "algorithm/GLScale.h"
#include "algorithm/GLRegions.h"
GPPtr<GLMatrix<float>> ImageProc::computeForARGB(void* dst, void* src, int w, int h)
{
    GLASSERT(NULL!=dst);
    GLASSERT(NULL!=src);
    GLASSERT(w>0);
    GLASSERT(h>0);
    static const int maxLength = 200;
    GPPtr<GLBmp> p1 = new GLBmp(w, h, dst);
    GPPtr<GLBmp> p2 = new GLBmp(w, h, src);
    float xscale = 1.0f;
    float yscale = 1.0f;
    if (w > maxLength)
    {
        int scale = (w + maxLength-1) / maxLength;
        p1 = GLScale::reduceBitmapCroped(p1.get(), 0, 0, w-1, h-1, scale);
        p2 = GLScale::reduceBitmapCroped(p2.get(), 0, 0, w-1, h-1, scale);
        xscale = (float)w/p1->width();
        yscale = (float)h/p1->height();
    }

    GPPtr<GLGrayBitmap> g1 = new GLGrayBitmap(p1->width(), p1->height());
    GLGrayBitmap::turnGray(g1.get(), p1.get());
    GPPtr<GLGrayBitmap> g2 = new GLGrayBitmap(p2->width(), p2->height());
    GLGrayBitmap::turnGray(g2.get(), p2.get());


    GLRegistration registor(new GLSiftOperator, new GLDistanceMatcher, new GLLinearRegressor);
    GPPtr<GLMatrix<float>> tempres = registor.registration(g1.get(), g2.get());
    GLASSERT(tempres->width() == 3);
    GLASSERT(tempres->height() == 2);
    auto _first = tempres->getAddr(0);
    auto _second = tempres->getAddr(1);
    _first[2] = _first[2]*xscale;
    _second[2] = _second[2]*yscale;
    return tempres;
}

void ImageProc::bitmapMergeMask(GLBmp* dst, const GLBmp* src, const GLGrayBitmap* mask, int xoffset, int yoffset)
{
    GLASSERT(NULL!=dst);
    GLASSERT(NULL!=src);
    GLASSERT(NULL!=mask);
    GLASSERT(dst->width() == src->width());
    GLASSERT(dst->width() == mask->width());
    GLASSERT(dst->height() == src->height());
    GLASSERT(dst->height() == mask->height());
    int w = src->width();
    int h = src->height();
    for (int y=0; y<h; ++y)
    {
        auto _dst = dst->getAddr(0,y);
        auto _mask = mask->getAddr(0, y);
        auto src_y = -yoffset + y;
        if (src_y < 0 || src_y>=h)
        {
            continue;
        }
        auto _src = src->getAddr(0,src_y);
        for (int x=0; x<w; ++x)
        {
            int alpha = _mask[x];
            int sx = x - xoffset;
            if (sx < 0 || sx >=w)
            {
                continue;
            }
            for (int k=0; k<3; ++k)
            {
                _dst[4*x+k] = (_dst[4*x+k]*(256-alpha) + _src[4*sx+k]*alpha)/256;
            }
        }
    }
}

int ImageProc::meanImageWidth(const GLGrayBitmap* mask, float rate)
{
    GLASSERT(NULL!=mask);
    GLASSERT(rate>0 && rate<1);
    return GLRegion::getMeanWidth(mask, rate);
}

bool ImageProc::imageFilter(GLBmp* dst, GLBmp* src, const char* name, double rate)
{
    GLASSERT(NULL!=src);
    GLASSERT(NULL!=dst);
    GLASSERT(src->width() == dst->width());
    GLASSERT(src->height() == dst->height());
    auto filter = IGLFilterFactory::create(name, src->width(), src->height());
    if (NULL == filter)
    {
        return false;
    }
    size_t n = filter->vMap(NULL, 0);
    if (n > 0)
    {
        GLAUTOSTORAGE(p, double, n);
        p[0] = rate;
        for (int i=1; i<n; ++i)
        {
            p[i] = 0.5;
        }
    }
    filter->vFilter(dst, src);
    return true;
}

std::vector<std::string> ImageProc::getAllFilterName()
{
    return IGLFilterFactory::listMethods();
}

#include "OpenGLWorker.h"

#include "GL/GLShaderFactory.h"
#include "GL/GLBitmapWork.h"
class GLImageWarpWork:public GLTextureWork
{
public:
    GLImageWarpWork(float mx, float my):GLTextureWork(NULL, GLShaderFactory::get("ImageWarping.fra"))
    {
        mMX = mx;
        mMY = my;
    }
    virtual ~GLImageWarpWork(){}
    virtual void onUse(GLTexture* dst, std::vector<GLTexture*> sources, GLProgram* shader)
    {
        GLProgram::setUniform(mMX, shader->uniform("mMX"));
        GLProgram::setUniform(mMY, shader->uniform("mMY"));
    }
private:
    float mMX;
    float mMY;
};


void ImageProc::imageWarping(GLBmp* dst, const GLBmp* src, int l, int t, int w, int h, int mx, int my)
{
    GLASSERT(NULL!=dst);
    GLASSERT(NULL!=src);
    GLASSERT(dst->width() == src->width());
    GLASSERT(dst->height() == src->height());
    GLASSERT(l>=0 && t>=0);
    GLASSERT(w+l <= dst->width());
    GLASSERT(h+t <= dst->height());
    GPPtr<GLBmp> src_cropped = GLScale::reduceBitmapCroped(src, l, t, w+l-1, h+t-1, 1);
    float mxf = (mx-l)/(float)w;
    float myf = (my-t)/(float)h;
    auto workfunc = [&](){
        GPPtr<GLTextureWork> _w= new GLImageWarpWork(mxf, myf);
        GPPtr<GLBitmapWork> w = new GLBitmapWork(_w, true);
        w->set(src_cropped, src_cropped);
        w->runOnePass();
    };
    auto sema = OpenGLWorker::getInstance()->queueWork(new GLFunctionWork(workfunc));
    sema->wait();
    /*Copy to dst*/
    for (int y=0; y<h; ++y)
    {
        auto _dst = dst->getAddr(l, t+y);
        auto _src = src_cropped->getAddr(0, y);
        ::memcpy(_dst, _src, 4*w*sizeof(unsigned char));
    }
}

