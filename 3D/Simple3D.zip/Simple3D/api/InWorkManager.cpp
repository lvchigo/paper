#include "InWorkManager.h"
#include "GLInWorkFactory.h"
#include "GLMultiPassDrawWork.h"
#include "Decryptor.h"
#include "utils/GLAutoStorage.h"
#include "utils/GLAttributes.h"
#include "filter/GLGPUFilter.h"
#include "filter/GLLargeGPUFilter.h"
#include "filter/IGLFilterFactory.h"
#include "GLvboBufferManager.h"
#include <sstream>
#include <string.h>
#include "OpenGLWorker.h"
#include "utils/GP_Clock.h"
InWorkManager::InWorkManager()
{
    mCur = 0;
    mNeedComposeFilterRefresh = false;
    mComposeRatios = NULL;
    mComposeIds = NULL;
    mComposeNumber = 0;
}
InWorkManager::~InWorkManager()
{
    for (int i=0; i<mResources.size(); ++i)
    {
        delete mResources[i];
    }
}
void InWorkManager::setIndex(int index)
{
    index = index % mResources.size();
    mCur = index;
    //FUNC_PRINT(mCur);
}
void InWorkManager::addWork(const char* name, const std::vector<BitmapInfo>& infos, float ratio)
{
    std::ostringstream vertexfix;
    vertexfix << name;
    vertexfix << ".vex";
    const char* vertex = GLShaderFactory::get(vertexfix.str());
    std::ostringstream fragfix;
    fragfix << name;
    fragfix << ".fra";
    const char* frag = GLShaderFactory::get(fragfix.str());
    GLInWorkResource* r = new GLInWorkResource;
    mResources.push_back(r);
    r->vertex = vertex;
    r->frag = frag;
    r->ratio = ratio;
    r->name = name;
    std::vector<GLBmp*>& res = r->resources;
    for (int i=0;i<infos.size(); ++i)
    {
        auto inf = infos[i];
        GLBmp* bmp = new GLBmp(inf.w, inf.h);
        auto p = bmp->pixels();
        ::memcpy(p, inf.pixels, 4*sizeof(char)*inf.w*inf.h);
        Decryptor::decode(bmp);
        res.push_back(bmp);
    }
}
IGLDrawWork* InWorkManager::_create(int useoes, int ids)
{
    GLASSERT(ids>=0 && ids<mResources.size());
    if (1==useoes)
    {
        GLInWorkResource* r = mResources[ids];
        return GLInWorkFactory::create(r->name.c_str(), r);
    }
    return createWork(ids);
}

IGLDrawWork* InWorkManager::createWork(int index, bool preferSpeed)
{
    if (index == InWorkManager::ORIGIN)
    {
        return GLInWork::createDefault();
    }
    GLASSERT(index>=0 && index<mResources.size());
    GLInWorkResource* r = mResources[index];
    GLInWorkResource newResource;
    newResource.name = r->name;
    newResource.vertex = r->vertex;
    newResource.resources = r->resources;
    newResource.ratio = r->ratio;
    GLASSERT(NULL!=r->frag);
    for (int i=0; i<newResource.resources.size(); ++i)
    {
        newResource.resources[i]->addRef();
    }
    std::string newfrag(r->frag);
    std::string originstring("samplerExternalOES");
    std::string replacstring("sampler2D");
    auto pos = newfrag.find(originstring);
    if (std::string::npos!=pos)
    {
        for (int i=0; i<replacstring.size(); ++i)
        {
            newfrag[pos++] = replacstring[i];
        }
        for (int i=0; i<originstring.size()-replacstring.size(); ++i)
        {
            newfrag[pos++] = ' ';
        }
        for (int i=0; i<newfrag.size(); ++i)
        {
            if (newfrag[i]=='\n')
            {
                break;
            }
            newfrag[i] = ' ';
        }
    }
    newResource.frag = newfrag.c_str();
    return GLInWorkFactory::create(newResource.name.c_str(), &newResource, preferSpeed);
}

IGLDrawWork* InWorkManager::prepareComposeFilter(int useoes, int* ids, int number)
{
    GLASSERT(number>=1);
    GLASSERT(NULL!=ids);
    if (number == 1)
    {
        return _create(useoes, ids[0]);
    }
    std::vector<GPPtr<IGLDrawWork> > works;
    works.push_back(_create(useoes, ids[0]));
    for (int i=1; i<number; ++i)
    {
        works.push_back(_create(0, ids[i]));
    }
    return new GLMultiPassDrawWork(works);
}


void InWorkManager::runForBitmap(const GLBmp* src, GLBmp* dst, float* vs, float* ts, int* ids, float* ratios, int number)
{
    GLASSERT(NULL!=src);
    GLASSERT(NULL!=dst);
    GLASSERT(NULL!=vs);
    GLASSERT(NULL!=ts);
    GLASSERT(NULL!=ids);
    GLASSERT(NULL!=ratios);
    GLASSERT(number>=1);
    GLAUTOSTORAGE(composeRatios, double, number);
    for (int i=0; i<number; ++i)
    {
        composeRatios[i] = ratios[i];
    }
    auto workfunc = [&](){
        GPPtr<IGLDrawWork> work;
        work = this->prepareComposeFilter(0, ids, number);
        work->vMap(composeRatios, number);
        float transformed_vex[8];
        /*flipV because glReadPixels is flipV*/
        for (int i=0; i<8; ++i)
        {
            transformed_vex[i] = (1-2*(i%2))*vs[i];
        }
        GPPtr<IGLFilter> fw = new GLGPUFilter(work, transformed_vex, ts);
        fw->vFilter(dst, src);
    };
    GPPtr<GLWork> work = new GLFunctionWork(workfunc);
    GPPtr<GLWorkSemore> s = OpenGLWorker::getInstance()->queueWork(work);
    s->wait();
}
void InWorkManager::reset(int n)
{
    if (n == mComposeNumber)
    {
        return;
    }
    if (NULL!=mComposeIds)
    {
        delete [] mComposeIds;
        mComposeIds = NULL;
    }
    if (NULL!=mComposeRatios)
    {
        delete [] mComposeRatios;
        mComposeRatios = NULL;
    }
    if (n>0)
    {
        mComposeIds = new int[n];
        mComposeRatios = new double[n];
    }
    mComposeNumber = n;
    mNeedComposeFilterRefresh = true;
}


void InWorkManager::drawFrame(GLTexture* src, float* vs, float* ts, int useoes, size_t tid)
{
    //GPCLOCK;
    IGLDrawWork* work = NULL;
    if (mNeedComposeFilterRefresh)
    {
        auto pos = (mComposeWork).find(tid);
        if (pos != mComposeWork.end())
        {
            delete pos->second;
            mComposeWork.erase(pos);
        }
        mNeedComposeFilterRefresh = false;
    }
    auto workpos = mComposeWork.find(tid);
    if (workpos == mComposeWork.end())
    {
        mComposeWork.insert(std::make_pair(tid, prepareComposeFilter(useoes, mComposeIds, mComposeNumber)));
        workpos = mComposeWork.find(tid);
    }
    work = workpos->second;
    work->vMap(mComposeRatios, mComposeNumber);
    
#if 0
    std::ostringstream os;
    for (int i=0; i<8; ++i)
    {
        os << _vs[i]<<", ";
    }
    FUNC_PRINT_ALL(os.str().c_str(), s);
#endif
    GLvboBuffer vex(vs, 2, 4, GL_TRIANGLE_STRIP);
    GLvboBuffer tex(ts, 2, 4, GL_TRIANGLE_STRIP);
    
    work->onDraw(&src, 1, &vex, &tex);
}

void InWorkManager::refresh(int* _ids, float* _ratios, int n)
{
    mNeedComposeFilterRefresh = true;
    bool needfresh = true;
    if (mComposeNumber  == n)
    {
        needfresh = false;
        for (int i=0; i<n; ++i)
        {
            if (mComposeIds[i]!=_ids[i])
            {
                needfresh = true;
                break;
            }
        }
    }
    if (needfresh)
    {
        reset(n);
    }
    for (int i=0; i<n; ++i)
    {
        mComposeRatios[i] = _ratios[i];
        mComposeIds[i] = _ids[i];
    }
}

static const int gUnit = 1024;
static bool supportLargeFilter(int* ids, int n, InWorkManager* manager, int size)
{
    GLASSERT(NULL!=ids);
    GLASSERT(1<=n);
    const int unit = gUnit;
    if (size < unit)
    {
        return false;
    }
    for (int i=0; i<n; ++i)
    {
        int interval = -1;
        auto name = manager->getName(ids[i]);
        interval = GLAttributes::get(name, "fUnit");
        if (-1 < interval)
        {
            interval = size*interval/100;
        }
        else
        {
            interval = GLAttributes::get(name, "unit");
        }
        if (-1 == interval || interval > unit/2)
        {
            return false;
        }
    }
    return true;
}

static GPPtr<IGLFilter> turnLargeFilterIfNeeded(GPPtr<IGLFilter> filter, int* ids, int n, InWorkManager* manager, int l, int t, int size, bool flipH, bool flipV, bool swapxy)
{
    GLASSERT(NULL!=ids);
    GLASSERT(1<=n);
    const int unit = gUnit;
    int maxInterval = -1;
    for (int i=0; i<n; ++i)
    {
        int interval = -1;
        auto name = manager->getName(ids[i]);
        interval = GLAttributes::get(name, "fUnit");
        if (-1 < interval)
        {
            interval = size*interval/100;
        }
        else
        {
            interval = GLAttributes::get(name, "unit");
        }
        if (-1 == interval || interval > unit/2)
        {
            return filter;
        }
        if (interval > maxInterval)
        {
            maxInterval = interval;
        }
    }
    return new GLLargeGPUFilter(filter, l, t, unit, maxInterval, flipH, flipV, swapxy);
}


void InWorkManager::releaseCurrentWork(size_t tid)
{
    auto pos = (mComposeWork).find(tid);
    if (pos != mComposeWork.end())
    {
        delete pos->second;
        mComposeWork.erase(pos);
    }
}


int InWorkManager::runForBitmapOpt(const GLBmp* src, GLBmp* dst, int* ids, float* ratios, int l, int t, int flipH, int flipV, int swapxy, int number)
{
    GLAUTOSTORAGE(composeRatios, double, number);
    for (int i=0; i<number; ++i)
    {
        composeRatios[i] = ratios[i];
    }
    if (!supportLargeFilter(mComposeIds, mComposeNumber, this, src->width()))
    {
        return 0;
    }
    int w = src->width();
    int h = src->height();
    if (1 == mComposeNumber)
    {
        auto name = getName(mComposeIds[0]);
        if (name == "Origin")
        {
            GPPtr<IGLFilter> cpufilter = IGLFilterFactory::create(name.c_str(), w, h);
            if (NULL!=cpufilter.get())
            {
                GPPtr<IGLFilter> lfw = turnLargeFilterIfNeeded(cpufilter, mComposeIds, mComposeNumber, this, l, t, src->width(), flipH, flipV, swapxy);
                lfw->vMap(composeRatios, mComposeNumber);
                lfw->vFilter(dst, src);
                return 1;
            }
        }
    }
    auto workfunc = [&](){
        GPPtr<IGLDrawWork> work = prepareComposeFilter(0, mComposeIds, mComposeNumber);
        work->vMap(composeRatios, mComposeNumber);
        GPPtr<GLvboBuffer> vs = GLvboBufferManager::createBasicPos();
        GPPtr<GLvboBuffer> ts = GLvboBufferManager::createBasicTex();
        GPPtr<IGLFilter> fw = turnLargeFilterIfNeeded(new GLGPUFilter(work, vs, ts), mComposeIds, mComposeNumber, this, l, t, w, flipH, flipV, swapxy);
        fw->vFilter(dst, src);
    };
    GPPtr<GLWork> work = new GLFunctionWork(workfunc);
    GPPtr<GLWorkSemore> s = OpenGLWorker::getInstance()->queueWork(work);
    s->wait();
    return 1;
}
