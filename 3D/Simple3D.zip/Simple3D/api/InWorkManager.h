#ifndef INWORKMANAGER_H
#define INWORKMANAGER_H
#include "GLInWork.h"
#include "GLShaderFactory.h"
#include "GLWorkThread.h"
#include <map>

class InWorkManager
{
public:
    enum {
        ORIGIN = -109
    };
    struct BitmapInfo
    {
        int w;
        int h;
        void* pixels;
    };
    InWorkManager();
    ~InWorkManager();
    void addWork(const char* name, const std::vector<BitmapInfo>& infos, float ratio);
    IGLDrawWork* prepareComposeFilter(int useoes, int* ids, int number);
    inline int getCur() const {return mCur;}
    void setIndex(int index);
    std::string getName(int index) const {return mResources[index]->name;}
    IGLDrawWork* createWork(int index,bool speedfirst=true);
    void runForBitmap(const GLBmp* src, GLBmp* dst, float* vs, float* ts, int* ids, float* ratios, int number);
    int runForBitmapOpt(const GLBmp* src, GLBmp* dst, int* ids, float* ratios, int l, int t, int flipH, int flipV, int swapxy, int number);
    void refresh(int* ids, float* ratios, int n);
    void releaseCurrentWork(size_t tid);
    void drawFrame(GLTexture* src, float* vs, float* ts, int useoes, size_t tid);
private:
    void reset(int n);
    IGLDrawWork* _prepare(int useoes, int ids);
    IGLDrawWork* _create(int useoes, int ids);
    std::vector<GLInWorkResource*> mResources;
    int mCur;
    std::map<size_t, IGLDrawWork* > mComposeWork;
    bool mNeedComposeFilterRefresh;
    double* mComposeRatios;
    int* mComposeIds;
    int mComposeNumber;
};
#endif
