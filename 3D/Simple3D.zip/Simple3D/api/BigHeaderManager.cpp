//
//  BigHeaderManager.cpp
//  simple3d
//
//  Created by jiangxiaotang on 15/9/1.
//  Copyright (c) 2015年 jiangxiaotang. All rights reserved.
//
#include <vector>
#include <math.h>
#include "utils/GLDebug.h"
#include "utils/GLAutoStorage.h"
#include "BigHeaderManager.h"
#include "algorithm/GLRegions.h"
#include "algorithm/GLGraphicCut.h"
#include "algorithm/GLSkinDetect.h"
#include "algorithm/GLScale.h"
#include "operator/GLFastBlurFilter.h"
#include "operator/GLTwoValueOperator.h"
#include "operator/GLSobelOperator.h"

#ifdef HAS_NEON
#include <arm_neon.h>
#endif
#ifdef GPCLOCK
#undef GPCLOCK
#define GPCLOCK
#endif

BigHeaderManager::BigHeaderManager()
{
}
BigHeaderManager::~BigHeaderManager()
{
}
void BigHeaderManager::setBitmap(GPPtr<GLBmp> src)
{
    GLASSERT(NULL!=src.get());
    mBackUpBitmap = src;
}

static void _refreshMask(GLGrayBitmap* count, const GLGrayBitmap* mask, int l, int t, int r, int b)
{
    auto h = mask->height();
    auto w = mask->width();
    auto th = count->height();
    auto tw = count->width();
    GLASSERT(r < tw);
    GLASSERT(b < th);
    GLASSERT(l <= r);
    GLASSERT(t <= b);
    for (int i=0; i<h; ++i)
    {
        auto mask_line = mask->getAddr(0, i);
        auto dst_line = count->getAddr(l, i+t);
        ::memcpy(dst_line, mask_line, w*sizeof(unsigned char));
    }
}



static void _alignBound(GLRect& bound, int align)
{
#define ALIGN_DOWN(x, align) ((x)/(align))*(align)
    bound.l = ALIGN_DOWN(bound.l, align);
    bound.r = ALIGN_DOWN(bound.r+1, align)-1;
    bound.t = ALIGN_DOWN(bound.t, align);
    bound.b = ALIGN_DOWN(bound.b+1, align)-1;
#undef ALIGN_DOWN
}

/*Graphic-Cut method with mask*/
bool BigHeaderManager::addNewMask(GLGrayBitmap* circle_seed, GLGrayBitmap* dst_mask, const GLRect& origin_bound, int scaleArea)
{
    GLASSERT(origin_bound.l <= origin_bound.r);
    GLASSERT(origin_bound.t <= origin_bound.b);
    GLASSERT(NULL!=mBackUpBitmap.get());
    GLRect bound = origin_bound;
    int w = bound.r-bound.l+1;
    int h = bound.b-bound.t+1;
    int scale = 1;
    if (w*h > scaleArea)
    {
        scale = sqrt(w*h/scaleArea);
    }
    _alignBound(bound, scale);
    w = bound.r-bound.l+1;
    h = bound.b-bound.t+1;
//    FUNC_PRINT(w);
//    FUNC_PRINT(h);
    if (w <=0 || h<=0)
    {
        return false;
    }
    GPPtr<GLGrayBitmap> crop_seed = GLScale::reduceBitmapCroped(circle_seed, bound.l, bound.t, bound.r, bound.b, scale);
    GPPtr<GLBmp> crop_bitmap = GLScale::reduceBitmapCroped(mBackUpBitmap.get(), bound.l, bound.t, bound.r, bound.b, scale);
    GLGraphicCut cut(450,30);
    bool success = cut.grabCut(crop_bitmap.get(), crop_seed.get(), 128, 255);
    if (!success)
    {
        return false;
    }
    if (scale > 1)
    {
        crop_seed = GLScale::scaleBitmap(crop_seed.get(), scale);
    }
    _refreshMask(dst_mask, crop_seed.get(), bound.l, bound.t, bound.r, bound.b);
    return true;
}


void BigHeaderManager::eclosion(GLGrayBitmap* dstmask, int _shift)
{
    GLASSERT(NULL!=dstmask);
    GPCLOCK;
    const int shift = _shift*2;
    if (dstmask->width() <= (1 << (shift/2)))
    {
        return;
    }
    GLFastBlurFilter filter(shift);
    GLGrayBitmap tempmask(dstmask->width(), dstmask->height());
    filter.vFilter(&tempmask, dstmask);
    unsigned char* dst_ = dstmask->getAddr(0, 0);
    unsigned char* src_ = tempmask.getAddr(0, 0);
    int size = tempmask.width()*tempmask.height();
    ::memcpy(dst_, src_, size*sizeof(unsigned char));
    return;
}

static void _refresh(GLRect& r, int x, int y)
{
    if (r.l > x) r.l = x;
    if (r.r < x) r.r = x;
    if (r.t > y) r.t = y;
    if (r.b < y) r.b = y;
}

GLRect BigHeaderManager::getBound(const GLGrayBitmap* mask, int threhold)
{
    GLASSERT(NULL!=mask);
    auto w = mask->width();
    auto h = mask->height();
    GLRect r;
    r.l = w-1;
    r.r = 0;
    r.t = h-1;
    r.b = 0;
    for (int y=0; y<mask->height();++y)
    {
        auto _pl = mask->getAddr(0, y);
        for (int x=0; x<w; ++x)
        {
            if (_pl[x] > threhold)
            {
                _refresh(r, x, y);
            }
        }
    }
    return r;
}

void BigHeaderManager::crop(GLBmp* dst, const GLGrayBitmap* mask, int l, int t)
{
    GLASSERT(NULL!=dst);
    GLASSERT(NULL!=mask);
    GLASSERT(NULL!=mBackUpBitmap.get());
    GLASSERT(l>=0 && t>=0);
    GLASSERT(dst->width()+l <= mBackUpBitmap->width());
    GLASSERT(dst->height()+t<= mBackUpBitmap->height());
    GLASSERT(mask->width() == mBackUpBitmap->width());
    GLASSERT(mask->height() == mBackUpBitmap->height());
    auto w = dst->width();
    auto h = dst->height();
    for (int y=0; y<h; ++y)
    {
        for (int x=0; x<w; ++x)
        {
            auto dst_ = dst->getAddr(x, y);
            auto src_ = mBackUpBitmap->getAddr(x+l, y+t);
            auto mask_ = mask->getAddr(x+l, y+t);
            int m = mask_[0];
            for (int i=0; i<3; ++i)
            {
                int s = src_[i];
                dst_[i] = m*s/255;
            }
            dst_[3] = m;
        }
    }
}

GLRect BigHeaderManager::reduceToOneRegion(GLGrayBitmap* mask)
{
    return GLRegion::reduceToOneRegion(mask);
}


static std::vector<std::pair<int, int>> _filterPoints(const std::vector<std::pair<int, int>>& origin, int interval, int thredhold)
{
    std::vector<std::pair<int, int>> filterPoints;
    int cd = interval;
    filterPoints.push_back(origin[0]);
    for (int cur=1; cur<origin.size(); ++cur)
    {
        if (::abs(origin[cur].first-origin[cur-1].first)>thredhold || ::abs(origin[cur].second-origin[cur-1].second)>thredhold)
        {
            cd = 0;
        }
        if (0 >= cd)
        {
            filterPoints.push_back(origin[cur]);
            cd = interval+1;
        }
        cd--;
    }
    return filterPoints;
}


GLMatrix<int>* BigHeaderManager::getBoundAxis(GLGrayBitmap* mask_src, const GLRect& r, int offset, int intervalrate, int thredhold, unsigned char pixelThred)
{
    GPCLOCK;
    GLASSERT(intervalrate>=0);
    int scale = sqrt((r.r-r.l+1)*(r.b-r.t+1)/200000.0);
    //int scale = 1;
    if (scale < 1)
    {
        scale = 1;
    }
    offset = offset / scale;
    GPPtr<GLGrayBitmap> mask = GLScale::reduceBitmapCroped(mask_src, r.l, r.t, r.r, r.b, scale);
    GLTwoValueOperator::filter(mask.get(), mask.get(), pixelThred);
    /*Find first point*/
    std::vector<std::pair<int, int>> path;
    GLRegion::findContour(mask.get(), path);
    if (path.empty())
    {
        return NULL;
    }
    int interval = (int)((double)intervalrate*(double)path.size())/100.0f;
    if (interval > 1)
    {
        path = _filterPoints(path, interval, thredhold);
    }
    if (offset != 0)
    {
        GLRegion::offsetContour(path, path, offset);
    }
    
    /*Find all bounds end*/
    auto result = new GLMatrix<int>((int)(path.size()), 2);
    auto _rx = result->getAddr(0);
    auto _ry = result->getAddr(1);
    for (int i=0; i<result->width(); ++i)
    {
        _rx[i] = path[i].first*scale;
        _ry[i] = path[i].second*scale;
    }
    return result;
}



void BigHeaderManager::skinDetect(GLGrayBitmap* mask, unsigned char skin, unsigned char noskin)
{
    GLASSERT(NULL!=mBackUpBitmap.get());
    GLASSERT(mBackUpBitmap->width() == mask->width());
    GLASSERT(mBackUpBitmap->height() == mask->height());
    GLSkinDetect::run(mBackUpBitmap.get(), mask, skin, noskin);
}

void BigHeaderManager::addNewMaskConnected(GLGrayBitmap* seed, GLGrayBitmap* dst_mask, const GLRect& bound, int scaleArea)
{
    addNewMask(seed, dst_mask, bound, scaleArea);
    GLRegion::reduceToOneRegion(dst_mask, &bound, 1);
}


void BigHeaderManager::fillHole(GLGrayBitmap* mask)
{
    GLRect bound = getBound(mask, 254);
    if (!bound.valid())
    {
        return;
    }
    GPPtr<GLGrayBitmap> cropMask = GLScale::reduceBitmapCroped(mask, bound.l, bound.t, bound.r, bound.b, 1);
    GLRegion::fillHole(cropMask.get());
    _refreshMask(mask, cropMask.get(), bound.l, bound.t, bound.r, bound.b);
}
