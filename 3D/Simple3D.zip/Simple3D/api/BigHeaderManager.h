//
//  BigHeaderManager.h
//  simple3d
//
//  Created by jiangxiaotang on 15/9/1.
//  Copyright (c) 2015年 jiangxiaotang. All rights reserved.
//

#ifndef __simple3d__BigHeaderManager__
#define __simple3d__BigHeaderManager__

#include <stdio.h>
#include "algorithm/GLMatrix.h"
#include "utils/RefCount.h"
#include "core/GLBmp.h"
#include "core/GLRect.h"
#include "core/GLGrayBitmap.h"
class BigHeaderManager:public RefCount
{
public:
    BigHeaderManager();
    virtual ~BigHeaderManager();
    
    /*设定原图，必须为ARGB格式*/
    void setBitmap(GPPtr<GLBmp> src);
    
    /*根据种子点，运行grabcut算法，确定目标区域
     种子值的参数值含义：
     255：确定前景
     128-254：疑似前景
     1-127：疑似背景
     0：确定背景
     * dst_mask最终填充值是 0 / 255，表示背景/前景（由于双线性插值，有可能在边缘出现过渡值）
     * dst_mask 和 seed 都为 alpha-8格式，其长宽必须与之前设定的 Bitmap 相同。
     * bound：参与运算区域限制范围
     * scaleArea：执行 grabcut 的区域限制大小，先将原图和seed缩小到 scaleArea 这个尺寸执行算法，再将结果放大插值回去
     */
    bool addNewMask(GLGrayBitmap* seed, GLGrayBitmap* dst_mask, const GLRect& bound, int scaleArea=50000);
    
    /*
     *在addNewMask的基础上，剔除掉不与新增区域连通的点
     */
    void addNewMaskConnected(GLGrayBitmap* seed, GLGrayBitmap* dst_mask, const GLRect& bound, int scaleArea=50000);
    
    /*将之前设定的Bitmap，按mask值作alpha乘法，减淡算到dst上
     * dst(x, y) = mask(x+l, y+t)*mBackUpBitmap(x+l, y+t)/255.0
     * mask 长宽必须与 mBackUpBitmap 相等
     * l、t 分别表示左偏移和上偏移，必须保证 l+dst.w <= mBackUpBitmap.w && t+dst.h <= mBackUpBitmap.h
     */
    void crop(GLBmp* dst, const GLGrayBitmap* mask, int l, int t);
    
    
    /*获取mask的有效范围，在这个范围之外mask的像素值均为0*/
    static GLRect getBound(const GLGrayBitmap* mask, int thredhold=0);
    
    /*羽化（快速模糊），模糊半径为(1<<shift)*/
    static void eclosion(GLGrayBitmap* dstmask, int shift=4);
    
    /*把mask缩减至惟一一个连通域（保留最大那个）*/
    static GLRect reduceToOneRegion(GLGrayBitmap* mask);
    
    /*填补中心的洞*/
    static void fillHole(GLGrayBitmap* mask);
    
    /*获取边界坐标，返回nX2的矩阵，第一行是x值，第二行是y值
     *需要保证输入图像只有单一连通区域，若有多个连通区域结果不确定
     *interval表示所取得的坐标需要做interval阶平滑
     */
    static GLMatrix<int>* getBoundAxis(GLGrayBitmap* mask_src, const GLRect& r, int offset, int intervalrate, int thredhold=1, unsigned char pixelThred=254);
    
    /*肤色检测，以 mBackUpBitmap 为基准*/
    void skinDetect(GLGrayBitmap* mask, unsigned char skin, unsigned char noskin);
    
    /*将边界内灰度值小于阈值的的像素填成指定颜色, 需要输入图像是单连通*/
    static void colorFillSingleRegion(GLBmp* dst, uint32_t color, unsigned char thredhold);

private:
    GPPtr<GLBmp> mBackUpBitmap;
};

#endif /* defined(__simple3d__BigHeaderManager__) */
