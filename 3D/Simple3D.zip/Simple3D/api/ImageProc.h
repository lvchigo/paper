#ifndef IMAGEPROC_H
#define IMAGEPROC_H
#include "algorithm/GLMatrix.h"
#include <vector>
#include <string>
class GLGrayBitmap;
class GLBmp;
class ImageProc
{
public:
    /*图像配准，得到 src->dst 的变换矩阵*/
    static GPPtr<GLMatrix<float>> computeForARGB(void* dst, void* src, int w, int h);
    /*将两张Bitmap按掩模Mask合成，合成结果设在第一张图上，传入的三幅图像必须宽高相同*/
    static void bitmapMergeMask(GLBmp* dst, const GLBmp* src, const GLGrayBitmap* mask, int xoffset, int yoffset);
    /*获取达到rate比例的最小宽*/
    static int meanImageWidth(const GLGrayBitmap* mask, float rate=0.6f);
    
    
    /*使用CPU版本的滤镜，当找到相应滤镜时，执行并返回true，否则返回false
     * src 和 dst 为ARGB图像，其宽高必须相同
     * name 目前支持：
        Meifu （美肤）
        Blur（模糊）
     * rate 为 0.0-1.0的一个系数
     */
    static bool imageFilter(GLBmp* dst, GLBmp* src, const char* name, double rate);
    /*获取所有支持的filter名称*/
    static std::vector<std::string> getAllFilterName();
    
    /*图像变形，采用下面文章描述的算法：
     http://www.cnblogs.com/xiaotie/archive/2009/12/08/1619046.html
     * src 和 dst 为ARGB图像，其宽高必须相同，src和dst可以是同一幅图像
     * l、t、w、h圈定变形区域
     * mx和my是变形目的点
     */
    static void imageWarping(GLBmp* dst, const GLBmp* src, int l, int t, int w, int h, int mx, int my);
};
#endif
