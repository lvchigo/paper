//
//  GLShallowFilter.cpp
//  simple3d
//
//  Created by jiangxiaotang on 15/8/12.
//  Copyright (c) 2015年 jiangxiaotang. All rights reserved.
//

#include <stdio.h>
#include "GLGuideFilter.h"
#include "IGLFilterFactory.h"
#include "GLChainFilter.h"
#include "GLBrightFilter.h"
class guild_creator:public IGLFilterCreater
{
public:
    virtual IGLFilter* vCreate(int w, int h) const
    {
        GLChainFilter* f = new GLChainFilter(new GLGuideFilter(std::min(128.0, w*0.03), 0.005));
        f->addFilter(new GLBrightFilter);
        return f;
    }
};

static IGLFilterCreatorRegister<guild_creator> __T("Meifu");
