#include "GLChainFilter.h"

void GLChainFilter::vFilter(GLBmp* dst, const GLBmp* src) const
{
    /*TODO Assum that all filter can handle dst = src case*/
    GLASSERT(NULL!=dst);
    GLASSERT(NULL!=src);
    GLASSERT(dst->width()==src->width());
    GLASSERT(dst->height()==src->height());
    mFirst->vFilter(dst, src);
    for (auto f : mFilters)
    {
        f->vFilter(dst, dst);
    }
}
size_t GLChainFilter::vMap(double* parameters, size_t n)
{
    if (NULL==parameters)
    {
        size_t sum = mFirst->vMap(NULL, 0);
        for (auto f:mFilters)
        {
            sum+=f->vMap(NULL, 0);
        }
        return sum;
    }
    size_t cur = mFirst->vMap(parameters, n);
    for (auto f : mFilters)
    {
        auto pcur = parameters+cur;
        cur += f->vMap(pcur, n-cur);
    }
    return cur;
}
