//
//  GLLargeGPUFilter.cpp
//  simple3d
//
//  Created by jiangxiaotang on 15/7/25.
//  Copyright (c) 2015年 jiangxiaotang. All rights reserved.
//

#include "GLLargeGPUFilter.h"
#include "GLvboBufferManager.h"
#include "GLAutoFbo.h"
#include "GLAutoStorage.h"
#include "GP_Clock.h"
GLLargeGPUFilter::GLLargeGPUFilter(GPPtr<IGLFilter> w, int l, int t, int unit, int interval, bool fliph, bool flipv, bool swapxy)
{
    GLASSERT(NULL!=w.get());
    GLASSERT(100 <= unit);
    GLASSERT(0<=l);
    GLASSERT(0<=t);
    mWork = w;
    mUnit = unit;
    mL = l;
    mT = t;
    mInterval = (interval/2)*2;
    mFlipV = flipv;
    mFlipH = fliph;
    if (swapxy)
    {
        mFlipV = fliph;
        mFlipH = flipv;
    }
    mSwapXY = swapxy;
}
GLLargeGPUFilter::~GLLargeGPUFilter()
{
}

size_t GLLargeGPUFilter::vMap(double* parameters, size_t n)
{
    return mWork->vMap(parameters, n);
}

static void _copyline(unsigned char* dest, unsigned char* source, int w, int bpp, bool flip)
{
    if (!flip)
    {
        ::memcpy(dest, source, bpp*w*sizeof(unsigned char));
    }
    else
    {
        for (int i=0; i<w; ++i)
        {
            ::memcpy(dest+i*bpp, source+(w-i-1)*bpp, bpp);
        }
    }
}
static void _DoFlipCopy(unsigned char* dst, unsigned char* src, int dw, int sw, int w, int h, bool flipH, bool flipV, int bpp)
{
    if (flipV)
    {
        for (int i=0; i<h; ++i)
        {
            auto dest = dst + (h-i-1)*dw*bpp;
            auto source = src + i*sw*bpp;
            _copyline(dest, source, w, bpp, flipH);
        }
    }
    else
    {
        for (int i=0; i<h; ++i)
        {
            auto dest = dst + i*dw*bpp;
            auto source = src + i*sw*bpp;
            _copyline(dest, source, w, bpp, flipH);
        }
    }
}

static void _DoFlipSelf(GLBmp* target, bool flipH, bool flipV)
{
    if (!flipH && !flipV) return;
    unsigned char* pixels = (unsigned char*)(target->pixels());
    auto bpp = target->bpp();
    auto w = target->width();
    auto h = target->height();
    if (flipV)
    {
        GLAUTOSTORAGE(temp, unsigned char, w*bpp);
        for (int i=0; i<h/2; ++i)
        {
            auto dest = pixels + (h-i-1)*w*bpp;
            auto source = pixels + i*w*bpp;
            ::memcpy(temp, dest, w*bpp*sizeof(unsigned char));
            _copyline(dest, source, w, bpp, flipH);
            _copyline(source, temp, w, bpp, flipH);
        }
    }
    else
    {
        GLAUTOSTORAGE(temp, unsigned char, bpp);
        for (int i=0; i<h; ++i)
        {
            auto tar = pixels + i*w*bpp;
            for (int j=0; j<w/2;++j)
            {
                auto dest = tar + j*bpp;
                auto src = tar + (w-j-1)*bpp;
                ::memcpy(temp, dest, bpp*sizeof(unsigned char));
                ::memcpy(dest, src, bpp*sizeof(unsigned char));
                ::memcpy(src, temp, bpp*sizeof(unsigned char));
            }
        }
    }
}
#ifdef HAS_NEON
#include <arm_neon.h>
#endif

static void _transpose(unsigned char* dest_s, unsigned char* source_s, int dstw, int srcw, int dw, int dh, int bpp)
{
    int ista=0,jsta=0;
    GLASSERT(bpp==4);
#ifdef HAS_NEON
    const int unit = 4;//必须是4
    //GPCLOCK;
    int nw = dw/unit;
    int nh = dh/unit;
    int srcstride = srcw*bpp;
    int dststride = dstw*bpp;
    if (nw > 1 && nh > 1)
    {
        asm (
                "mov r5, #4\t\n"
                "mul r8, %[srcstride], r5\t\n"
                "mul r9, %[dststride], r5\t\n"
                "mul r10, r5, r5\t\n"//In fact, it's 4*r5
                //"movs r5, %[nh]\t\n"//i
                "sub r5, %[nh], #1\t\n"
                "1:\t\n"
                "sub r4, %[nw], #1\t\n"//j
                "2:\t\n"
                "mla r6, r4, r8, %[source_s]\t\n"
                "mla r6, r5, r10, r6\t\n"
                "vld1.32 {d1, d2}, [r6]\t\n"
                "add r6, r6, %[srcstride]\t\n"
                "vld1.32 {d3, d4}, [r6]\t\n"
                "add r6, r6, %[srcstride]\t\n"
                "vld1.32 {d5, d6}, [r6]\t\n"
                "add r6, r6, %[srcstride]\t\n"
                "vld1.32 {d7, d8}, [r6]\t\n"

                /*Transpose internal*/
                "vtrn.32 d1, d3\t\n"
                "vtrn.32 d2, d4\t\n"
                "vtrn.32 d5, d7\t\n"
                "vtrn.32 d6, d8\t\n"
                "vswp d2, d5\t\n"
                "vswp d4, d7\t\n"

                "mla r7, r5, r9, %[dest_s]\t\n"
                "mla r7, r4, r10, r7\t\n"
                "vst1.32 {d1, d2}, [r7]\t\n"
                "add r7, r7, %[dststride]\t\n"
                "vst1.32 {d3, d4}, [r7]\t\n"
                "add r7, r7, %[dststride]\t\n"
                "vst1.32 {d5, d6}, [r7]\t\n"
                "add r7, r7, %[dststride]\t\n"
                "vst1.32 {d7, d8}, [r7]\t\n"

                "subs r4, r4, #1\t\n"
                "bne 2b\t\n"//Loop1

                "mla r6, r4, r8, %[source_s]\t\n"
                "mla r6, r5, r10, r6\t\n"
                "vld1.32 {d1, d2}, [r6]\t\n"
                "add r6, r6, %[srcstride]\t\n"
                "vld1.32 {d3, d4}, [r6]\t\n"
                "add r6, r6, %[srcstride]\t\n"
                "vld1.32 {d5, d6}, [r6]\t\n"
                "add r6, r6, %[srcstride]\t\n"
                "vld1.32 {d7, d8}, [r6]\t\n"

                /*Transpose internal*/
                "vtrn.32 d1, d3\t\n"
                "vtrn.32 d2, d4\t\n"
                "vtrn.32 d5, d7\t\n"
                "vtrn.32 d6, d8\t\n"
                "vswp d2, d5\t\n"
                "vswp d4, d7\t\n"

                "mla r7, r5, r9, %[dest_s]\t\n"
                "mla r7, r4, r10, r7\t\n"
                "vst1.32 {d1, d2}, [r7]\t\n"
                "add r7, r7, %[dststride]\t\n"
                "vst1.32 {d3, d4}, [r7]\t\n"
                "add r7, r7, %[dststride]\t\n"
                "vst1.32 {d5, d6}, [r7]\t\n"
                "add r7, r7, %[dststride]\t\n"
                "vst1.32 {d7, d8}, [r7]\t\n"

                "subs r5, r5, #1\t\n"
                "bne 1b\t\n"//Loop2

                /*Last line*/
                "sub r4, %[nw], #1\t\n"//j
                "4:\t\n"
                "mla r6, r4, r8, %[source_s]\t\n"
                "mla r6, r5, r10, r6\t\n"
                "vld1.32 {d1, d2}, [r6]\t\n"
                "add r6, r6, %[srcstride]\t\n"
                "vld1.32 {d3, d4}, [r6]\t\n"
                "add r6, r6, %[srcstride]\t\n"
                "vld1.32 {d5, d6}, [r6]\t\n"
                "add r6, r6, %[srcstride]\t\n"
                "vld1.32 {d7, d8}, [r6]\t\n"

                /*Transpose internal*/
                "vtrn.32 d1, d3\t\n"
                "vtrn.32 d2, d4\t\n"
                "vtrn.32 d5, d7\t\n"
                "vtrn.32 d6, d8\t\n"
                "vswp d2, d5\t\n"
                "vswp d4, d7\t\n"

                "mla r7, r5, r9, %[dest_s]\t\n"
                "mla r7, r4, r10, r7\t\n"
                "vst1.32 {d1, d2}, [r7]\t\n"
                "add r7, r7, %[dststride]\t\n"
                "vst1.32 {d3, d4}, [r7]\t\n"
                "add r7, r7, %[dststride]\t\n"
                "vst1.32 {d5, d6}, [r7]\t\n"
                "add r7, r7, %[dststride]\t\n"
                "vst1.32 {d7, d8}, [r7]\t\n"

                "subs r4, r4, #1\t\n"
                "bne 4b\t\n"//Loop1
                "mla r6, r4, r8, %[source_s]\t\n"
                "mla r6, r5, r10, r6\t\n"
                "vld1.32 {d1, d2}, [r6]\t\n"
                "add r6, r6, %[srcstride]\t\n"
                "vld1.32 {d3, d4}, [r6]\t\n"
                "add r6, r6, %[srcstride]\t\n"
                "vld1.32 {d5, d6}, [r6]\t\n"
                "add r6, r6, %[srcstride]\t\n"
                "vld1.32 {d7, d8}, [r6]\t\n"

                /*Transpose internal*/
                "vtrn.32 d1, d3\t\n"
                "vtrn.32 d2, d4\t\n"
                "vtrn.32 d5, d7\t\n"
                "vtrn.32 d6, d8\t\n"
                "vswp d2, d5\t\n"
                "vswp d4, d7\t\n"

                "mla r7, r5, r9, %[dest_s]\t\n"
                "mla r7, r4, r10, r7\t\n"
                "vst1.32 {d1, d2}, [r7]\t\n"
                "add r7, r7, %[dststride]\t\n"
                "vst1.32 {d3, d4}, [r7]\t\n"
                "add r7, r7, %[dststride]\t\n"
                "vst1.32 {d5, d6}, [r7]\t\n"
                "add r7, r7, %[dststride]\t\n"
                "vst1.32 {d7, d8}, [r7]\t\n"

                "5:\t\n"
                : [srcstride] "+r" (srcstride), [dststride] "+r" (dststride), [source_s] "+r" (source_s), [dest_s] "+r" (dest_s), [nw] "+r" (nw), [nh] "+r" (nh)
                :
                    : "r4", "r5", "r6", "r7", "r8", "r9","r10", "cc","memory", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8"
                        );
    }
    ista = nh*unit;
    jsta = nw*unit;
#endif
    //ista = 0; jsta = 0;/*Debug*/
    for (int i=ista; i<dh; ++i)
    {
        for (int j=0; j<dw; ++j)
        {
            uint32_t* dest =   (uint32_t*)(dest_s + (i*dstw+j)*bpp);
            uint32_t* source = (uint32_t*)(source_s + (j*srcw+i)*bpp);
//            if (*dest != *source)
//            {
//                GPPRINT("%d,%d error", i, j);
//            }
            *dest = *source;
        }
    }
    for (int i=0; i<ista; ++i)
    {
        for (int j=jsta; j<dw; ++j)
        {
            uint32_t* dest =   (uint32_t*)(dest_s + (i*dstw+j)*bpp);
            uint32_t* source = (uint32_t*)(source_s + (j*srcw+i)*bpp);
            *dest = *source;
        }
    }
}

void GLLargeGPUFilter::_runForRegion(const GLBmp* src, GLBmp* dst, int dl, int dt, int dw, int dh) const
{
    GLASSERT(NULL!=src);
    GLASSERT(NULL!=dst);
    GLASSERT(0<=dl && 0<=dt);
    GLASSERT(dst->width()>=dl+dw && dst->height()>=dt+dh);
    const int bpp = 4;
    /*Compute Src position for t, l, w, h*/
    int st = mT + dt;
    int sl = mL + dl;
    int sb = st + dh;
    int sr = sl + dw;
    int w = dw+mInterval;
    int h = dh+mInterval;
    int sw = src->width();
    int sh = src->height();
    if (mSwapXY)
    {
        sh = src->width();
        sw = src->height();
    }
    if (mFlipV)
    {
        auto temp = st;
        st = sh-sb-1;
        sb = sh-temp-1;
    }
    if (mFlipH)
    {
        sl = sw-sr-1;
    }
    if (mSwapXY)
    {
        auto temp = st;
        st = sl;
        sl = temp;
        temp = w;
        w = h;
        h = temp;
    }

    /*Add Interval to avoid edge effect*/
    st-=mInterval/2;sl-=mInterval/2;

    GPPtr<GLBmp> bmp = new GLBmp(w, h);
    int offset = 0;
    int stride = w;
    if (sl < 0)
    {
        offset = -sl;
        stride = sl + w;
    }
    if (sl+offset+stride > src->width())
    {
        stride = src->width()-sl-offset;
    }
    GLASSERT(sl+offset+stride<=src->width());
    /*Copy src Region Pixels to bmp. Do Crop here*/
    for (int i=0; i<h; ++i)
    {
        if (i+st<0 || i+st >=src->height()) continue;
        auto dest = (unsigned char*)(bmp->pixels())+(i*w+offset)*bpp;
        auto source = (unsigned char*)(src->pixels())+((i+st)*src->width()+sl+offset)*bpp;
        ::memcpy(dest, source, bpp*stride*sizeof(unsigned char));
    }
    /*Run Filter, src and dest are the same*/
    mWork->vFilter(bmp.get(), bmp.get());

    /*Copy Region Pixels to dst bmp. Do flip and swap if needed*/
    auto dest_s = (unsigned char*)(dst->pixels())+((dt)*dst->width()+dl)*bpp;
    auto source_s = (unsigned char*)(bmp->pixels())+((mInterval/2)*bmp->width()+(mInterval/2))*bpp;
    if (!mSwapXY)
    {
        _DoFlipCopy(dest_s, source_s, dst->width(), bmp->width(), dw, dh, mFlipH, mFlipV, bmp->bpp());
    }
    else
    {
        //GPCLOCK;
        /*mFlipV and mFlipH must be swap now*/
        _DoFlipSelf(bmp.get(), mFlipV, mFlipH);
        _transpose(dest_s, source_s, dst->width(), bmp->width(), dw, dh, bpp);
    }
}

void GLLargeGPUFilter::vFilter(GLBmp* dst, const GLBmp* src) const
{
    GLASSERT(NULL!=dst);
    GLASSERT(NULL!=src);
    /*Divide into Net*/
    int w_n = (dst->width()+mUnit-1)/mUnit;
    int h_n = (dst->height()+mUnit-1)/mUnit;
    for (int i=0; i<h_n; ++i)
    {
        for (int j=0; j<w_n; ++j)
        {
            int dl = j*mUnit;
            int dt = i*mUnit;
            int cw = dst->width()-dl > mUnit ? mUnit : dst->width()-dl;
            int ch = dst->height()-dt > mUnit ? mUnit : dst->height()-dt;
            _runForRegion(src, dst, dl, dt, cw, ch);
        }
    }
}
