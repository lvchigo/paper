//
//  GLOriginFilter.cpp
//  simple3d
//
//  Created by jiangxiaotang on 15/7/29.
//  Copyright (c) 2015年 jiangxiaotang. All rights reserved.
//

#include "GLOriginFilter.h"
#include <string.h>
void GLOriginFilter::vFilter(GLBmp* dst, const GLBmp* src) const
{
    if (src == dst)
    {
        return;
    }
    GLASSERT(NULL!=dst);
    GLASSERT(NULL!=src);
    GLASSERT(src->width() == dst->width());
    GLASSERT(src->height() == dst->height());
    auto dstpixels = (unsigned char*)(dst->pixels());
    auto srcpixels = (unsigned char*)(src->pixels());
    ::memcpy(dstpixels, srcpixels, src->width()*src->height()*src->bpp()*sizeof(unsigned char));
}


#include "IGLFilterFactory.h"
class ori_creator:public IGLFilterCreater
{
public:
    virtual IGLFilter* vCreate(int w, int h) const
    {
        return new GLOriginFilter;
    }
};

static IGLFilterCreatorRegister<ori_creator> __T("Origin");

