#include "JiuYanFilter.h"

const char* JiuYanFilterSign()
{
    const char* str = "HangZhouJiuYanKeJi";
    return str;
}
