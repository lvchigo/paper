//
//  GLBoxFilter.cpp
//  simple3d
//
//  Created by jiangxiaotang on 15/7/13.
//  Copyright (c) 2015年 jiangxiaotang. All rights reserved.
//

#include "filter/GLBoxFilter.h"
#include "GP_Clock.h"

#ifdef HAS_NEON
#undef HAS_NEON
#endif

#ifdef HAS_NEON
#include <arm_neon.h>
#endif

GLBoxFilter::GLBoxFilter(size_t bw, size_t bh)
{
    GLASSERT(bw >0 && bh >0);
    mW = bw;
    mH = bh;
}
GLBoxFilter::~GLBoxFilter()
{
}

void GLBoxFilter::compute(size_t* dst_sum2, size_t* dst_sum, unsigned char* src, size_t w, size_t h)
{
    //GPCLOCK;
    GLASSERT(NULL!=dst_sum);
    GLASSERT(NULL!=dst_sum2);
    auto dst_stride = w;
    auto src_stride = w;
    GLAUTOSTORAGE(bufferSum, unsigned int, w);
    GLAUTOSTORAGE(bufferSum2, unsigned int, w);
    ::memset(dst_sum2, 0, sizeof(size_t)*w*h);
    ::memset(dst_sum, 0, sizeof(size_t)*w*h);
    ::memset(bufferSum, 0, sizeof(unsigned int)*w);
    ::memset(bufferSum2, 0, sizeof(unsigned int)*w);
    for (size_t i=0; i<mH; ++i)
    {
        auto sum = bufferSum;
        auto sum2 = bufferSum2;
        auto pixels = src + src_stride*i;
        for (size_t j=0; j<w; ++j)
        {
            auto p = pixels[j];
            sum[j] += p;
            sum2[j] += p*p;
        }
    }
    for (int i=0; i<h-mH; ++i)
    {
        auto window1 = dst_sum + dst_stride*(i+(mH/2)) + (mW/2);
        auto window2 = dst_sum2 + dst_stride*(i+(mH/2)) + (mW/2);
        size_t Xsum = 0;
        size_t Xsum2 = 0;
        int sta;
        for (int j=0; j<mW; ++j)
        {
            Xsum += bufferSum[j];
            Xsum2 += bufferSum2[j];
        }
        *window1 = Xsum;
        *window2 = Xsum2;
        sta = 1;
        
        for(int x=sta; x<w-mW; ++x)
        {
            Xsum = Xsum-bufferSum[(x-1)]+bufferSum[(mW-1+x)];
            Xsum2 = Xsum2-bufferSum2[(x-1)]+bufferSum2[(mW-1+x)];
            *(window1+x) = Xsum;
            *(window2+x) = Xsum2;
        }
        auto img = src + src_stride*i;
        auto img_det = img + src_stride*mH;
        sta = 0;
#ifdef HAS_NEON
        int uw = w/8;
        auto _img = img;
        auto _img_det = img_det;
        auto _sum = bufferSum;
        auto _sum2 = bufferSum2;
        asm (
            "movs r4, %[uw]\t\n"
            "beq 2f\t\n"
            "1:\t\n"
            "vld1.8 d0, [%[_img]]!\t\n"
            "vld1.8 d1, [%[_img_det]]!\t\n"
            "vld4.32 {d2-d5}, [%[_sum]]\t\n"//q1, q2
            "vld4.32 {d6-d9}, [%[_sum2]]\t\n"//q3, q4
            /*d0 - q5, q6*/
            "vmovl.u8 q9, d0\t\n"
            "vmovl.u16 q5, d18\t\n"
            "vmovl.u16 q6, d19\t\n"
            /*d1 - q7, q8*/
            "vmovl.u8 q9, d1\t\n"
            "vmovl.u16 q7, d18\t\n"
            "vmovl.u16 q8, d19\t\n"
            /*compute bufferSum*/
            "vsub.u32 q1, q1, q5\t\n"
            "vsub.u32 q2, q2, q6\t\n"
            "vadd.u32 q1, q1, q7\t\n"
            "vadd.u32 q2, q2, q8\t\n"
            /*compute bufferSum2*/
            "vmls.u32 q3, q5, q5\t\n"
            "vmls.u32 q4, q6, q6\t\n"
            "vmla.u32 q3, q7, q7\t\n"
            "vmla.u32 q4, q8, q8\t\n"
            
            /*Store*/
            "vst4.32 {d2-d5}, [%[_sum]]!\t\n"//q1, q2
            "vst4.32 {d6-d9}, [%[_sum2]]!\t\n"//q3, q4
            
            "subs r4, r4, #1\t\n"
            "bne 1b\t\n"
            "2:\t\n"
            : [_img] "+r" (_img), [_img_det] "+r" (_img_det), [uw] "+r" (uw), [_sum] "+r" (_sum), [_sum2] "+r" (_sum2)
            :
            : "r4", "cc","memory", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "d10", "d11", "d12", "d13", "d14", "d15", "d16", "d17", "d18", "d19"
        );
        sta = uw*8;
#endif
        for(int x=sta; x<w; x++)
        {
            unsigned char pixel = img[x];
            unsigned char pixel2 = img_det[x];
            bufferSum[x] = bufferSum[x] - pixel + pixel2;
            bufferSum2[x] = bufferSum2[x] - pixel*pixel + pixel2*pixel2;
        }
    }
}

void GLBoxFilter::computeWithShift(size_t* dst_sum2, size_t* dst_sum, unsigned char* src, size_t w, size_t h, size_t shift)
{
    GLASSERT(NULL!=dst_sum);
    GLASSERT(NULL!=dst_sum2);
    auto dst_stride = w;
    auto src_stride = w;
    GLAUTOSTORAGE(bufferSum, size_t, w);
    GLAUTOSTORAGE(bufferSum2, size_t, w);
    ::memset(dst_sum2, 0, sizeof(size_t)*w*h);
    ::memset(dst_sum, 0, sizeof(size_t)*w*h);
    ::memset(bufferSum, 0, sizeof(size_t)*w);
    ::memset(bufferSum2, 0, sizeof(size_t)*w);
    for (size_t i=0; i<mH; ++i)
    {
        auto sum = bufferSum;
        auto sum2 = bufferSum2;
        auto pixels = src + src_stride*i;
        for (size_t j=0; j<w; ++j)
        {
            auto p = pixels[j];
            sum[j] += p;
            sum2[j] += p*p;
        }
    }
    for (size_t i=0; i<h-mH; ++i)
    {
        auto window1 = dst_sum + dst_stride*(i+(mH/2)) + (mW/2);
        auto window2 = dst_sum2 + dst_stride*(i+(mH/2)) + (mW/2);
        size_t Xsum = 0;
        size_t Xsum2 = 0;
        for (size_t j=0; j<mW; ++j)
        {
            Xsum += bufferSum[j];
            Xsum2 += bufferSum2[j];
        }
        *window1 = Xsum >> shift;
        *window2 = Xsum2 >> shift;
        
        for(size_t x=1; x<w-mW; ++x)
        {
            Xsum = Xsum-bufferSum[(x-1)]+bufferSum[(mW-1+x)];
            Xsum2 = Xsum2-bufferSum2[(x-1)]+bufferSum2[(mW-1+x)];
            *(window1+x) = Xsum >> shift;
            *(window2+x) = Xsum2 >> shift;
        }
        auto img = src + src_stride*i;
        auto img_det = img + src_stride*mH;
        for(size_t x=0; x<w; x++)
        {
            unsigned char pixel = img[x];
            unsigned char pixel2 = img_det[x];
            bufferSum[x] = bufferSum[x] - pixel + pixel2;
            bufferSum2[x] = bufferSum2[x] - pixel*pixel + pixel2*pixel2;
        }
    }
}

void GLBoxFilter::computeWithShiftSingle(unsigned char* dst, unsigned char* src, size_t w, size_t h, size_t shift)
{
    auto dst_sum = dst;
    GLASSERT(NULL!=dst_sum);
    auto dst_stride = w;
    auto src_stride = w;
    GLAUTOSTORAGE(bufferSum, size_t, w);
    ::memset(bufferSum, 0, sizeof(size_t)*w);
    for (size_t i=0; i<mH; ++i)
    {
        auto sum = bufferSum;
        auto pixels = src + src_stride*i;
        for (size_t j=0; j<w; ++j)
        {
            auto p = pixels[j];
            sum[j] += p;
        }
    }
    for (size_t i=0; i<h-mH; ++i)
    {
        auto window1 = dst_sum + dst_stride*(i+(mH/2)) + (mW/2);
        size_t Xsum = 0;
        for (size_t j=0; j<mW; ++j)
        {
            Xsum += bufferSum[j];
        }
        *window1 = Xsum >> shift;
        
        for(size_t x=1; x<w-mW; ++x)
        {
            Xsum = Xsum-bufferSum[(x-1)]+bufferSum[(mW-1+x)];
            *(window1+x) = Xsum >> shift;
        }
        auto img = src + src_stride*i;
        auto img_det = img + src_stride*mH;
        for(size_t x=0; x<w; x++)
        {
            unsigned char pixel = img[x];
            unsigned char pixel2 = img_det[x];
            bufferSum[x] = bufferSum[x] - pixel + pixel2;
        }
    }
}
void GLBoxFilter::computeMean(unsigned char* dst, unsigned char* src, size_t w, size_t h)
{
    auto dst_sum = dst;
    GLASSERT(NULL!=dst_sum);
    auto dst_stride = w;
    auto src_stride = w;
    GLAUTOSTORAGE(bufferSum, size_t, w);
    ::memset(bufferSum, 0, sizeof(size_t)*w);
    size_t divide = mW*mH;
    for (size_t i=0; i<mH; ++i)
    {
        auto sum = bufferSum;
        auto pixels = src + src_stride*i;
        for (size_t j=0; j<w; ++j)
        {
            auto p = pixels[j];
            sum[j] += p;
        }
    }
    for (size_t i=0; i<h-mH; ++i)
    {
        auto window1 = dst_sum + dst_stride*(i+(mH/2)) + (mW/2);
        size_t Xsum = 0;
        for (size_t j=0; j<mW; ++j)
        {
            Xsum += bufferSum[j];
        }
        *window1 = Xsum / divide;
        
        for(size_t x=1; x<w-mW; ++x)
        {
            Xsum = Xsum-bufferSum[(x-1)]+bufferSum[(mW-1+x)];
            *(window1+x) = Xsum / divide;
        }
        auto img = src + src_stride*i;
        auto img_det = img + src_stride*mH;
        for(size_t x=0; x<w; x++)
        {
            unsigned char pixel = img[x];
            unsigned char pixel2 = img_det[x];
            bufferSum[x] = bufferSum[x] - pixel + pixel2;
        }
    }
}
