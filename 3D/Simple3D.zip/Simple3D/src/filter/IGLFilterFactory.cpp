#include "IGLFilterFactory.h"
IGLFilterFactory* IGLFilterFactory::gFactory = NULL;

IGLFilterFactory& IGLFilterFactory::get()
{
    if (NULL == gFactory)
    {
        gFactory = new IGLFilterFactory;
    }
    return *gFactory;
}

void IGLFilterFactory::printMethods(std::ostream& os)
{
    CREATERS& c = gFactory->mCreator;
    CREATERS::iterator it = c.begin();
    for (;it!=c.end(); it++)
    {
        os << it->first<<std::endl;
        it->second->vDetail(os);
        os << std::endl;
    }
}

IGLFilter* IGLFilterFactory::create(const char* name, int w, int h)
{
    IGLFilterFactory& f = IGLFilterFactory::get();
    return f._create(name, w, h);
}

IGLFilter* IGLFilterFactory::_create(const char* name, int w, int h)
{
    if (NULL==name) return NULL;
    CREATERS::iterator i = mCreator.find(std::string(name));
    if (i!=mCreator.end())
    {
        return (i->second)->vCreate(w, h);
    }
    return NULL;
}

void IGLFilterFactory::insert(IGLFilterCreater* c, const std::string& s)
{
    mCreator.insert(make_pair(s, c));
}

IGLFilterFactory::IGLFilterFactory()
{
}

IGLFilterFactory::~IGLFilterFactory()
{
    for (CREATERS::iterator i=mCreator.begin(); i!=mCreator.end(); i++)
    {
        delete i->second;
        i->second = NULL;
    }
}
std::vector<std::string> IGLFilterFactory::listMethods()
{
    std::vector<std::string> res;
    CREATERS& c = gFactory->mCreator;
    CREATERS::iterator it = c.begin();
    for (;it!=c.end(); it++)
    {
        res.push_back(it->first);
    }
    return res;
}
