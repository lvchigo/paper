#include "filter/GLHistogramEqualFilter.h"
#include "GLAutoStorage.h"
#include <string.h>
GLHistogramEqualFilter::GLHistogramEqualFilter()
{
    
}
GLHistogramEqualFilter::~GLHistogramEqualFilter()
{
    
}

size_t GLHistogramEqualFilter::vMap(double* parameters, size_t n)
{
    return 0;
}

void GLHistogramEqualFilter::vFilter(GLBmp* dst, const GLBmp* src) const
{
    GLASSERT(NULL!=src);
    GLASSERT(NULL!=dst);
    GLASSERT(src->width() == dst->width());
    GLASSERT(src->height() == dst->height());
    auto w = src->width();
    auto h = src->height();
    const int NUMBER=256;
    const int COMP = 3;
    int comp_max[COMP];
    int comp_min[COMP];
    GLAUTOSTORAGE(coloc_map, int, COMP*NUMBER);
    ::memset(coloc_map, 0, COMP*NUMBER*sizeof(int));
    /*Calculate numbers of all color*/
    for (int i=0; i<h; ++i)
    {
        for (int j=0; j<w; ++j)
        {
            auto src_sta = src->getAddr(j, i);
            for (int k=0; k<COMP; ++k)
            {
                ++coloc_map[src_sta[k]+NUMBER*k];
            }
        }
    }
    /*Find max and min value, accumulation*/
    for (int k=0; k<COMP; ++k)
    {
        comp_max[k] = 0;
        comp_min[k] = 0;
        auto comp_map = coloc_map + k*NUMBER;
        for (int i=0; i<NUMBER; ++i)
        {
            if (0!=comp_map[i])
            {
                comp_min[k] = i;
                break;
            }
        }
        for (int i=NUMBER-1; i>=0; --i)
        {
            if (0!=comp_map[i])
            {
                comp_max[k] = i;
                break;
            }
        }
        for (int i=1; i<NUMBER; ++i)
        {
            comp_map[i] = comp_map[i] + comp_map[i-1];
        }
    }
    GLAUTOSTORAGE(historgam, float, COMP*NUMBER);
    for (int i=0; i<COMP*NUMBER; ++i)
    {
        //FUNC_PRINT(coloc_map[i]);
        historgam[i] = coloc_map[i]/(float)w/(float)h;
    }
    /*Transform*/
    for (int i=0; i<h; ++i)
    {
        for (int j=0; j<w; ++j)
        {
            auto src_sta = src->getAddr(j, i);
            auto dst_sta = dst->getAddr(j, i);
            for (int k=0; k<COMP; ++k)
            {
                auto _historgam = historgam + k*NUMBER;
                unsigned char src_color = src_sta[k];
                dst_sta[k] = _historgam[src_color]*(comp_max[k]-comp_min[k]) + comp_min[k];
            }
        }
    }
}
