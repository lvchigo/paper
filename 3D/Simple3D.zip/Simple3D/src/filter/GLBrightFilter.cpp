#include "GLBrightFilter.h"
#include <math.h>
#include "utils/GP_Clock.h"
#include <vector>
#include <thread>
//float beta = 3.1;
//vec3 after_filter;
//after_filter = clamp(color, vec3(0.0), vec3(1.0));
//after_filter = vec3(after_filter.r*(1.0 + beta*0.01), after_filter.g*1., after_filter.b*1.);
//after_filter = log(after_filter*(beta-1.)+1.)/log(beta);

//"mediump vec3 BrightnessContrastSaturation(mediump vec3 color, mediump float brt, mediump float con, mediump float sat){\n"
//+ "    mediump vec3 black = vec3(0., 0., 0.);\n"
//+ "    mediump vec3 middle = vec3(0.5, 0.5, 0.5);\n"
//+ "    mediump vec3 W = vec3(0.2125, 0.7154, 0.0721);\n"
//+ "    mediump float luminance = dot(color, W);\n"
//+ "    mediump vec3 gray = vec3(luminance, luminance, luminance);\n"
//+ "    mediump vec3 brtColor = mix(black, color, brt);\n"
//+ "    mediump vec3 conColor = mix(middle, brtColor, con);\n"
//+ "    mediump vec3 satColor = mix(gray, conColor, sat);\n"
//+ "    return satColor;\n"
//+ "}\n"


template<typename T>
static T limit(T v)
{
    if (v>255) return 255;
    return v;
}
#if 1
static inline float log_self(float x)
{
    float y = 1.0 - 2.0/(1.0+x);
    return 2.0*y;
}
#else
static inline float log_self(float x)
{
    return log(x);
}
#endif
#ifdef HAS_NEON
#include <arm_neon.h>
#endif

static void _run(unsigned char* dst, unsigned char* src, int l, int t, int w, int h, int bpp)
{
    //float beta = 3.1;
    //float logbeta = log(beta);
    
    for (int i=t; i<t+h; ++i)
    {
        auto dst_sta = dst + (i*w+l)*bpp;
        auto src_sta = src + (i*w+l)*bpp;
        int sta = 0;
#ifdef HAS_NEON
        int uw = w/8;
        auto _src = src_sta;
        auto _dst = dst_sta;
        asm(
            "ldr r4, =#0x3C0B1C1C\t\n"//0.008490588235294116
            "vdup.32 q5, r4\t\n"
            "ldr r4, =#0x3C06ED54\t\n"//0.00823529411764706
            "vdup.32 q6, r4\t\n"
            "ldr r4, =#0x43E16252\t\n"//225.38405877988833*2.0
            "vdup.32 q7, r4\t\n"
            "ldr r4, =#0x3F800000\t\n"//1
            "vdup.32 q8, r4\t\n"
            "ldr r4, =#0x40000000\t\n"//2
            "vdup.32 q9, r4\t\n"
            "ldr r4, =#0x437F0000\t\n"//255
            "vdup.32 q10, r4\t\n"
            
            "movs r4, %[uw]\t\n"
            "beq 2f\t\n"
            "1:\t\n"
            "vld4.8 {d0-d3}, [%[_src]]!\t\n"
            /*R begin*/
            "vmovl.u8 q2, d0\t\n"//q2:d4,d5
            "vmovl.s16 q3, d4\t\n"
            "vmovl.s16 q4, d5\t\n"
            "vcvt.f32.s32 q3, q3\t\n"
            "vcvt.f32.s32 q4, q4\t\n"
            
            "vmul.f32 q3, q3, q5\t\n"
            "vmul.f32 q4, q4, q5\t\n"
            //Log: 1.0 - 2.0/(1.0+x);
            "vadd.f32 q3, q3, q9\t\n"
            "vadd.f32 q4, q4, q9\t\n"
            "vrecpe.f32 q3, q3\t\n"
            "vrecpe.f32 q4, q4\t\n"
            "vmul.f32 q3, q3, q9\t\n"
            "vmul.f32 q4, q4, q9\t\n"
            "vsub.f32 q3, q8, q3\t\n"
            "vsub.f32 q4, q8, q4\t\n"
            //
            "vmul.f32 q3, q3, q7\t\n"
            "vmul.f32 q4, q4, q7\t\n"
            "vmin.f32 q3, q3, q10\t\n"
            "vmin.f32 q4, q4, q10\t\n"
            
            
            "vcvt.s32.f32 q3, q3\t\n"
            "vcvt.s32.f32 q4, q4\t\n"
            "vmovn.s32 d4, q3\t\n"
            "vmovn.s32 d5, q4\t\n"
            "vmovn.s16 d0, q2\t\n"
            /*R end*/
            
            /*G begin*/
            "vmovl.u8 q2, d1\t\n"//q2:d4,d5
            "vmovl.s16 q3, d4\t\n"
            "vmovl.s16 q4, d5\t\n"
            "vcvt.f32.s32 q3, q3\t\n"
            "vcvt.f32.s32 q4, q4\t\n"
            
            "vmul.f32 q3, q3, q6\t\n"
            "vmul.f32 q4, q4, q6\t\n"
            //Log: 1.0 - 2.0/(1.0+x);
            "vadd.f32 q3, q3, q9\t\n"
            "vadd.f32 q4, q4, q9\t\n"
            "vrecpe.f32 q3, q3\t\n"
            "vrecpe.f32 q4, q4\t\n"
            "vmul.f32 q3, q3, q9\t\n"
            "vmul.f32 q4, q4, q9\t\n"
            "vsub.f32 q3, q8, q3\t\n"
            "vsub.f32 q4, q8, q4\t\n"
            //
            "vmul.f32 q3, q3, q7\t\n"
            "vmul.f32 q4, q4, q7\t\n"
            "vmin.f32 q3, q3, q10\t\n"
            "vmin.f32 q4, q4, q10\t\n"
            
            
            "vcvt.s32.f32 q3, q3\t\n"
            "vcvt.s32.f32 q4, q4\t\n"
            "vmovn.s32 d4, q3\t\n"
            "vmovn.s32 d5, q4\t\n"
            "vmovn.s16 d1, q2\t\n"
            /*G end*/

            /*B begin*/
            "vmovl.u8 q2, d2\t\n"//q2:d4,d5
            "vmovl.s16 q3, d4\t\n"
            "vmovl.s16 q4, d5\t\n"
            "vcvt.f32.s32 q3, q3\t\n"
            "vcvt.f32.s32 q4, q4\t\n"
            
            "vmul.f32 q3, q3, q6\t\n"
            "vmul.f32 q4, q4, q6\t\n"
            //Log: 1.0 - 2.0/(1.0+x);
            "vadd.f32 q3, q3, q9\t\n"
            "vadd.f32 q4, q4, q9\t\n"
            "vrecpe.f32 q3, q3\t\n"
            "vrecpe.f32 q4, q4\t\n"
            "vmul.f32 q3, q3, q9\t\n"
            "vmul.f32 q4, q4, q9\t\n"
            "vsub.f32 q3, q8, q3\t\n"
            "vsub.f32 q4, q8, q4\t\n"
            //
            "vmul.f32 q3, q3, q7\t\n"
            "vmul.f32 q4, q4, q7\t\n"
            "vmin.f32 q3, q3, q10\t\n"
            "vmin.f32 q4, q4, q10\t\n"
            
            
            "vcvt.s32.f32 q3, q3\t\n"
            "vcvt.s32.f32 q4, q4\t\n"
            "vmovn.s32 d4, q3\t\n"
            "vmovn.s32 d5, q4\t\n"
            "vmovn.s16 d2, q2\t\n"
            /*B end*/
            
            "vst4.8 {d0-d3}, [%[_dst]]!\t\n"
            "subs r4, r4, #1\t\n"
            "bne 1b\t\n"
            "2:\t\n"
            : [_src] "+r" (_src), [_dst] "+r" (_dst), [uw] "+r" (uw)
            :
            : "r4", "cc","memory", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "d10", "d11", "d12", "d13", "d14", "d15", "d16", "d17", "d18", "d19", "d20", "d21"
            );
        sta = uw*8;
#endif
        for (int j=sta; j<w; ++j)
        {
            auto dest = dst_sta + j*bpp;
            auto source = src_sta + j*bpp;
            //dest[0] = limit(255.0*log_self(source[0]/255.0*(1.0+beta*0.01)*2.1+1)/logbeta);
            //dest[1] = limit(255.0*log_self(source[1]/255.0*(1.0)*2.1+1)/logbeta);
            //dest[2] = limit(255.0*log_self(source[2]/255.0*(1.0)*2.1+1)/logbeta);
            dest[0] = limit(225.38405877988833*log_self(source[0]*0.008490588235294116+1));
            dest[1] = limit(225.38405877988833*log_self(source[1]*0.00823529411764706+1));
            dest[2] = limit(225.38405877988833*log_self(source[2]*0.00823529411764706+1));
            dest[3] = source[3];
        }
    }
}

void GLBrightFilter::vFilter(GLBmp* dst, const GLBmp* src) const
{
    //GPCLOCK;
    GLASSERT(NULL!=dst);
    GLASSERT(NULL!=src);
    GLASSERT(dst->width()==src->width());
    GLASSERT(dst->height()==src->height());
    auto w = dst->width();
    auto h = dst->height();
    auto bpp = dst->bpp();
    auto _dst = (unsigned char*)(dst->pixels());
    auto _src = (unsigned char*)(src->pixels());
    if (h < 500)
    {
        _run(_dst, _src, 0,0,w,h,bpp);
        return;
    }
    int hunit = h /4;
    int hoffset[] = {0, hunit, 2*hunit,3*hunit, h};
    std::vector<std::thread*> queues;
    for (int i=0; i<4; ++i)
    {
        int t = hunit*i;
        int _h = hoffset[i+1]-hoffset[i];
        auto f = ([=]{
            _run(_dst, _src,0,t,w,_h,bpp);
        });
        queues.push_back(new std::thread(f));
    }
    for (auto t : queues)
    {
        t->join();
        delete t;
    }
    queues.clear();
}
size_t GLBrightFilter::vMap(double* parameters, size_t n)
{
    return 0;
}
