#include "GLGuideFilter.h"
#include "GLAutoStorage.h"
#include "GLBoxFilter.h"
#include "GP_Clock.h"

//#define USE_MEAN
#define USE_FLOAT 1
#ifdef HAS_NEON
#undef HAS_NEON
#endif

#ifdef HAS_NEON
#include <arm_neon.h>
#endif


GLGuideFilter::GLGuideFilter(int unit, float thetha, const GLBmp* guideImage)
{
    mUnit = unit;
    mThetha = thetha;
    mGuideBmp = guideImage;
    mUnitPercent = 1.0;
}
GLGuideFilter::~GLGuideFilter()
{
    
}
size_t GLGuideFilter::vMap(double* parameters, size_t n)
{
    if (NULL == parameters)
    {
        return 1;
    }
    mUnitPercent = parameters[0];
    return 1;
}

#if !USE_FLOAT
static size_t Turn2Power(size_t p)
{
    size_t res = 0;
    while (p > 0 && res < 8)
    {
        res++;
        p/=2;
    }
    return res;
}
#endif

static void _regress(unsigned char* pix, int w, int h, size_t unit, size_t* mean, size_t* var, float thetha)
{
    auto ew = w+unit;
    for (int i=0; i<h; ++i)
    {
        int sta = 0;
#ifdef HAS_NEON
        auto mean_sta = mean + i*ew+unit/2;
        auto var_sta = var + i*ew+unit/2;
        auto pix_sta = pix + i*ew+unit/2;
        float count_rep = 1.0/((float)unit*(float)unit*255.0);
        int uw = w/8;
        asm volatile(
            "ldr r4, =#0x437F0000\t\n"//255
            "vdup.32 q9, r4\t\n"
            "mov r4, %[count_rep]\t\n"
            "vdup.32 q10, r4\t\n"
            
            "mov r4, %[thetha]\t\n"
            "vdup.32 q11, r4\t\n"

            "ldr r4, =#0x3F800000\t\n"//1
            "vdup.32 q12, r4\t\n"
            
            "movs r4, %[uw]\t\n"
            "beq 2f\t\n"
            "1:\t\n"
            "vld4.32 {d0-d3}, [%[mean_sta]]!\t\n"//q0, q1
            "vld4.32 {d4-d7}, [%[var_sta]]!\t\n"//q2, q3
            "vld1.8 d8, [%[pix_sta]]\t\n"
            //Use q7,q8 to mid save pixels, use q4 to save result
            "vmovl.u8 q5, d8\t\n"
            "vmovl.s16 q7, d10\t\n"
            "vmovl.s16 q8, d11\t\n"
            
            "vcvt.f32.s32 q0, q0\t\n"
            "vcvt.f32.s32 q1, q1\t\n"
            "vcvt.f32.s32 q2, q2\t\n"
            "vcvt.f32.s32 q3, q3\t\n"
            "vcvt.f32.s32 q7, q7\t\n"
            "vcvt.f32.s32 q8, q8\t\n"
            
            "vmul.f32 q0, q0, q10\t\n"
            "vmul.f32 q1, q1, q10\t\n"
            "vmul.f32 q2, q2, q10\t\n"
            "vmul.f32 q3, q3, q10\t\n"
            
            "vmls.f32 q2, q0, q0\t\n"//__var = __var - __mean*__mean
            "vmls.f32 q3, q1, q1\t\n"//__var = __var - __mean*__mean
            "vadd.f32 q5, q11, q2\t\n"//thetha + __var
            "vadd.f32 q6, q11, q3\t\n"//thetha + __var
            "vrecpe.f32 q5, q5\t\n"
            "vrecpe.f32 q6, q6\t\n"
            "vmul.f32 q5, q5, q2\t\n"//a
            "vmul.f32 q6, q6, q3\t\n"//a
            /*Now __var is not used, resued the q2 q3*/
            "vsub.f32 q2, q12, q5\t\n"
            "vsub.f32 q3, q12, q6\t\n"
            "vmul.f32 q2, q2, q0\t\n"//b
            "vmul.f32 q3, q3, q1\t\n"//b
            
            /*(a*p+b*255)*/
            "vmul.f32 q7, q7, q5\t\n"
            "vmul.f32 q8, q8, q6\t\n"
            "vmla.f32 q7, q2, q9\t\n"
            "vmla.f32 q8, q3, q9\t\n"

            /*Store back*/
            "vcvt.s32.f32 q7, q7\t\n"
            "vcvt.s32.f32 q8, q8\t\n"
            "vmovn.s32 d10, q7\t\n"
            "vmovn.s32 d11, q8\t\n"
            "vmovn.s16 d8, q5\t\n"
            
            "vst1.8 {d8}, [%[pix_sta]]!\t\n"
            "subs r4, r4, #1\t\n"
            "bne 1b\t\n"
            "2:\t\n"
            : [mean_sta] "+r" (mean_sta), [var_sta] "+r" (var_sta), [pix_sta] "+r" (pix_sta), [uw] "+r" (uw), [count_rep] "+r" (count_rep), [thetha] "+r" (thetha)
            :
            : "r4", "cc","memory", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "d10", "d11", "d12", "d13", "d14", "d15", "d16", "d17", "d18", "d19", "d20", "d21", "d22", "d23", "d24", "d25"
        );
        sta = 8*uw;
#endif
        for (int j=sta; j<w; ++j)
        {
            float __mean = mean[i*ew+j+unit/2]/(float)(unit*unit*255);
            float __var = var[i*ew+j+unit/2]/(float)(unit*unit*255*255);
            __var = __var - __mean*__mean;
            float a = __var/(thetha + __var);
            float b = (1.0 - a)*__mean;
            pix[i*ew+j+unit/2] = (pix[i*ew+j+unit/2]*a + b*255.0);
        }
    }
}
void GLGuideFilter::vFilter(GLBmp* dst, const GLBmp* src) const
{
    //GPCLOCK;
    GLASSERT(NULL!=src);
    GLASSERT(NULL!=dst);
    auto w = src->width();
    auto h = src->height();
#if !USE_FLOAT
    size_t power2unit = Turn2Power(mUnitPercent*mUnit);
    size_t unit = 1 << power2unit;
    size_t thetha = mThetha*(float)(255*255);
#else
    size_t unit = mUnitPercent*mUnit;
#endif
    if (0>=unit)
    {
        unit = 1;
    }
    auto ew = w+unit;
    auto eh = h+unit;
    GLASSERT(w == dst->width());
    GLASSERT(h == dst->height());
    /*TODO*/
    GLASSERT(NULL == mGuideBmp);
    auto size = ew*eh;
    GLAUTOSTORAGE(mean, size_t, size);
    GLAUTOSTORAGE(var, size_t, size);
    GPPtr<GLBoxFilter> filter = new GLBoxFilter(unit, unit);
    unsigned char* pix[3];
    GLAUTOSTORAGE(pix_origin, unsigned char, size*3);
    pix[0] = pix_origin;
    pix[1] = pix_origin + size;
    pix[2] = pix_origin + 2*size;
    GLBmp::loadComponent(pix, src, ew, ew*(unit/2)+unit/2);
    /*Run For RGB*/
    for (int k=0; k<3; ++k)
    {
        unsigned char* _pix = pix[k];
#if USE_FLOAT
        filter->compute(var, mean, _pix, ew, eh);
        _regress(_pix, w, h, unit, mean, var, mThetha);
#else
        filter->computeWithShift(var, mean, _pix, ew, eh, 2*power2unit);
        for (int i=0; i<h; ++i)
        {
            for (int j=0; j<w; ++j)
            {
                auto __mean = mean[i*ew+j+unit/2];
                auto __var = var[i*ew+j+unit/2];
                __var = __var - __mean*__mean;
                size_t a = (__var << 8)/(thetha+__var);
                size_t b = (256 - a)*__mean;
                _pix[i*ew+j+unit/2] = ((_pix[i*ew+j+unit/2]*a + b))>>8;
            }
        }
#endif
    }
    GLBmp::writeComponent(pix, dst, ew, ew*(unit/2)+unit/2);
}

