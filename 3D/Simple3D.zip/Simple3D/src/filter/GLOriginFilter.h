//
//  GLOriginFilter.h
//  simple3d
//
//  Created by jiangxiaotang on 15/7/29.
//  Copyright (c) 2015年 jiangxiaotang. All rights reserved.
//

#ifndef __simple3d__GLOriginFilter__
#define __simple3d__GLOriginFilter__

#include <stdio.h>
#include "IGLFilter.h"
class GLOriginFilter:public IGLFilter
{
public:
    GLOriginFilter() = default;
    virtual ~GLOriginFilter() = default;
    virtual void vFilter(GLBmp* dst, const GLBmp* src) const;
    virtual size_t vMap(double* parameters, size_t n) {return 1;}
};
#endif /* defined(__simple3d__GLOriginFilter__) */
