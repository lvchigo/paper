#include "GLSharpFilter.h"
#include "GP_Clock.h"
#include <string.h>
GLSharpFilter::GLSharpFilter()
{
}
GLSharpFilter::~GLSharpFilter()
{
}

static int limit(int a)
{
    if (a > 255) return 255;
    if (a < 0) return 0;
    return a;
}
void GLSharpFilter::vFilter(GLBmp* dst, const GLBmp* src) const
{
    GLASSERT(NULL!=dst);
    GLASSERT(NULL!=src);
    GLASSERT(src!=dst);
    GLASSERT(dst->width()==src->width());
    GLASSERT(dst->height()==src->height());
    GLASSERT(src->bpp()==dst->bpp());
    int w = src->width();
    int h = src->height();
    auto bpp = dst->bpp();
    unsigned char* source = (unsigned char*)(src->pixels());
    unsigned char* dest = (unsigned char*)(dst->pixels());
    int mask[] = {
        -1,0,-1,
        0,8,0,
        -1,0,-1,
    };
    for (int i=1;i<h-1;++i)
    {
        for (int j=1; j<w-1; ++j)
        {
            auto src_ = source + (i*w+j)*bpp;
            auto dst_ = dest + (i*w+j)*bpp;
            int sumr = 0;
            int sumg = 0;
            int sumb = 0;
            for (int m=-1;m<=1;++m)
            {
                for (int n=-1;n<=1;++n)
                {
                    auto __src = src_ + ((m)*w+n)*bpp;
                    int mask_ = mask[(m+1)*3+n+1];
                    sumr += __src[0]*mask_;
                    sumg += __src[1]*mask_;
                    sumb += __src[2]*mask_;
                }
            }
            dst_[0] = limit(sumr/4);
            dst_[1] = limit(sumg/4);
            dst_[2] = limit(sumb/4);
            dst_[3] = src_[3];
        }
    }
}
size_t GLSharpFilter::vMap(double* parameters, size_t n)
{
    return 0;
}
