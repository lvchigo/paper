#include "core/GLBmp.h"
#include "utils/GLDebug.h"
#include <math.h>
#include <string.h>
static const int BPP = 4;

GLBmp::GLBmp(int w, int h)
{
    GLASSERT(0<h&&0<w);
    mWidth = w;
    mHeight = h;
    mPixels = new unsigned char[h*w*BPP];
    mOwnPixels = true;
    mStride = w*BPP;
}
GLBmp::GLBmp(int w, int h, void* pixels, int stride)
{
    GLASSERT(0<h&&0<w);
    GLASSERT(0==stride || stride >= BPP*w);
    GLASSERT(NULL!=pixels);
    mWidth = w;
    mHeight = h;
    mPixels = (unsigned char*)pixels;
    mOwnPixels = false;
    if (stride == 0)
    {
        mStride = w*BPP;
    }
    else
    {
        mStride = stride;
    }
}

GLBmp::~GLBmp()
{
    if (mOwnPixels)
    {
        delete [] mPixels;
    }
}
unsigned char* GLBmp::getAddr(int x, int y) const
{
    return (unsigned char*)pixels() + y*mStride+x*BPP;
}

double GLBmp::psnr(const GLBmp& other) const
{
    //GPCLOCK;
    double result = 0.0;
    int w = other.width();
    int h = other.height();
    if (width()!=w || height()!=h)
    {
        return 0.0;
    }
    for (int i=0; i<h; ++i)
    {
        unsigned char* src = getAddr(0, i);
        unsigned char* dst = other.getAddr(0, i);
        for (int j=0; j<w; ++j)
        {
            for (int k=0; k<3; ++k)
            {
                double s = src[k];
                double d = dst[k];
                result+= (s-d)*(s-d);
            }
            src+=4;
            dst+=4;
        }
    }
    unsigned char _max = 0xFF;
    result = result/(double)(w*h*3);
    result = -10.0*log(result/(double)_max/(double)_max)/log(10.0);
    return result;
}


void GLBmp::loadComponent(unsigned char* pix[], const GLBmp* src, size_t pix_stride, size_t offset)
{
    GLASSERT(NULL!=src);
    GLASSERT(NULL!=pix);
    auto w = src->width();
    auto h = src->height();
    for (int i=0; i<h; ++i)
    {
        int sta = 0;
        auto source = src->getAddr(0, i);
#ifdef HAS_NEON
        unsigned char* r = pix[0]+i*pix_stride+offset;
        unsigned char* g = pix[1]+i*pix_stride+offset;
        unsigned char* b = pix[2]+i*pix_stride+offset;
        int uw = w/8;
        unsigned char* _src = source;
        asm(
            "movs r4, %[uw]\t\n"
            "beq 2f\t\n"
            "1:\t\n"
            "pld [%[_src], #256]\t\n"
            "vld4.8 {d0-d3}, [%[_src]]!\t\n"
            "vst1.8 d0, [%[r]]!\t\n"
            "vst1.8 d1, [%[g]]!\t\n"
            "vst1.8 d2, [%[b]]!\t\n"
            
            "subs r4, r4, #1\t\n"
            "bne 1b\t\n"
            "2:\t\n"
            : [r] "+r" (r), [g] "+r" (g), [b] "+r" (b), [uw] "+r" (uw), [_src] "+r" (_src)
            :
            : "r4", "cc","memory", "d0", "d1", "d2", "d3"
            );
        sta = uw*8;
#endif
        for (int j=sta; j<w; ++j)
        {
            for (int k=0; k<3; ++k)
            {
                pix[k][i*pix_stride+j+offset] = source[j*4+k];
            }
        }
    }
}

void GLBmp::writeComponent(unsigned char* pix[], GLBmp* dst, size_t pix_stride, size_t offset)
{
    GLASSERT(NULL!=dst);
    GLASSERT(NULL!=pix);
    int w = dst->width();
    int h = dst->height();
    for (int i=0; i<h; ++i)
    {
        auto dest = dst->getAddr(0, i);
        int sta = 0;
#ifdef HAS_NEON
        unsigned char* r = pix[0]+i*pix_stride+offset;
        unsigned char* g = pix[1]+i*pix_stride+offset;
        unsigned char* b = pix[2]+i*pix_stride+offset;
        unsigned char* _dst = dest;
        int uw = w/8;
        asm volatile(
                     "mov r4, #255\t\n"
                     "vdup.8 d3, r4\t\n"
                     "movs r4, %[uw]\t\n"
                     "beq 2f\t\n"
                     "1:\t\n"
                     "vld1.8 d0, [%[r]]!\t\n"
                     "vld1.8 d1, [%[g]]!\t\n"
                     "vld1.8 d2, [%[b]]!\t\n"
                     "vst4.8 {d0-d3}, [%[_dst]]!\t\n"
                     
                     "subs r4, r4, #1\t\n"
                     "bne 1b\t\n"
                     "2:\t\n"
                     : [r] "+r" (r), [g] "+r" (g), [b] "+r" (b), [uw] "+r" (uw), [_dst] "+r" (_dst)
                     :
                     : "r4", "cc","memory", "d0", "d1", "d2", "d3"
                     );
        sta = uw*8;
#endif
        for (int j=sta; j<w; ++j)
        {
            for (int k=0; k<3; ++k)
            {
                dest[j*4+k] = pix[k][i*pix_stride+j+offset];
            }
            dest[j*4+3] = 0xFF;
        }
    }
}

void GLBmp::clear()
{
    for (int y=0; y<mHeight; ++y)
    {
        ::memset(getAddr(0,y), 0, 4*sizeof(unsigned char)*mWidth);
    }
}

