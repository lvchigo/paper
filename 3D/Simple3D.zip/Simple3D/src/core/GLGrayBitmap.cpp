#include "core/GLGrayBitmap.h"
#include "utils/GLDebug.h"
#include <string.h>
GLGrayBitmap::GLGrayBitmap(int w, int h, int stride, unsigned char* outputPixels)
{
    GLASSERT(0<w);
    GLASSERT(0<h);
    GLASSERT(0==stride || stride >= w);
    mW = w;
    mH = h;
    if (0 == stride)
    {
        stride = w;
    }
    mStride = stride;
    if (NULL ==outputPixels)
    {
        mPixels = new unsigned char[w*h];
        mOwnPixels = true;
    }
    else
    {
        mPixels = outputPixels;
        mOwnPixels = false;
    }
}


GLGrayBitmap::~GLGrayBitmap()
{
    if (mOwnPixels)
    {
        delete [] mPixels;
    }
}
void GLGrayBitmap::clear(unsigned char color)
{
    for (int i=0; i<mH; ++i)
    {
        ::memset(mPixels+i*mStride, color, mW*sizeof(unsigned char));
    }
}

/*0.3*r + 0.59*g + 0.11*b*/
/*(38*r + 76*g + 14*b)/128*/
void GLGrayBitmap::turnGray(GLGrayBitmap* dst, const GLBmp* src)
{
    GLASSERT(NULL!=dst);
    GLASSERT(NULL!=src);
    GLASSERT(src->width() == dst->width());
    GLASSERT(src->height() == dst->height());
    int w = src->width();
    int h = src->height();
    for (int i=0; i<h; ++i)
    {
        int sta = 0;
        auto gray_l = dst->getAddr(0, i);
        auto rgb_l = src->getAddr(0, i);
        for (int j=sta; j<w; ++j)
        {
            unsigned char r = rgb_l[j*4];
            unsigned char g = rgb_l[j*4+1];
            unsigned char b = rgb_l[j*4+2];
            gray_l[j] = (r*38 + g*76 + b*14) >> 7;
        }
    }
}
void GLGrayBitmap::turnRGB(const GLGrayBitmap* src, GLBmp* dst)
{
    GLASSERT(NULL!=dst);
    GLASSERT(NULL!=src);
    GLASSERT(src->width() == dst->width());
    GLASSERT(src->height() == dst->height());
    int w = src->width();
    int h = src->height();
    for (int i=0; i<h; ++i)
    {
        int sta = 0;
        auto gray_l = src->getAddr(0, i);
        auto rgb_l = dst->getAddr(0, i);
        for (int j=sta; j<w; ++j)
        {
            auto ggray = gray_l[j];
            rgb_l[j*4] = ggray;
            rgb_l[j*4+1] = ggray;
            rgb_l[j*4+2] = ggray;
            rgb_l[j*4+3] = 255;
        }
    }
}

void GLGrayBitmap::mapRGB(const GLGrayBitmap* src, GLBmp* dst, unsigned char* rTab, unsigned char* gTab, unsigned char* bTab)
{
    GLASSERT(NULL!=dst);
    GLASSERT(NULL!=src);
    GLASSERT(src->width() == dst->width());
    GLASSERT(src->height() == dst->height());
    GLASSERT(NULL!=rTab);
    GLASSERT(NULL!=gTab);
    GLASSERT(NULL!=bTab);
    int w = src->width();
    int h = src->height();
    for (int i=0; i<h; ++i)
    {
        int sta = 0;
        auto gray_l = src->getAddr(0, i);
        auto rgb_l = dst->getAddr(0, i);
        for (int j=sta; j<w; ++j)
        {
            auto ggray = gray_l[j];
            rgb_l[j*4] = rTab[ggray];
            rgb_l[j*4+1] = gTab[ggray];
            rgb_l[j*4+2] = bTab[ggray];
            rgb_l[j*4+3] = 255;
        }
    }
}


void GLGrayBitmap::reverse(GLGrayBitmap* src, GLGrayBitmap* dst, int thredhold)
{
    GLASSERT(NULL!=dst);
    GLASSERT(NULL!=src);
    GLASSERT(src->width() == dst->width());
    GLASSERT(src->height() == dst->height());
    auto w = src->width();
    for (int y=0; y<src->height(); ++y)
    {
        auto dst_line = dst->getAddr(0, y);
        auto src_line = src->getAddr(0, y);
        for (int x=0; x<w; ++x)
        {
            if (src_line[x]>thredhold)
            {
                dst_line[x] = 0;
            }
            else
            {
                dst_line[x] = 0xFF;
            }
        }
    }

}

