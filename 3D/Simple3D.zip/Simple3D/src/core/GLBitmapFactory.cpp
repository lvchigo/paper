#ifndef DISABLE_MOVIE

#include "core/GLBitmapFactory.h"
extern "C"{
#include "png.h"
}
#include <string.h>

#include "utils/GLDebug.h"
#include "utils/GLAutoStorage.h"
#include "utils/GLStream.h"

static void sk_read_fn(png_structp png_ptr, png_bytep data, png_size_t length) {
    GLStream* sk_stream = (GLStream*) png_get_io_ptr(png_ptr);
    sk_stream->vRead(data, length);
}

struct PNGAutoClean {
    PNGAutoClean(png_structp p, png_infop i): png_ptr(p), info_ptr(i) {}
    ~PNGAutoClean() {
        png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
    }
private:
    png_structp png_ptr;
    png_infop info_ptr;
};

static GLBmp* _createFromStream(GPPtr<GLStream> inputs)
{
    png_structp png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING,
                                                 NULL, NULL, NULL);
    GLASSERT(NULL!=png_ptr);
    /* Allocate/initialize the memory for image information. */
    png_infop info_ptr = png_create_info_struct(png_ptr);
    GLASSERT(NULL!=info_ptr);
    png_set_read_fn(png_ptr, (void *)(inputs.get()), sk_read_fn);
    png_set_keep_unknown_chunks(png_ptr, PNG_HANDLE_CHUNK_ALWAYS, (png_byte*)"", 0);
    png_read_info(png_ptr, info_ptr);
    png_uint_32 width, height;
    int bitDepth, colorType;
    png_get_IHDR(png_ptr, info_ptr, &width, &height, &bitDepth,
                 &colorType, NULL, NULL, NULL);
    GLASSERT(bitDepth == 8);
    GLASSERT(colorType == PNG_COLOR_TYPE_RGBA || colorType == PNG_COLOR_TYPE_RGB);
    GLBmp* backGround = new GLBmp(width, height);
    PNGAutoClean autoClean(png_ptr, info_ptr);
    png_read_update_info(png_ptr, info_ptr);
    if (colorType == PNG_COLOR_TYPE_RGBA)
    {
        for (int y = 0; y < height; y++) {
            auto tmp = backGround->getAddr(0, y);
            png_read_rows(png_ptr, &tmp, NULL, 1);
        }
    }
    else if (colorType == PNG_COLOR_TYPE_RGB)
    {
        GLAUTOSTORAGE(temp, unsigned char, width*3);
        for (int y = 0; y < height; y++) {
            auto tmp = backGround->getAddr(0, y);
            png_read_rows(png_ptr, &temp, NULL, 1);
            for (int x=0; x<width; ++x)
            {
                tmp[x*4+3] = 0xFF;
                ::memcpy(tmp+x*4, temp+x*3, 3*sizeof(unsigned char));
            }
        }
        
    }
    else
    {
        GLASSERT(0);
    }
    png_read_end(png_ptr, info_ptr);
    return backGround;
}

static void gl_png_write_fn(png_structp png_ptr, png_bytep data, png_size_t len) {
    GLWStream* sk_stream = (GLWStream*)png_get_io_ptr(png_ptr);
    if (!sk_stream->vWrite(data, len)) {
        png_error(png_ptr, "sk_write_fn Error!");
    }
}

void GLBitmapFactory::dump(const GLBmp* background, const char* filename)
{
    GPPtr<GLWStream> output = GLStreamFactory::writeForFile(filename);
    GLASSERT(NULL!=output.get());
    GLASSERT(NULL!=background);
    png_structp png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL,
                                                  NULL);
    GLASSERT(NULL!=png_ptr);
    png_infop info_ptr = png_create_info_struct(png_ptr);
    GLASSERT(NULL!=info_ptr);
    const GLBmp* bitmap = background;
    auto h = bitmap->height();
    auto w = bitmap->width();
    int colorType = PNG_COLOR_MASK_COLOR | PNG_COLOR_MASK_ALPHA;
    int bitDepth = 8;   // default for color
    png_color_8 sig_bit;
    sig_bit.red = 8;
    sig_bit.green = 8;
    sig_bit.blue = 8;
    sig_bit.alpha = 8;
    png_set_write_fn(png_ptr, (void*)(output.get()), gl_png_write_fn, NULL);
    
    png_set_IHDR(png_ptr, info_ptr, w, h,
                 bitDepth, colorType,
                 PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_BASE,
                 PNG_FILTER_TYPE_BASE);
    
    png_set_sBIT(png_ptr, info_ptr, &sig_bit);
    png_write_info(png_ptr, info_ptr);
    for (int y = 0; y < h; y++) {
        const char* srcImage = (const char*)bitmap->getAddr(0, y);
        png_bytep row_ptr = (png_bytep)srcImage;
        png_write_rows(png_ptr, &row_ptr, 1);
    }

    png_write_end(png_ptr, info_ptr);
    png_destroy_write_struct(&png_ptr, &info_ptr);
}

GLBmp* GLBitmapFactory::create(const char* pic)
{
    GPPtr<GLStream> inputs = GLStreamFactory::readFromFile(pic);
    return _createFromStream(inputs);
}
GLBmp* create(unsigned char* data, int length)
{
    return NULL;
}
#endif
