#include "algorithm/GLDistanceMatcher.h"
#include <vector>
#include <stdlib.h>


static float _GetDistance(float* a, float* b, int n)
{
    float sum = 0;
    float error = 0;
    for (int i=0; i<n; ++i)
    {
        error = a[i]-b[i];
        sum += (error*error);
    }
    return sum;
}

static void swap(int& i, int& j, float& di, float& dj)
{
    int temp = i;
    i = j;
    j = temp;
    float _temp = di;
    di = dj;
    dj = _temp;
}

GPPtr<GLMatrix<int>> GLDistanceMatcher::vMatch(GPPtr<GLMatrix<float>> featuresA, GPPtr<GLMatrix<float>> featuresB) const
{
    GLASSERT(featuresA.get()!=NULL);
    GLASSERT(featuresB.get()!=NULL);
    GLASSERT(featuresA->width() == featuresB->width());
    auto w = featuresA->width();
    auto ha = featuresA->height();
    auto hb = featuresB->height();
    
    std::vector<std::pair<int, int>> points;
    const float rate = 0.4f;
    
    for (int i=0; i<ha; ++i)
    {
        auto va = featuresA->getAddr(i);
        int minPos = 0;
        float minDistance = _GetDistance(featuresB->getAddr(0), va, w);
        int minPos2 = 1;
        float minDistance2 = _GetDistance(featuresB->getAddr(1), va, w);
        if (minDistance2 < minDistance)
        {
            swap(minPos, minPos2, minDistance, minDistance2);
        }
        for (int j=2; j<hb; ++j)
        {
            auto curb = featuresB->getAddr(j);
            float distance = _GetDistance(curb, va, w);
            if (distance < minDistance)
            {
                minDistance2 = minDistance;
                minPos2 = minPos;
                minDistance = distance;
                minPos = j;
            }
            else if (distance < minDistance2)
            {
                minDistance2 = distance;
                minPos2 = j;
            }
        }
        if (minDistance < minDistance2*rate)
        {
            points.push_back(std::make_pair(i, minPos));
        }
    }
    if (0 == points.size())
    {
        /*FIXME*/
        GLASSERT(0);
        return NULL;
    }
    auto pointSize = (int)points.size();
    GPPtr<GLMatrix<int>> result = new GLMatrix<int>(pointSize, 2);
    auto _x = result->getAddr(0);
    auto _y = result->getAddr(1);
    for (int i=0; i< pointSize; ++i)
    {
        _x[i] = points[i].first;
        _y[i] = points[i].second;
    }
    return result;
}
