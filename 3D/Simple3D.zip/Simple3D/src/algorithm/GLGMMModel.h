//
//  GLGMMModel.h
//  simple3d
//
//  Created by jiangxiaotang on 15/9/9.
//  Copyright (c) 2015年 jiangxiaotang. All rights reserved.
//

#ifndef __simple3d__GLGMMModel__
#define __simple3d__GLGMMModel__

#include <stdio.h>
#include <vector>
#include "utils/RefCount.h"
#include "algorithm/GLMatrix.h"
class GLGMMModel:public RefCount
{
public:
    GLGMMModel(const GLMatrix<float>* data, int centers);
    virtual ~GLGMMModel();
    float predictUnit(float* piece, float* diffcache, int n);
    void predict(const GLMatrix<float>* data, GLMatrix<float>* dest);
    bool isValid() const {return mCenters.get() != NULL;}
private:
    GPPtr<GLMatrix<float>> mCenters;
    GPPtr<GLMatrix<float>> mCoes;
    std::vector<GPPtr<GLMatrix<float>>> mInverseCovs;
};
#endif /* defined(__simple3d__GLGMMModel__) */
