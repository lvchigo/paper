#include "algorithm/GLSiftOperator.h"
#ifndef DISABLE_MOVIE
extern "C"
{
#include "sift.h"
}
#include <vector>
#include <string.h>
#include "utils/GLAutoStorage.h"

GLSiftOperator::GLSiftOperator(int noctaves, int nlevels, int o_min)
{
    mNoctaves = noctaves;
    mNlevels = nlevels;
    mOmin = o_min;
}
GLSiftOperator::~GLSiftOperator()
{
}

std::pair<GPPtr<GLMatrix<int>>, GPPtr<GLMatrix<float>>> GLSiftOperator::vExtract(const GLGrayBitmap* origin) const
{
    GLAutoStorage<float> _gray_float(origin->width()*origin->height());
    vl_sift_pix* gray_float = _gray_float.get();
    
    auto w = origin->width();
    auto h = origin->height();
    for (int y=0; y<origin->height(); ++y)
    {
        auto _g = origin->getAddr(0, y);
        auto _gf = gray_float + w*y;
        for (int x=0; x<w; ++x)
        {
            _gf[x] = _g[x];
        }
    }
    int noctaves=4,nlevels=2,o_min=0;
    VlSiftFilt *SiftFilt= vl_sift_new(w,h,noctaves,nlevels,o_min);
    GLAutoDelete<VlSiftFilt> __delete(SiftFilt, vl_sift_delete);
    int totalPoints = 0;
    std::vector<GPPtr<GLMatrix<float>>> features;
    std::vector<GPPtr<GLMatrix<int>>> points;
    if (vl_sift_process_first_octave(SiftFilt,gray_float)!=VL_ERR_EOF)
    {
        do
        {
            vl_sift_detect(SiftFilt);
            VlSiftKeypoint *pKeyPoint=SiftFilt->keys;
            totalPoints+=SiftFilt->nkeys;
            GPPtr<GLMatrix<float>> currentFeature = new GLMatrix<float>(128, SiftFilt->nkeys);
            GPPtr<GLMatrix<int>> currentPoints = new GLMatrix<int>(SiftFilt->nkeys, 2);
            auto _x = currentPoints->getAddr(0);
            auto _y = currentPoints->getAddr(1);
            for (int i=0;i<SiftFilt->nkeys;i++)
            {
                VlSiftKeypoint TemptKeyPoint=pKeyPoint[i];
                _x[i] = TemptKeyPoint.x;
                _y[i] = TemptKeyPoint.y;
                double angles[4];
                int angleCount=vl_sift_calc_keypoint_orientations(SiftFilt,angles,&TemptKeyPoint);
                GLASSERT(angleCount>=1);
                auto _f = currentFeature->getAddr(i);
                double TemptAngle=angles[0];
                vl_sift_calc_keypoint_descriptor(SiftFilt,_f,&TemptKeyPoint,TemptAngle);
            }
            features.push_back(currentFeature);
            points.push_back(currentPoints);
        } while (vl_sift_process_next_octave(SiftFilt)!=VL_ERR_EOF);
    }
    /*Merge*/
    GLASSERT(totalPoints > 0);
    GPPtr<GLMatrix<int>> mergePoints = new GLMatrix<int>(totalPoints, 2);
    GPPtr<GLMatrix<float>> mergeFeature = new GLMatrix<float>(128, totalPoints);
    int n = (int)points.size();
    auto tx = mergePoints->getAddr(0);
    auto ty = mergePoints->getAddr(1);
    int offset = 0;
    for (int i=0; i<n; ++i)
    {
        auto x = points[i]->getAddr(0);
        auto y = points[i]->getAddr(1);
        ::memcpy(tx+offset, x, sizeof(int)*points[i]->width());
        ::memcpy(ty+offset, y, sizeof(int)*points[i]->width());
        offset += points[i]->width();
    }
    
    offset = 0;
    for (int i=0; i<n; ++i)
    {
        auto f = features[i];
        auto fh = f->height();
        auto fw = f->width();
        for (int y=0; y<fh; ++y)
        {
            auto _mf = mergeFeature->getAddr(y+offset);
            auto _f = f->getAddr(y);
            ::memcpy(_mf, _f, sizeof(float)*fw);
        }
        offset += fh;
    }
    return std::make_pair(mergePoints, mergeFeature);
}
#else
GLSiftOperator::GLSiftOperator(int noctaves, int nlevels, int o_min)
{
}
GLSiftOperator::~GLSiftOperator()
{
}
    
std::pair<GPPtr<GLMatrix<int>>, GPPtr<GLMatrix<float>>> GLSiftOperator::vExtract(const GLGrayBitmap* bitmap) const
{
    GPPtr<GLMatrix<int>> x;
    GPPtr<GLMatrix<float>> y;
    return std::make_pair(x, y);
}
#endif
