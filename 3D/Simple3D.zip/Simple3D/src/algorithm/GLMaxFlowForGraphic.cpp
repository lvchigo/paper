#include "GLMaxFlowForGraphic.h"
#include "utils/GLDebug.h"
GLMaxFlowForGraphic::GLMaxFlowForGraphic(int w, int h)
{
    GLASSERT(w > 5 && h > 5);
    mW = w;
    mH = h;
    mTcap = new GLMatrix<float>(w, h);
    mLeft = new GLMatrix<float>(w, h);
    mRight = new GLMatrix<float>(w, h);
    mUp = new GLMatrix<float>(w, h);
    mDown = new GLMatrix<float>(w, h);
    mUpLeft = new GLMatrix<float>(w, h);
    mUpRight = new GLMatrix<float>(w, h);
    mDownLeft = new GLMatrix<float>(w, h);
    mDownRight = new GLMatrix<float>(w, h);
    mIsSource = new GLMatrix<char>(w, h);
    mParentX = new GLMatrix<int>(w, h);
    mParentY = new GLMatrix<int>(w, h);
}
GLMaxFlowForGraphic::~GLMaxFlowForGraphic()
{
}


void GLMaxFlowForGraphic::setUp(const GLMatrix<float>* frontWeight, const GLMatrix<float>* backWeight, const GLMatrix<float>* up, const GLMatrix<float>* left, const GLMatrix<float>* upleft, const GLMatrix<float>* upright)
{
    GLASSERT(frontWeight->height() == mW*mH);
    GLASSERT(backWeight->height() == mW*mH);
    GLASSERT(up->height() == mH && up->width() == mW);
    GLASSERT(left->height() == mH && left->width() == mW);
    GLASSERT(upleft->height() == mH && upleft->width() == mW);
    GLASSERT(upright->height() == mH && upright->width() == mW);
    for (int i=0; i<mH; ++i)
    {
        auto x = mParentX->getAddr(i);
        auto y = mParentY->getAddr(i);
        for (int j=0; j<mW; ++j)
        {
            x[j] = -1;
            y[j] = -1;
        }
    }
    for (int i=0; i<mH; ++i)
    {
        auto tap = mTcap->getAddr(i);
        auto sign = mIsSource->getAddr(i);
        for (int j=0; j<mW; ++j)
        {
            auto front = frontWeight->getAddr(i*mW+j);
            auto back = backWeight->getAddr(i*mW+j);
            tap[j] = *front - *back;
            sign[j] = tap[j]>0;
        }
    }
    /*Up, Down*/
    for (int i=0; i<mH; ++i)
    {
        auto _up = mUp->getAddr(i);
        ::memcpy(_up, up->getAddr(i), mW*sizeof(float));
        auto _down = mDown->getAddr(i);
        if (i < mH-1)
        {
            ::memcpy(_down, up->getAddr(i+1), mW*sizeof(float));
        }
        else
        {
            ::memset(_down, 0, mW*sizeof(float));
        }
    }
    /*Left Right*/
    for (int i=0; i<mH; ++i)
    {
        auto _left = mLeft->getAddr(i);
        ::memcpy(_left, left->getAddr(i), mW*sizeof(float));
        auto _right = mRight->getAddr(i);
        ::memcpy(_right, left->getAddr(i)+1, (mW-1)*sizeof(float));
        _right[mW-1] = 0.0;
    }
    /*UpLeft, DownRight*/
    mUpLeft->clear();
    mUpRight->clear();
    for (int i=0; i<mH-1; ++i)
    {
        auto basic = upleft->getAddr(i+1)+1;
        auto origin = mUpLeft->getAddr(i+1)+1;
        ::memcpy(origin, basic, (mW-1)*sizeof(float));
        auto _reverse = mDownRight->getAddr(i);
        ::memcpy(_reverse, basic, (mW-1)*sizeof(float));
    }
    /*UpRight, DownLeft*/
    mUpRight->clear();
    mDownLeft->clear();
    for (int i=0; i<mH-1; ++i)
    {
        auto basic = upright->getAddr(i+1);
        auto origin = mUpLeft->getAddr(i+1);
        ::memcpy(origin, basic, (mW-1)*sizeof(float));
        auto _reverse = mDownRight->getAddr(i)+1;
        ::memcpy(_reverse, basic, (mW-1)*sizeof(float));
    }
}
void GLMaxFlowForGraphic::runForGraphic(GLGrayBitmap* dst)
{
    GLASSERT(dst->width() == mW);
    GLASSERT(dst->height() == mH);
}
