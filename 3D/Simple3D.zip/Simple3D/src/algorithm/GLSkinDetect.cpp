#include "algorithm/GLSkinDetect.h"
#include "utils/GLDebug.h"
/*
varying vec2 textureCoordinate;

uniform sampler2D inputImage;
const vec3 CbC = vec3(0.5,-0.4187,-0.0813);
const vec3 CrC = vec3(-0.1687,-0.3313,0.5);
float possible(float a, float mean, float sqr)
{
    return exp(-(a-mean)*(a-mean)/sqr/10.0);
}



void main()
{
    vec3 color = texture2D(inputImage, textureCoordinate).rgb;
    float x0 = color.r;
    float x1 = color.g;
    float x2 = color.b;
    float x3 = dot(CbC, color);
    float x4 = dot(CrC, color);
    //float pos = possible(cb, 0.0506405, 0.00211371) * possible(cr, -0.0419684, 0.00152153);
    float pos = 0.0;
    pos = float(x4 <=-0.0615369 ? (x3 <=0.0678488 ? (x3 <=0.0352417 ? 0 : (x2 <=0.686631 ? 0 : 1)) : (x3 <=0.185183 ? 1 : 0)) : (x4 <=-0.029597 ? (x3 <=0.0434402 ? 0 : (x1 <=0.168271 ? 0 : 1)) : 0));
    gl_FragColor = vec4(pos);
    //gl_FragColor = vec4(color*vec3(pos), 1.0);
}
*/
void GLSkinDetect::run(const GLBmp* src, GLGrayBitmap* dst, unsigned char skin, unsigned char nonskin)
{
    GLASSERT(NULL!=src);
    GLASSERT(NULL!=dst);
    GLASSERT(src->width() == dst->width());
    GLASSERT(src->height() == dst->height());
    int w = src->width();
    int h = src->height();
    for (auto i=0; i<h; ++i)
    {
        auto rgb_p = src->getAddr(0, i);
        auto mask_p = dst->getAddr(0, i);
        for (auto j=0; j<w; ++j)
        {
            float x0 = rgb_p[4*j+0]/255.0;
            float x1 = rgb_p[4*j+1]/255.0;
            float x2 = rgb_p[4*j+2]/255.0;
            float x3 = 0.5*x0 - 0.4187*x1 -0.0813*x2;
            float x4 = -0.1687*x0 -0.3313*x1 + 0.5*x2;
            int isskin = (x4 <=-0.0615369 ? (x3 <=0.0678488 ? (x3 <=0.0352417 ? 0 : (x2 <=0.686631 ? 0 : 1)) : (x3 <=0.185183 ? 1 : 0)) : (x4 <=-0.029597 ? (x3 <=0.0434402 ? 0 : (x1 <=0.168271 ? 0 : 1)) : 0));
            mask_p[j] = isskin*skin + (1-isskin)*nonskin;
        }
    }
}
