#include "algorithm/GLRegions.h"
#include "utils/GP_Clock.h"
#include "utils/GLDebug.h"
#include "utils/GLAutoStorage.h"
#include <vector>
#include <string.h>
typedef unsigned char uchar;

#ifdef GPCLOCK
#undef GPCLOCK
#define GPCLOCK
#endif

struct run
{
    int sta;
    int fin;
    int mask;
};
typedef std::vector<run> RUNS;

static void _resetMinMask(int* maskMap, char* maskMatrix, int maskCount, int pos, int minIndex)
{
    if (maskMap[pos] <= minIndex) return;
    maskMap[pos] = minIndex;
    auto mask_line = maskMatrix + pos*maskCount;
    for (int i=0; i<maskCount; ++i)
    {
        if (mask_line[i] > 0)
        {
            _resetMinMask(maskMap, maskMatrix, maskCount, i, minIndex);
        }
    }
}


static void _connect(int* maskMap, int maskCount, int h_start, int h_stop, RUNS* runForAllLines)
{
    GPCLOCK;
    GLAUTOSTORAGE(maskMatrix, char, maskCount*maskCount);
    GLASSERT(NULL!=maskMatrix);
    ::memset(maskMatrix, 0, sizeof(char)*maskCount*maskCount);
    {
        GPCLOCK;
        for (int y=h_start+1; y<=h_stop; ++y)
        {
            RUNS& r_before = runForAllLines[y-1];
            RUNS& r_current = runForAllLines[y];
            if (r_before.empty() || r_current.empty())
            {
                continue;
            }
            for (int i=0; i<r_current.size(); ++i)
            {
                run& r_cur = r_current[i];
                for (int j=0; j<r_before.size(); ++j)
                {
                    run& r_bef = r_before[j];
                    if (r_cur.sta <= r_bef.fin-1 && r_cur.fin >= r_bef.sta-1)
                    {
                        maskMatrix[r_bef.mask*maskCount+r_cur.mask] = 1;
                        maskMatrix[r_cur.mask*maskCount+r_bef.mask] = 1;
                    }
                }
            }
        }
    }
    for (int i=0; i<maskCount; ++i)
    {
        int min_index = i;
        auto _maskMatrix_line = maskMatrix + i*maskCount;
        for (int j=0;j<i; ++j)
        {
            if (_maskMatrix_line[j] > 0)
            {
                min_index = maskMap[j] < min_index ? maskMap[j] : min_index;
            }
        }
        maskMap[i] = min_index;
        for (int j=0;j<i; ++j)
        {
            if (_maskMatrix_line[j] > 0)
            {
                _resetMinMask(maskMap, maskMatrix, maskCount, j, min_index);
            }
        }
    }
}


static int _findAllRuns(RUNS* runForAllLines, int w, int h, const GLGrayBitmap* mask)
{
    /*Find All Runs Begin*/
    GPCLOCK;
    int maskCount = 0;
    for (int y=0; y<h; ++y)
    {
        bool count = false;
        auto line_p = mask->getAddr(0, y);
        RUNS& r = runForAllLines[y];
        run current;
        for (int x=0; x<w-1; ++x)
        {
            if (count)
            {
                if (0 == line_p[x])
                {
                    current.mask = maskCount++;
                    current.fin = x-1;
                    r.push_back(current);
                    count = false;
                }
            }
            else
            {
                if (0 < line_p[x])
                {
                    current.sta = x;
                    count = true;
                }
            }
        }
        if (count)
        {
            if (0 < line_p[w-1])
            {
                current.fin = w-1;
            }
            else
            {
                current.fin = w-2;
            }
            current.mask = maskCount++;
            r.push_back(current);
        }
    }
    /*Find All Runs End*/
    return maskCount;
}

GLRect GLRegion::reduceToOneRegion(GLGrayBitmap* mask, const GLRect* saveRects, int saveNumber)
{
    GPCLOCK;
    GLASSERT(NULL!=mask);
    auto w = mask->width();
    auto h = mask->height();
    GLRect result;
    result.l = -1;
    result.r = -1;
    result.t = -1;
    result.b = -1;
    GLAUTOSTORAGE(runForAllLines, RUNS, h);
    GLASSERT(NULL!=runForAllLines);
    int maskCount = _findAllRuns(runForAllLines, w, h, mask);
    int h_start = h-1, h_stop = 0;
    for (int y=0; y<h; ++y)
    {
        RUNS& r = runForAllLines[y];
        if (!r.empty())
        {
            h_start = y;
            break;
        }
    }
    for (int y=h-1; y>=0; --y)
    {
        RUNS& r = runForAllLines[y];
        if (!r.empty())
        {
            h_stop = y;
            break;
        }
    }
    if (h_start >= h_stop)
    {
        GLASSERT(0);
        return result;
    }
    /*Connect And Reduce*/
    if (maskCount>10000)
    {
        GLASSERT(0);
        return result;
    }
    GLAUTOSTORAGE(maskMap, int, maskCount);
    GLASSERT(NULL!=maskMap);
    _connect(maskMap, maskCount, h_start, h_stop, runForAllLines);
    /*Replace mask*/
    for (int y=h_start; y<=h_stop; ++y)
    {
        RUNS& runs = runForAllLines[y];
        for (int i=0; i<runs.size(); ++i)
        {
            run& r = runs[i];
            GLASSERT(r.fin>=r.sta);
            r.mask = maskMap[r.mask];
        }
    }
    ::memset(maskMap, 0, sizeof(int)*maskCount);
    if (NULL == saveRects)
    {
        GPCLOCK;
        /*Find max and clear others*/
        /*CountNumber*/
        GLAUTOSTORAGE(maskNumbers, size_t, maskCount);
        ::memset(maskNumbers, 0, maskCount*sizeof(size_t));
        for (int y=0; y<h; ++y)
        {
            RUNS& runs = runForAllLines[y];
            for (auto r : runs)
            {
                GLASSERT(r.fin>=r.sta);
                maskNumbers[r.mask]+= (r.fin-r.sta+1);
            }
        }
        size_t max = 0;
        int max_mask = -1;
        for (int i=0; i<maskCount; ++i)
        {
            if (maskNumbers[i]>max)
            {
                max = maskNumbers[i];
                max_mask = i;
            }
        }
        maskMap[max_mask] = 1;
    }
    else
    {
        for (int i=0; i<saveNumber; ++i)
        {
            const GLRect* saveRect = saveRects+i;
            if (!saveRect->valid())
            {
                continue;
            }
            for (int y=saveRect->t; y<=saveRect->b; ++y)
            {
                RUNS& runs = runForAllLines[y];
                for (int i=0; i<runs.size(); ++i)
                {
                    run& r = runs[i];
                    if (r.fin >= saveRect->l && r.sta <= saveRect->r)
                    {
                        maskMap[r.mask] = 1;
                    }
                }
            }
        }
    }
    GPPtr<GLGrayBitmap> cacheMask = new GLGrayBitmap(mask->width(), mask->height());
    cacheMask->clear();
    for (int y=h_start; y<=h_stop; ++y)
    {
        RUNS& runs = runForAllLines[y];
        for (auto r : runs)
        {
            if (maskMap[r.mask]>0)
            {
                result.enLarge(r.sta, y, r.fin, y);
                ::memset(cacheMask->getAddr(r.sta, y), 0xFF, sizeof(unsigned char)*(r.fin-r.sta+1));
            }
        }
    }
    for (int y=0; y<mask->height(); ++y)
    {
        auto _m = mask->getAddr(0, y);
        auto _cm = cacheMask->getAddr(0, y);
        for (int x=0; x<mask->width(); ++x)
        {
            if (_cm[x] <= 0)
            {
                _m[x] = 0;
            }
        }
    }
    return result;
}

/*Copy From OpenCV*/
typedef char schar;
struct CvPoint
{
    int x;
    int y;
    CvPoint(int _x = 0, int _y = 0): x(_x), y(_y) {}
};

static void icvFetchContour(schar* ptr, int step, CvPoint pt, std::vector<std::pair<int, int>>& points);

static const CvPoint icvCodeDeltas[8] =
{ CvPoint(1, 0), CvPoint(1, -1), CvPoint(0, -1), CvPoint(-1, -1), CvPoint(-1, 0), CvPoint(-1, 1), CvPoint(0, 1), CvPoint(1, 1) };

/* initializes 8-element array for fast access to 3x3 neighborhood of a pixel */
#define  CV_INIT_3X3_DELTAS( deltas, step, nch )            \
    ((deltas)[0] =  (nch),  (deltas)[1] = -(step) + (nch),  \
     (deltas)[2] = -(step), (deltas)[3] = -(step) - (nch),  \
     (deltas)[4] = -(nch),  (deltas)[5] =  (step) - (nch),  \
     (deltas)[6] =  (step), (deltas)[7] =  (step) + (nch))

typedef struct _CvContourInfo
{
    int flags;
    struct _CvContourInfo *next;        /* next contour with the same mark value */
    struct _CvContourInfo *parent;      /* information about parent contour */
    GLRect rect;                /* bounding rectangle */
    CvPoint origin;             /* origin point (where the contour was traced from) */
    int is_hole;                /* hole flag */
}
_CvContourInfo;

struct _CvContourScanner
{
    schar *img0;                /* image origin */
    schar *img;                 /* current image row */
    int img_step;               /* image step */
    int img_w;
    int img_h;
    _CvContourInfo frame_info;
    CvPoint offset;             /* ROI offset: coordinates, added to each contour point */
    CvPoint pt;                 /* current scanner position */
    CvPoint lnbd;               /* position of the last met contour */
    int nbd;                    /* current mark val */
    int subst_flag;
    int seq_type1;              /* type of fetched contours */
    int header_size1;           /* hdr size of fetched contours */
    int elem_size1;             /* elem size of fetched contours */
    int seq_type2;              /*                                       */
    int header_size2;           /*        the same for approx. contours  */
    int elem_size2;             /*                                       */
};

typedef _CvContourScanner* CvContourScanner;


static CvContourScanner cvStartFindContours( GLGrayBitmap* _img, CvPoint offset)
{
    int img_w = _img->width();
    int img_h = _img->height();
    int step = _img->width();
    uchar* img = (uchar*)(_img->getAddr(0, 0));
    for (int i=0; i<img_h*img_w; ++i)
    {
        if (img[i] > 0)
        {
            img[i] = 1;
        }
    }

    CvContourScanner scanner = new _CvContourScanner;
    memset( scanner, 0, sizeof(*scanner) );

    scanner->img0 = (schar *) img;
    scanner->img = (schar *) (img + step);
    scanner->img_step = step;
    scanner->img_h = img_h - 1;
    scanner->img_w = img_w -1;
    scanner->offset = offset;
    scanner->pt.x = scanner->pt.y = 1;
    scanner->lnbd.x = 0;
    scanner->lnbd.y = 1;
    scanner->nbd = 2;
    scanner->frame_info.is_hole = 1;
    scanner->frame_info.next = 0;
    scanner->frame_info.parent = 0;
    scanner->frame_info.rect = GLRect( 0, 0, img_w, img_h);
    scanner->subst_flag = 0;
    scanner->elem_size1 = sizeof( CvPoint );

    memset( img, 0, img_w*sizeof(uchar) );
    memset( img + step * (img_h - 1), 0, img_w*sizeof(uchar) );

    img += step;
    for( int y = 1; y < img_h - 1; y++, img += step )
    {
        img[0] = img[img_w-1] = (schar)0;
    }
    return scanner;
}


typedef std::vector<std::pair<int, int>> POINTS;

static void cvFindNextContour(CvContourScanner scanner, std::vector<std::pair<int, int>>& points)
{
    /* initialize local state */
    schar* img = scanner->img;
    int step = scanner->img_step;
    int x = scanner->pt.x;
    int y = scanner->pt.y;
    int width = scanner->img_w;
    int height = scanner->img_h;
    CvPoint lnbd = scanner->lnbd;
    int prev = img[x - 1];
    int new_mask = -2;

    for( ; y < height; y++, img += step )
    {
        int* img_i = 0;
        int p = 0;

        for( ; x < width; x++ )
        {
            if( img_i )
            {
                for( ; x < width && ((p = img_i[x]) == prev || (p & ~new_mask) == (prev & ~new_mask)); x++ )
                    prev = p;
            }
            else
            {
                for( ; x < width && (p = img[x]) == prev; x++ )
                    ;
            }

            if( x >= width )
                break;

            {
                _CvContourInfo *par_info = 0;
                int is_hole = 0;
                CvPoint origin;


                origin.y = y;
                origin.x = x - is_hole;

                /* find contour parent */
                par_info = &(scanner->frame_info);

                lnbd.x = x - is_hole;

                /* initialize header */
                CvPoint searchStart(origin.x + scanner->offset.x, origin.y + scanner->offset.y);
                POINTS temppoints;
                icvFetchContour( img + x - is_hole, step, searchStart, temppoints);
                p = img[x];
                prev = p;
                //points.insert(points.end(), temppoints.begin(), temppoints.end());
                if (points.size() < temppoints.size())
                {
                    points = temppoints;
                }
                /* update lnbd */
                if( prev & -2 )
                {
                    lnbd.x = x;
                }
                if (temppoints.size()>points.size())
                {
                    points = temppoints;
                }
                if (temppoints.size()>0)
                {
                    break;
                }
            }                   /* end of prev != p */
        }                       /* end of loop on x */

        lnbd.x = 0;
        lnbd.y = y + 1;
        x = 1;
        prev = 0;
    }                           /* end of loop on y */

    return;
}




static void icvFetchContour(schar* ptr, int step, CvPoint pt, std::vector<std::pair<int, int>>& points)
{
    const char     nbd = 2;
    int             deltas[16];
    int             prev_s = -1, s, s_end;
    /* initialize local state */
    CV_INIT_3X3_DELTAS( deltas, step, 1);
    ::memcpy( deltas + 8, deltas, 8 * sizeof( deltas[0] ));
    char           *i0 = (ptr), *i1, *i3, *i4 = 0;
    s_end = s = 4;
    //s_end = s = CV_IS_SEQ_HOLE( contour ) ? 0 : 4;

    do
    {
        s = (s - 1) & 7;
        i1 = i0 + deltas[s];
        if( *i1 != 0 )
            break;
    }
    while( s != s_end );

    if( s == s_end )            /* single pixel domain */
    {
        return;
    }
    i3 = i0;
    prev_s = s ^ 4;

    /* follow border */
    for( ;; )
    {
        s_end = s;

        for( ;; )
        {
            i4 = i3 + deltas[++s];
            if( *i4 != 0 )
                break;
        }
        s &= 7;

        /* check "right" bound */
        if( (unsigned) (s - 1) < (unsigned) s_end )
        {
            *i3 = (schar) (nbd | -128);
        }
        else if( *i3 == 1 )
        {
            *i3 = nbd;
        }

        {
            if( s != prev_s)
            {
                points.push_back(std::make_pair(pt.x, pt.y));
                prev_s = s;
            }

            pt.x += icvCodeDeltas[s].x;
            pt.y += icvCodeDeltas[s].y;

        }

        if( i4 == i0 && i3 == i1 )
            break;

        i3 = i4;
        s = (s + 4) & 7;
    }                       /* end of border following loop */
}


/*Copy From OpenCV End*/

void GLRegion::findContour(GLGrayBitmap* mask, std::vector<std::pair<int, int>>& points)
{
    GLASSERT(NULL!=mask);
    CvPoint offset(0,0);
    auto info = cvStartFindContours(mask, offset);
    cvFindNextContour(info, points);
    delete info;
}

void GLRegion::fillHole(GLGrayBitmap* mask)
{
    GLASSERT(NULL!=mask);
    GPPtr<GLGrayBitmap> reverseMask = new GLGrayBitmap(mask->width(), mask->height());
    auto w = mask->width();
    auto h = mask->height();
    if (w <= 4 || h <=4)
    {
        return;
    }
    GLGrayBitmap::reverse(mask, reverseMask.get(), 254);
    GLRect bounds[4];
    /*Left*/
    bounds[0].l = 0; bounds[0].t=1; bounds[0].r = 0; bounds[0].b = h-1;
    /*Right*/
    bounds[1].l = w-1; bounds[1].t=1; bounds[1].r = w-1; bounds[1].b = h-1;
    /*Top*/
    bounds[2].l = 0; bounds[2].t=0; bounds[2].r = w-1; bounds[2].b = 0;
    /*Bottom*/
    bounds[3].l = 0; bounds[3].t=h-1; bounds[3].r = w-1; bounds[3].b = h-1;
    reduceToOneRegion(reverseMask.get(), bounds, 4);
    GLGrayBitmap::reverse(reverseMask.get(), mask);
}

#include "clipper.hpp"
using namespace ClipperLib;

void GLRegion::offsetContour(std::vector<std::pair<int, int>>& inputs, std::vector<std::pair<int, int>>& outputs, int offset)
{
    Path origin;
    for (size_t i=0; i<inputs.size(); ++i)
    {
        origin.push_back(IntPoint(inputs[i].first, inputs[i].second));
    }
    ClipperOffset clpr;
    //get the intersection of the subject and clip polygons ...
    clpr.AddPath(origin, jtRound, etClosedPolygon);
    Paths solution;
    clpr.Execute(solution, offset);
    outputs.clear();
    /*Find Max One*/
    size_t max_size = 0;
    size_t pos = -1;
    for (int i=0; i<solution.size(); ++i)
    {
        if (solution[i].size() > max_size)
        {
            max_size = solution[i].size();
            pos = i;
        }
    }
    if (-1 == pos)
    {
        return;
    }
    //GLASSERT(1 == solution.size());
    auto s = solution[pos];
    for (size_t i=0; i<s.size(); ++i)
    {
        outputs.push_back(std::make_pair(s[i].X, s[i].Y));
    }
}

int GLRegion::getMeanWidth(const GLGrayBitmap* mask, float rate)
{
    GLASSERT(NULL!=mask);
    GLASSERT(rate>0 && rate<1);
    auto w = mask->width();
    auto h = mask->height();
    const int level = 20;
    if (w <= level)
    {
        return w;
    }
    float piece = (float)w/(float)level;
    GLAUTOSTORAGE(number, int, level+1);
    for (int i=0; i<level+1; ++i)
    {
        number[i] = 0;
    }
    for (int y=0; y<h; ++y)
    {
        auto line_p = mask->getAddr(0, y);
        bool count = false;
        int sta = 0;
        for (int x=0; x<w-1; ++x)
        {
            if (count)
            {
                if (0 == line_p[x])
                {
                    int curW = x-sta;
                    int pos = curW/piece;
                    number[pos]++;
                    count = false;
                }
            }
            else
            {
                if (0 < line_p[x])
                {
                    sta = x;
                    count = true;
                }
            }
        }
        if (count)
        {
            int curW = 0;
            if (0 < line_p[w-1])
            {
                curW = w-sta;
            }
            else
            {
                curW = w-sta-1;
            }
            int pos = curW/piece;
            number[pos]++;
        }
    }
    int sum = 0;
    for (int i=0; i<level+1; ++i)
    {
        sum+=number[i];
    }
    int cur = 0;
    int permit = sum*rate;
    for (int i=0; i<level+1; ++i)
    {
        cur+=number[i];
        if (cur > permit)
        {
            return piece*(i+1);
        }
    }

    return 0;
}

