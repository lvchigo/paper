//
//  GLSampler.h
//  simple3d
//
//  Created by jiangxiaotang on 15/9/9.
//  Copyright (c) 2015年 jiangxiaotang. All rights reserved.
//

#ifndef __simple3d__GLSampler__
#define __simple3d__GLSampler__

#include <stdio.h>
#include "algorithm/GLMatrix.h"
#include "core/GLBmp.h"
#include "core/GLGrayBitmap.h"
class GLSampler
{
public:
    static GPPtr<GLMatrix<float>> sampleRectBound(const GLBmp* source, int l, int t, int r, int b);
    static GPPtr<GLMatrix<float>> sampleByMaskRect(const GLBmp* source, const GLGrayBitmap* mask, int l, int t);
    static GPPtr<GLMatrix<float>> sampleAllRect(const GLBmp* source, int l, int t, int r, int b);
    static GPPtr<GLMatrix<float>> sampleAllOutRect(const GLBmp* source, int l, int t, int r, int b);
    static void sampleRandomOutRect(const GLBmp* source, int l, int t, int r, int b, GLMatrix<float>* sample);
    static void sampleRandomRect(const GLBmp* source, int l, int t, int r, int b, GLMatrix<float>* sample, int offset, int count);
};


#endif /* defined(__simple3d__GLSampler__) */
