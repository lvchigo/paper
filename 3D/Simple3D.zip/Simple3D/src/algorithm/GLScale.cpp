#include "algorithm/GLScale.h"
#include "utils/GLDebug.h"


GPPtr<GLBmp> GLScale::reduceBitmapCroped(const GLBmp* src, int l, int t, int r, int b, int scaled)
{
    GLASSERT(NULL!=src);
    int w = r-l+1;
    int h = b-t+1;
    GLASSERT(scaled>=1);
    GLASSERT(w % scaled == 0);
    GLASSERT(h % scaled == 0);
    int dw = w/scaled;
    int dh = h/scaled;
    GPPtr<GLBmp> res = new GLBmp(dw, dh);
    int bpp = src->bpp();
    for (int i=0; i<dh; ++i)
    {
        for (int j=0; j<dw; ++j)
        {
            auto dst_sta = res->getAddr(j, i);
            auto src_sta = src->getAddr(l+j*scaled, t+i*scaled);
            for (int k=0; k<bpp; ++k)
            {
                dst_sta[k] = src_sta[k];
            }
        }
    }
    return res;
}

GPPtr<GLGrayBitmap> GLScale::reduceBitmapCroped(const GLGrayBitmap* src, int l, int t, int r, int b, int scaled)
{
    GLASSERT(NULL!=src);
    int w = r-l+1;
    int h = b-t+1;
    GLASSERT(scaled>=1);
    GLASSERT(w % scaled == 0);
    GLASSERT(h % scaled == 0);
    int dw = w/scaled;
    int dh = h/scaled;
    GPPtr<GLGrayBitmap> res = new GLGrayBitmap(dw, dh);
    int bpp = src->bpp();
    for (int i=0; i<dh; ++i)
    {
        for (int j=0; j<dw; ++j)
        {
            auto dst_sta = res->getAddr(j, i);
            auto src_sta = src->getAddr(l+j*scaled, t+i*scaled);
            for (int k=0; k<bpp; ++k)
            {
                dst_sta[k] = src_sta[k];
            }
        }
    }
    return res;
}


GPPtr<GLGrayBitmap> GLScale::scaleBitmap(const GLGrayBitmap* src, int scale)
{
    GPCLOCK;
    GLASSERT(NULL!=src);
    GLASSERT(scale>1);
    int w = src->width();
    int h = src->height();
    GPPtr<GLGrayBitmap> res = new GLGrayBitmap(w*scale, h*scale);
    float divide = 1.0/scale;
    for (int i=0; i<h; ++i)
    {
        for (int j=0; j<w; ++j)
        {
            int r = j+1;
            if (r >= w) r = w-1;
            int b = i+1;
            if (b >= h) b = h-1;
            int lt = *(src->getAddr(j, i));
            int lb = *(src->getAddr(j, b));
            int rt = *(src->getAddr(r, i));
            int rb = *(src->getAddr(r, b));
            for (int q=0; q<scale; ++q)
            {
                float yRate = q*divide;
                auto dst_ = res->getAddr(j*scale, i*scale+q);
                for (int p=0; p<scale; ++p)
                {
                    float xRate = p*divide;
                    dst_[p] = (1-xRate)*(1-yRate)*lt + (1-xRate)*yRate*lb + xRate*(1-yRate)*rt + xRate*yRate*rb;
                }
            }
        }
    }
    return res;
}
