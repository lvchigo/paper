#include "algorithm/GLLinearRegressor.h"


GPPtr<GLMatrix<float>> GLLinearRegressor::vRegress(GPPtr<GLMatrix<int>> P1, GPPtr<GLMatrix<int>> P2) const
{
    GLASSERT(P1->width() == P2->width());
    GLASSERT(P1->height() == 2 && P2->height() == 2);
    auto h = P1->width();
    auto w = 3;
    GPPtr<GLMatrix<float>> X = new GLMatrix<float>(w, h);
    GPPtr<GLMatrix<float>> Y = new GLMatrix<float>(2, h);
    
    /*P2 = F * P1*/
    
    auto _p1x = P1->getAddr(0);
    auto _p1y = P1->getAddr(1);
    auto _p2x = P2->getAddr(0);
    auto _p2y = P2->getAddr(1);
    for (int i=0; i<h; ++i)
    {
        auto x = X->getAddr(i);
        auto y = Y->getAddr(i);
        x[0] = _p1x[i];
        x[1] = _p1y[i];
        x[2] = 1.0f;
        y[0] = _p2x[i];
        y[1] = _p2y[i];
    }
    
    //(XTX)-1 * XT * Y
    GPPtr<GLMatrix<float>> XT = new GLMatrix<float>(h, w);
    GLMatrix_transpose(X.get(), XT.get());
    GPPtr<GLMatrix<float>> P = GLMatrix_product(XT.get(), X.get());
    GPPtr<GLMatrix<float>> Q = new GLMatrix<float>(P->width(), P->height());
    GLMatrix_inverse(P.get(), Q.get());
    P = GLMatrix_product(Q.get(), XT.get());
    P = GLMatrix_product(P.get(), Y.get());
    
    GPPtr<GLMatrix<float>> res = new GLMatrix<float>(P->height(), P->width());
    GLMatrix_transpose(P.get(), res.get());
    return res;
}
