#ifndef __simple3d__GLMaxFlowForGraphic__
#define __simple3d__GLMaxFlowForGraphic__

#include "core/GLGrayBitmap.h"
#include "algorithm/GLMatrix.h"
class GLMaxFlowForGraphic
{
public:
    GLMaxFlowForGraphic(int w, int h);
    ~GLMaxFlowForGraphic();
    void setUp(const GLMatrix<float>* frontWeight, const GLMatrix<float>* backWeight, const GLMatrix<float>* up, const GLMatrix<float>* left, const GLMatrix<float>* upleft, const GLMatrix<float>* upright);
    void runForGraphic(GLGrayBitmap* dst);
private:
    GPPtr<GLMatrix<float>> mTcap;
    
    GPPtr<GLMatrix<float>> mUp;
    GPPtr<GLMatrix<float>> mDown;
    
    GPPtr<GLMatrix<float>> mLeft;
    GPPtr<GLMatrix<float>> mRight;
    
    GPPtr<GLMatrix<float>> mUpLeft;
    GPPtr<GLMatrix<float>> mDownRight;
    
    GPPtr<GLMatrix<float>> mUpRight;
    GPPtr<GLMatrix<float>> mDownLeft;
    
    GPPtr<GLMatrix<char>> mIsSource;
    GPPtr<GLMatrix<int>> mParentX;
    GPPtr<GLMatrix<int>> mParentY;
    
    int mW;
    int mH;
};

#endif
