//
//  GLKMeans.h
//  simple3d
//
//  Created by jiangxiaotang on 15/9/9.
//  Copyright (c) 2015年 jiangxiaotang. All rights reserved.
//

#ifndef __simple3d__GLKMeans__
#define __simple3d__GLKMeans__

#include <stdio.h>
#include "algorithm/GLMatrix.h"
#include "utils/RefCount.h"
class GLKMeans
{
public:
    static GPPtr<GLMatrix<float> > train(const GLMatrix<float>* data, int centers, float error=0.1, int maxiters = 1000);
    
    /*Return a one-line matrix*/
    static GPPtr<GLMatrix<int>> predict(const GLMatrix<float>* data, const GLMatrix<float>* centers);
};
#endif /* defined(__simple3d__GLKMeans__) */
