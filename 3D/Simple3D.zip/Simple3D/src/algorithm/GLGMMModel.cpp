//
//  GLGMMModel.cpp
//  simple3d
//
//  Created by jiangxiaotang on 15/9/9.
//  Copyright (c) 2015年 jiangxiaotang. All rights reserved.
//

#include "GLGMMModel.h"
#include "GLKMeans.h"
#include "GLAutoStorage.h"
#include <math.h>
#include <iostream>
#include "GP_Clock.h"
GLGMMModel::GLGMMModel(const GLMatrix<float>* data, int centers)
{
    GLASSERT(NULL!=data);
    GLASSERT(centers > 0);
    mCenters = GLKMeans::train(data, centers);
    if (mCenters.get() == NULL)
    {
        return;
    }
    /*Compute the cov*/
    int w = data->width();
    int h = data->height();
    for (int i=0; i<centers; ++i)
    {
        mInverseCovs.push_back(new GLMatrix<float>(w, w));
    }
    for (int i=0; i<centers; ++i)
    {
        auto _cov = mInverseCovs[i]->getAddr(0);
        ::memset(_cov, 0, sizeof(float)*w*w);
    }
    GPPtr<GLMatrix<int>> mask = GLKMeans::predict(data, mCenters.get());
    auto mask_ = mask->getAddr(0);
    GLAUTOSTORAGE(counts, int, centers);
    ::memset(counts, 0, centers*sizeof(int));
    for (int i=0; i<h; ++i)
    {
        auto data_ = data->getAddr(i);
        auto targetCov = mInverseCovs[mask_[i]];
        counts[mask_[i]]+=1;
        auto center = mCenters->getAddr(mask_[i]);
        auto targetCov_ = targetCov->getAddr(0);
        for (int j=0; j<w; ++j)
        {
            for (int k=j; k<w; ++k)
            {
                targetCov_[j*w+k] += (data_[j]-center[j])*(data_[k]-center[k]);
            }
        }
    }
    /*The coes is comput as c[i]/total*/
    mCoes = new GLMatrix<float>(centers, 1);
    auto _coes = mCoes->getAddr(0);
    for (int i=0; i<centers; ++i)
    {
        auto _cov = mInverseCovs[i]->getAddr(0);
        float count = counts[i];
        _coes[i] = count / (float)h;
        for (int j=0; j<w; ++j)
        {
            for (int k=j; k<w; ++k)
            {
                float temp = _cov[j*w+k]/count;
                _cov[j*w+k] = temp;
                _cov[k*w+j] = temp;
            }
        }
    }
    
    /*Inverse all cov*/
    for (int i=0; i<centers; ++i)
    {
        GPPtr<GLMatrix<float>> invcov = new GLMatrix<float>(w, w);
        float det = GLMatrix_inverse(mInverseCovs[i].get(), invcov.get());
        mInverseCovs[i] = invcov;
        _coes[i] *= (1.0/sqrt(det+0.00000001));//Consider for the case that det is very small and near zero
    }
}
GLGMMModel::~GLGMMModel()
{
}
void GLGMMModel::predict(const GLMatrix<float>* data, GLMatrix<float>* dest)
{
    GLASSERT(NULL!=dest);
    GLASSERT(NULL!=data);
    GLASSERT(dest->width() == data->height());
    GLASSERT(data->width() == mCenters->width());
    GLASSERT(NULL!=mCenters.get());
    GLASSERT(NULL!=mCoes.get());
    int w = data->width();
    int h = data->height();
    int centers = mCenters->height();
    GLAUTOSTORAGE(diff, float, w);
    float* result = dest->getAddr(0);
    auto coefs = mCoes->getAddr(0);
    for (int i=0; i<h; ++i)
    {
        float sum = 0.0;
        auto data_ = data->getAddr(i);
        for (int j=0; j<centers; ++j)
        {
            float multi = 0.0;
            auto center_ = mCenters->getAddr(j);
            auto invcov_ = mInverseCovs[j]->getAddr(0);
            for (int k=0; k<w; ++k)
            {
                diff[k] = data_[k] - center_[k];
            }
            for (int x=0; x<w; ++x)
            {
                float csum = 0.0;
                for (int y=0; y<w; ++y)
                {
                    csum += invcov_[x*w+y]*diff[y];
                }
                multi += csum*diff[x];
            }
            sum += coefs[j]*exp(-0.5f*multi);
        }
        result[i] = log(sum);
    }
}

float GLGMMModel::predictUnit(float* piece, float* diff, int n)
{
    GLASSERT(NULL!=piece);
    GLASSERT(n == mCenters->width());
    float sum = 0.0;
    int centers = mCenters->height();
    auto data_ = piece;
    int w = n;
    auto coefs = mCoes->getAddr(0);
    for (int j=0; j<centers; ++j)
    {
        float multi = 0.0;
        auto center_ = mCenters->getAddr(j);
        auto invcov_ = mInverseCovs[j]->getAddr(0);
        for (int k=0; k<w; ++k)
        {
            diff[k] = data_[k] - center_[k];
        }
        for (int x=0; x<w; ++x)
        {
            float csum = 0.0;
            for (int y=0; y<w; ++y)
            {
                csum += invcov_[x*w+y]*diff[y];
            }
            multi += csum*diff[x];
        }
        sum += coefs[j]*exp(-0.5f*multi);
    }
    return log(sum);
}

