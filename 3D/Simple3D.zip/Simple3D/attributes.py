#!/usr/bin/python
import json
jsonfile = "glsl/attributes.json"
cppfile = "src/utils/GLAttributes_Insert.cpp"
listA = json.loads(open(jsonfile).read())
head = '#include \"GLAttributes.h\"\n using namespace std;\n' 
head+="class GLAttributesRegistor{\n"
head+="public:\n"
head+="GLAttributesRegistor(){\n"

tail = '}\n};\n'
tail += 'static GLAttributesRegistor __a;\n'

middle = ''
print listA
for l in listA:
    print l
    middle+= 'map<string, int> ' + l+';\n'
    for group in listA[l]:
        print group
        for attr in group:
            value = group[attr]
            middle+= l + '.insert(make_pair(\"' + attr + '\",' + '%d' %value + '));\n'
        middle += 'GLAttributes::gAttributes.insert(make_pair(\"Shallow\", Shallow));\n'.replace('Shallow', l)
with open(cppfile, 'w') as f:
    f.write(head+middle+tail)
